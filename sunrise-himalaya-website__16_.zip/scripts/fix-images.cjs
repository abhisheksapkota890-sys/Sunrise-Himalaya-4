const fs = require("fs");
const path = require("path");

// 1. Copy photos
const photoCopies = [
  {
    src: "public/assets/gallery-annapurna-trail-lMf23I0A.jpg",
    dest: "public/images/short-annapurna-circuit.webp",
  },
  {
    src: "public/assets/region-mustang-lo-manthang-B0XvWSGn.jpg",
    dest: "public/images/upper-mustang.jpg",
  },
  { src: "public/images/upper-mustang-motorbike-tour.jpg", dest: "public/images/mustang-trek.jpg" },
  {
    src: "public/assets/gallery-patan-durbar-temple-BcZ9TqRc.jpg",
    dest: "public/images/patan-durbar-square.jpg",
  },
  {
    src: "public/assets/region-mustang-lo-manthang-B0XvWSGn.jpg",
    dest: "public/images/pilgrims-guide-muktinath-kali-gandaki.jpg",
  },
  { src: "public/images/changu-narayan-temple.jpg", dest: "public/images/muktinath-temple.jpg" },
  {
    src: "public/assets/region-chitwan-rhino-knqlVUXn.jpg",
    dest: "public/images/sauraha-jungle-safari.jpg",
  },
  {
    src: "public/assets/gallery-hill-village-stone-houses-RlDC_mTv.jpg",
    dest: "public/images/nar-phu-valley-trek.jpg",
  },
  {
    src: "public/assets/region-kathmandu-swayambhunath-DmGavd0w.jpg",
    dest: "public/images/swayambhunath-stupa.jpg",
  },
  {
    src: "public/assets/gallery-kathmandu-durbar-temple-CZfIl7Kj.jpg",
    dest: "public/images/pashupatinath-temple.jpg",
  },
  { src: "public/images/gorkha-durbar.jpg", dest: "public/images/nuwakot-durbar.jpg" },
  {
    src: "public/images/kathmandu-durbar-square-photo.jpg",
    dest: "public/images/tansen-durbar.jpg",
  },
  {
    src: "public/assets/hero-himalaya-DrS97LmK.jpg",
    dest: "public/images/pathibhara-devi-temple.jpg",
  },
  {
    src: "public/images/annapurna-base-camp-helicopter-tour.jpg",
    dest: "public/images/upper-mustang-helicopter-tour.jpg",
  },
  {
    src: "public/assets/gallery-gokyo-lake-reflection-BtoS1Y9X.jpg",
    dest: "public/images/pokhara-phewa-lake.jpg",
  },
  {
    src: "public/images/mountain-flight.jpg",
    dest: "public/images/paragliding-in-sarangkot-photo.jpg",
  },
];

for (const copy of photoCopies) {
  if (fs.existsSync(copy.src)) {
    fs.copyFileSync(copy.src, copy.dest);
    console.log(`Copied ${copy.src} -> ${copy.dest} (${fs.statSync(copy.dest).size} bytes)`);
  } else {
    console.error(`Source missing: ${copy.src}`);
  }
}

// 2. Generate SVG maps
function generateMapSvg(title, subtitle, waypoints) {
  const minAlt = Math.min(...waypoints.map((w) => w.alt));
  const maxAlt = Math.max(...waypoints.map((w) => w.alt));
  const plotTop = 160;
  const plotBottom = 500;
  const plotHeight = plotBottom - plotTop;
  const plotLeft = 100;
  const plotRight = 1100;
  const plotWidth = plotRight - plotLeft;

  const points = waypoints.map((w, i) => {
    const x = plotLeft + (i / (waypoints.length - 1)) * plotWidth;
    const ratio = maxAlt === minAlt ? 0.5 : (w.alt - minAlt) / (maxAlt - minAlt);
    const y = plotBottom - ratio * plotHeight;
    return { ...w, x, y };
  });

  const pathD = points
    .map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(1)},${p.y.toFixed(1)}`)
    .join(" ");
  const areaD = `${pathD} L ${plotRight},550 L ${plotLeft},550 Z`;

  const safeId = title.toLowerCase().replace(/[^a-z0-9]/g, "-");

  const markers = points
    .map(
      (p) => `
    <g>
      <line x1="${p.x.toFixed(1)}" y1="${p.y.toFixed(1)}" x2="${p.x.toFixed(1)}" y2="${(p.y - 16).toFixed(1)}" stroke="#9ca3af" stroke-width="1.5" stroke-dasharray="2,3"/>
      <circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="6.5" fill="#f59e0b" stroke="#111111" stroke-width="2"/>
      <circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="2" fill="#111111"/>
      <text x="${p.x.toFixed(1)}" y="${(p.y - 32).toFixed(1)}" text-anchor="middle" font-size="13" font-weight="700" fill="#111111">${p.name}</text>
      <text x="${p.x.toFixed(1)}" y="${(p.y - 18).toFixed(1)}" text-anchor="middle" font-size="12" font-weight="700" fill="#b45309">${p.alt}m</text>
    </g>
  `,
    )
    .join("\n");

  return `<svg width="1200" height="640" viewBox="0 0 1200 640" xmlns="http://www.w3.org/2000/svg" font-family="Georgia, 'Times New Roman', serif">
  <defs>
    <linearGradient id="sky-${safeId}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#eaf4fb"/>
      <stop offset="55%" stop-color="#cfe6f5"/>
      <stop offset="100%" stop-color="#ffffff"/>
    </linearGradient>
    <linearGradient id="area-${safeId}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#f59e0b" stop-opacity="0.35"/>
      <stop offset="100%" stop-color="#f59e0b" stop-opacity="0.03"/>
    </linearGradient>
  </defs>

  <rect x="0" y="0" width="1200" height="640" fill="url(#sky-${safeId})"/>
  <rect x="8" y="8" width="1184" height="624" fill="none" stroke="#111111" stroke-width="3"/>

  <rect x="300" y="28" width="600" height="60" fill="#ffffff" stroke="#111111" stroke-width="2"/>
  <text x="600" y="64" text-anchor="middle" font-size="22" font-weight="bold" fill="#111111">${title}</text>
  <text x="600" y="104" text-anchor="middle" font-size="14" fill="#475569" font-style="italic">${subtitle}</text>

  <!-- Axis -->
  <line x1="${plotLeft}" y1="130" x2="${plotLeft}" y2="550" stroke="#111111" stroke-width="1.5"/>
  <line x1="${plotLeft}" y1="550" x2="${plotRight}" y2="550" stroke="#111111" stroke-width="1.5"/>
  <text x="${plotLeft - 15}" y="140" text-anchor="end" font-size="12" fill="#475569">${maxAlt}m</text>
  <text x="${plotLeft - 15}" y="550" text-anchor="end" font-size="12" fill="#475569">${minAlt}m</text>
  <text x="${plotLeft - 45}" y="340" text-anchor="middle" font-size="12" fill="#334155" font-weight="700" transform="rotate(-90 ${plotLeft - 45} 340)">ELEVATION PROFILE</text>

  <!-- Area & Path -->
  <path d="${areaD}" fill="url(#area-${safeId})"/>
  <path d="${pathD}" fill="none" stroke="#b45309" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round"/>

  ${markers}
</svg>`;
}

const mapSpecs = [
  {
    file: "public/images/upper-mustang-trek-route-map.svg",
    title: "Upper Mustang Trek — Route Map",
    subtitle: "Ancient Walled City of Lo Manthang & Hidden Caves",
    waypoints: [
      { name: "Jomsom", alt: 2720 },
      { name: "Kagbeni", alt: 2810 },
      { name: "Chele", alt: 3050 },
      { name: "Geling", alt: 3570 },
      { name: "Charang", alt: 3560 },
      { name: "Lo Manthang", alt: 3840 },
    ],
  },
  {
    file: "public/images/nepal-cultural-tour-route-map.svg",
    title: "Nepal Cultural Golden Triangle — Route Map",
    subtitle: "Kathmandu Valley · Pokhara Lake · Chitwan Jungle",
    waypoints: [
      { name: "Kathmandu", alt: 1400 },
      { name: "Nagarkot", alt: 2175 },
      { name: "Pokhara", alt: 820 },
      { name: "Sarangkot", alt: 1600 },
      { name: "Chitwan", alt: 150 },
    ],
  },
  {
    file: "public/images/muktinath-janaki-pilgrimage-route-map.svg",
    title: "Muktinath to Janakpur Sacred Pilgrimage — Route Map",
    subtitle: "Sacred Vishnu Temple 3,800m & Janaki Mandir Mithila",
    waypoints: [
      { name: "Kathmandu", alt: 1400 },
      { name: "Pokhara", alt: 820 },
      { name: "Jomsom", alt: 2720 },
      { name: "Muktinath", alt: 3800 },
      { name: "Janakpur", alt: 74 },
    ],
  },
  {
    file: "public/images/upper-mustang-motorbike-tour-route-map.svg",
    title: "Upper Mustang Motorbike Expedition — Route Map",
    subtitle: "Royal Enfield Off-road Adventure to Lo Manthang",
    waypoints: [
      { name: "Pokhara", alt: 820 },
      { name: "Tatopani", alt: 1190 },
      { name: "Jomsom", alt: 2720 },
      { name: "Kagbeni", alt: 2810 },
      { name: "Ghami", alt: 3520 },
      { name: "Lo Manthang", alt: 3840 },
    ],
  },
  {
    file: "public/images/tilicho-lake-trek-route-map.svg",
    title: "Tilicho Lake & Annapurna Circuit — Route Map",
    subtitle: "World’s Highest Glacial Lake 4,919m & Thorong La 5,416m",
    waypoints: [
      { name: "Besisahar", alt: 760 },
      { name: "Chame", alt: 2670 },
      { name: "Manang", alt: 3519 },
      { name: "Siri Kharka", alt: 4060 },
      { name: "Tilicho Lake", alt: 4919 },
      { name: "Thorong La", alt: 5416 },
    ],
  },
  {
    file: "public/images/nar-phu-valley-trek-route-map.svg",
    title: "Nar Phu Valley & Kang La Pass — Route Map",
    subtitle: "Lost Tibetan Heritage Valleys of the Northern Annapurna",
    waypoints: [
      { name: "Koto", alt: 2600 },
      { name: "Meta", alt: 3560 },
      { name: "Phu Village", alt: 4080 },
      { name: "Nar Village", alt: 4110 },
      { name: "Kang La Pass", alt: 5320 },
      { name: "Ngawal", alt: 3660 },
    ],
  },
  {
    file: "public/images/patan-durbar-square-route-map.svg",
    title: "Patan Durbar Square & City of Fine Arts — Tour Map",
    subtitle: "Krishna Mandir · Golden Temple · Patan Museum",
    waypoints: [
      { name: "Hotel Pick", alt: 1350 },
      { name: "Mangal Bazaar", alt: 1380 },
      { name: "Krishna Mandir", alt: 1390 },
      { name: "Golden Temple", alt: 1395 },
      { name: "Patan Museum", alt: 1400 },
    ],
  },
  {
    file: "public/images/swayambhunath-stupa-route-map.svg",
    title: "Swayambhunath Stupa (Monkey Temple) — Tour Map",
    subtitle: "2,500-year-old Buddhist Stupa Overlooking Kathmandu",
    waypoints: [
      { name: "Kathmandu Center", alt: 1350 },
      { name: "Eastern Stairway", alt: 1375 },
      { name: "Vajra Platform", alt: 1420 },
      { name: "Main Stupa", alt: 1445 },
    ],
  },
  {
    file: "public/images/pashupatinath-temple-route-map.svg",
    title: "Pashupatinath Sacred Temple & Bagmati River — Tour Map",
    subtitle: "UNESCO World Heritage Sacred Hindu Sanctuary & Aarti Ceremony",
    waypoints: [
      { name: "Guheshwori", alt: 1370 },
      { name: "Bagmati Ghats", alt: 1360 },
      { name: "Main Temple Courtyard", alt: 1385 },
      { name: "Evening Sandhya Aarti", alt: 1365 },
    ],
  },
  {
    file: "public/images/nuwakot-durbar-tour-route-map.svg",
    title: "Historic Nuwakot 7-Story Palace — Tour Map",
    subtitle: "King Prithvi Narayan Shah’s Historic Hilltop Fortress",
    waypoints: [
      { name: "Kathmandu", alt: 1400 },
      { name: "Galchhi", alt: 580 },
      { name: "Trishuli Bazaar", alt: 600 },
      { name: "Nuwakot Durbar", alt: 980 },
    ],
  },
  {
    file: "public/images/tansen-durbar-tour-route-map.svg",
    title: "Palpa Tansen Historic Hill Town — Tour Map",
    subtitle: "Rani Mahal Taj Mahal of Nepal & Tansen Durbar",
    waypoints: [
      { name: "Pokhara", alt: 820 },
      { name: "Waling", alt: 800 },
      { name: "Tansen Bazaar", alt: 1350 },
      { name: "Srinagar Hill", alt: 1520 },
      { name: "Rani Mahal", alt: 350 },
    ],
  },
  {
    file: "public/images/muktinath-tour-route-map.svg",
    title: "Muktinath Temple & Kali Gandaki Valley — Tour Map",
    subtitle: "108 Sacred Spouts & Eternal Flame at 3,800m",
    waypoints: [
      { name: "Pokhara", alt: 820 },
      { name: "Beni", alt: 830 },
      { name: "Ghasa", alt: 2010 },
      { name: "Jomsom", alt: 2720 },
      { name: "Muktinath", alt: 3800 },
    ],
  },
  {
    file: "public/images/pathivera-tour-route-map.svg",
    title: "Pathibhara Devi Taplejung Pilgrimage — Route Map",
    subtitle: "Sacred Goddess Shrine on Eastern Himalayan Ridge 3,794m",
    waypoints: [
      { name: "Birtamod", alt: 150 },
      { name: "Ilam", alt: 1208 },
      { name: "Phidim", alt: 1180 },
      { name: "Taplejung", alt: 1820 },
      { name: "Pathibhara Devi", alt: 3794 },
    ],
  },
  {
    file: "public/images/sauraha-jungle-safari-route-map.svg",
    title: "Chitwan Sauraha Wildlife Safari — Route Map",
    subtitle: "Rapti River Canoe · Elephant Breeding Center · Deep Jungle Jeep Drive",
    waypoints: [
      { name: "Sauraha Resort", alt: 150 },
      { name: "Rapti River Canoe", alt: 145 },
      { name: "Jeep Safari Zone", alt: 160 },
      { name: "Tower Night Stay", alt: 165 },
    ],
  },
  {
    file: "public/images/upper-mustang-helicopter-tour-route-map.svg",
    title: "Upper Mustang VIP Helicopter Tour — Route Map",
    subtitle: "Direct Heli Flight from Pokhara to Walled Capital of Lo Manthang",
    waypoints: [
      { name: "Pokhara Airport", alt: 820 },
      { name: "Ghorepani Gorge", alt: 2860 },
      { name: "Dhaulagiri Pass", alt: 4200 },
      { name: "Lo Manthang Landing", alt: 3840 },
    ],
  },
  {
    file: "public/images/pokhara-adventure-package-route-map.svg",
    title: "Pokhara Ultimate Adventure Tour — Route Map",
    subtitle: "Paragliding · Zipflyer · Ultra-light · Phewa Lake Boating",
    waypoints: [
      { name: "Lakeside", alt: 820 },
      { name: "Sarangkot Launch", alt: 1600 },
      { name: "Peace Pagoda", alt: 1100 },
      { name: "Phewa Lake Landing", alt: 820 },
    ],
  },
  {
    file: "public/images/paragliding-in-sarangkot-route-map.svg",
    title: "Sarangkot Paragliding Flight — Route Map",
    subtitle: "Thermal Tandem Soaring with Machhapuchhre Views",
    waypoints: [
      { name: "Pokhara Lakeside", alt: 820 },
      { name: "Sarangkot Takeoff", alt: 1592 },
      { name: "Thermal Flight Zone", alt: 2100 },
      { name: "Phewa Lake Shore", alt: 820 },
    ],
  },
];

for (const m of mapSpecs) {
  const content = generateMapSvg(m.title, m.subtitle, m.waypoints);
  fs.writeFileSync(m.file, content, "utf8");
  console.log(`Generated SVG: ${m.file} (${content.length} bytes)`);
}

console.log("All missing assets created successfully!");
