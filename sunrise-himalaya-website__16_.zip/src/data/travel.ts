export interface Tour {
  slug: string;
  title: string;
  summary: string;
  description: string;
  image: string;
  gallery: string[];
  routeMap?: string;
  duration: string;
  difficulty?: string;
  groupSize?: string;
  maxAltitude?: string;
  bestSeason?: string;
  price: number;
  categories: string[];
  included?: string[];
  excluded?: string[];
  itinerary?: [string, string][];
}

export interface PackageItem {
  slug: string;
  title: string;
  price: string;
  days: string;
  img: string;
  places?: string[];
  difficulty?: string;
  maxAltitude?: string;
}

export interface TripItem {
  slug: string;
  title: string;
  price: string;
  off: string;
  days: string;
  places: string[];
  img: string;
}

export interface DealItem {
  slug: string;
  title: string;
  was: string;
  price: string;
  off: string;
  days: string;
  places: string[];
  img: string;
}

export interface RegionItem {
  name: string;
  title: string;
  image: string;
  packs: number;
  description: string;
}

export const allTours: Tour[] = [
  {
    slug: "everest-base-camp-trek",
    title: "Everest Base Camp Trek",
    summary: "Sherpa villages, Khumbu icefall views and the classic walk to 5,364 m.",
    description:
      "The signature Khumbu journey. We fly into Lukla, follow the Dudh Koshi through Namche Bazaar and Tengboche, acclimatise properly, and stand at Everest Base Camp before sunrise on Kala Patthar. Small groups, generous acclimatisation days and Sherpa guides who grew up on this trail.",
    image: "/images/everest-base-camp-sunrise.jpg",
    gallery: [
      "/images/everest-base-camp-sunrise.jpg",
      "/images/ebc-trek.jpg",
      "/images/everest-base-camp-12-days.jpg",
    ],
    routeMap: "/images/everest-base-camp-trek-route-map.svg",
    duration: "14 days",
    difficulty: "Challenging",
    groupSize: "2 – 12 people",
    maxAltitude: "5,545 m / Kala Patthar",
    bestSeason: "Mar – May · Sep – Nov",
    price: 2000,
    categories: ["Trekking", "Everest Region"],
    included: [
      "Airport transfers",
      "Licensed guide",
      "Porters",
      "All permits & national park fees",
      "Teahouse accommodation",
      "All meals on trek",
      "Kathmandu – Lukla – Kathmandu flights",
      "Down jacket and sleeping bag on loan",
    ],
    excluded: [
      "International flights",
      "Nepal entry visa",
      "Travel insurance",
      "Personal expenses & tips",
    ],
    itinerary: [
      [
        "Arrive in Kathmandu",
        "Welcome at Tribhuvan International Airport and trip briefing in Thamel.",
      ],
      [
        "Fly to Lukla, trek to Phakding",
        "35-minute mountain flight, then an easy 3-hour walk along the river.",
      ],
      ["Trek to Namche Bazaar", "Cross the Hillary Bridge and climb to the Sherpa capital."],
      ["Acclimatisation in Namche", "Hike to Everest View Hotel and the Sherpa Museum."],
      ["Trek to Tengboche", "Visit the largest monastery in the Khumbu at sunset."],
      ["Trek to Dingboche", "Enter the high valley below Ama Dablam."],
      ["Acclimatisation in Dingboche", "Day hike to Nangkartshang Peak, 5,083 m."],
      ["Trek to Lobuche", "Pass the memorial stupas of Thukla."],
      ["Everest Base Camp, sleep Gorak Shep", "Walk the Khumbu glacier moraine to base camp."],
      ["Kala Patthar sunrise, trek to Pheriche", "The finest Everest viewpoint on the trek."],
      ["Trek to Namche Bazaar", "Long descent back into the treeline."],
      ["Trek to Lukla", "Final trail day and celebration dinner with the crew."],
      ["Fly to Kathmandu", "Free afternoon for souvenir shopping."],
      ["Departure", "Transfer to the airport for your onward flight."],
    ],
  },
  {
    slug: "everest-three-passes-trek",
    title: "Everest Three Passes Trek",
    summary: "Kongma La, Cho La and Renjo La — the complete high circuit of the Khumbu.",
    description:
      "For strong walkers who want every viewpoint in the Khumbu: three passes above 5,300 m, Gokyo Lakes, Gokyo Ri and Everest Base Camp linked into one loop with careful acclimatisation.",
    image: "/images/everest-three-passes-trek.jpg",
    gallery: ["/images/everest-three-passes-trek.jpg", "/images/everest-region-sunset.jpg"],
    routeMap: "/images/everest-three-passes-trek-route-map.svg",
    duration: "19 days",
    difficulty: "Strenuous",
    groupSize: "2 – 8 people",
    maxAltitude: "5,545 m",
    bestSeason: "Apr – May · Oct – Nov",
    price: 2500,
    categories: ["Trekking", "Everest Region", "Adventure Tours"],
    included: [
      "Airport transfers",
      "Licensed guide",
      "Porters",
      "All permits & national park fees",
      "Teahouse accommodation",
      "All meals on trek",
      "Lukla flights",
      "Assistant guide for groups over 6",
    ],
    excluded: [
      "International flights",
      "Nepal entry visa",
      "Travel insurance",
      "Personal expenses & tips",
    ],
    itinerary: [
      ["Kathmandu arrival", "Briefing and gear check."],
      ["Fly to Lukla, trek to Phakding", "Gentle first day."],
      ["Namche Bazaar", "Climb to 3,440 m."],
      ["Acclimatisation day", "Hike to Khumjung village."],
      ["Tengboche to Dingboche", "Rhododendron forest and monastery."],
      ["Chhukung", "Approach to the first pass."],
      ["Kongma La to Lobuche", "5,535 m pass day."],
      ["Everest Base Camp", "Overnight Gorak Shep."],
      ["Kala Patthar to Dzongla", "Sunrise then traverse."],
      ["Cho La Pass to Thagnak", "Glacier crossing with fixed lines if icy."],
      ["Gokyo Lakes", "Turquoise lake basin."],
      ["Gokyo Ri and rest", "Panorama of four eight-thousanders."],
      ["Renjo La to Lumde", "Final pass of the circuit."],
      ["Thame", "Ancient trading village."],
      ["Namche to Lukla", "Two descent days."],
      ["Fly to Kathmandu", "Rest and recover."],
      ["Kathmandu heritage tour", "Guided walk of Durbar Square."],
      ["Reserve day", "Buffer for weather-delayed flights."],
      ["Departure", "Airport transfer."],
    ],
  },
  {
    slug: "gokyo-lakes-trek",
    title: "Gokyo Lakes & Gokyo Ri Trek",
    summary: "Six sacred turquoise lakes and the widest Everest panorama in the region.",
    description:
      "A quieter alternative to the base camp trail, following the Dudh Koshi to the glacial lake system of Gokyo and the sunrise viewpoint of Gokyo Ri at 5,357 m.",
    image: "/images/gokyo-lakes-trek.jpg",
    gallery: ["/images/gokyo-lakes-trek.jpg"],
    routeMap: "/images/gokyo-lake-trek-route-map.svg",
    duration: "12 days",
    difficulty: "Challenging",
    groupSize: "2 – 12 people",
    maxAltitude: "5,357 m",
    bestSeason: "Mar – May · Sep – Nov",
    price: 2350,
    categories: ["Trekking", "Everest Region"],
    included: [
      "Airport transfers",
      "Licensed guide",
      "Porters",
      "All permits & national park fees",
      "Teahouse accommodation",
      "All meals on trek",
    ],
    excluded: [
      "International flights",
      "Nepal entry visa",
      "Travel insurance",
      "Personal expenses & tips",
    ],
    itinerary: [
      ["Kathmandu arrival", "Trip briefing."],
      ["Fly Lukla, trek Phakding", "Riverside walk."],
      ["Namche Bazaar", "Sherpa capital."],
      ["Acclimatisation", "Everest View hike."],
      ["Dole", "Leave the main EBC trail."],
      ["Machhermo", "Short altitude-friendly day."],
      ["Gokyo village", "Arrive at the third lake."],
      ["Gokyo Ri and fifth lake", "Full panorama day."],
      ["Dole", "Begin descent."],
      ["Namche", "Back to the treeline."],
      ["Lukla", "Final trail day."],
      ["Fly to Kathmandu and depart", "Transfer as required."],
    ],
  },
  {
    slug: "annapurna-base-camp-trek",
    title: "Annapurna Base Camp Trek",
    summary: "Rice terraces to a snow amphitheatre ringed by 7,000 m peaks.",
    description:
      "One of the most rewarding short treks on earth: Gurung villages, the bamboo forests of the Modi Khola and a final morning inside the Annapurna Sanctuary itself.",
    image: "/images/annapurna-base-camp.webp",
    gallery: ["/images/annapurna-base-camp.webp", "/images/abc-trek.jpg"],
    routeMap: "/images/annapurna-base-camp-trek-route-map.svg",
    duration: "10 days",
    difficulty: "Moderate",
    groupSize: "2 – 14 people",
    maxAltitude: "4,130 m",
    bestSeason: "Mar – May · Oct – Dec",
    price: 1550,
    categories: ["Trekking", "Annapurna Region"],
    included: [
      "Airport transfers",
      "Licensed guide",
      "Porters",
      "All permits & national park fees",
      "Teahouse accommodation",
      "All meals on trek",
    ],
    excluded: [
      "International flights",
      "Nepal entry visa",
      "Travel insurance",
      "Personal expenses & tips",
    ],
    itinerary: [
      ["Kathmandu arrival", "Briefing."],
      ["Drive to Pokhara", "Lakeside evening."],
      ["Nayapul to Ghandruk", "Classic Gurung village."],
      ["Chhomrong", "Views of Machhapuchhre."],
      ["Bamboo", "Descend into the gorge."],
      ["Deurali", "Enter the sanctuary."],
      ["Annapurna Base Camp", "Sunset on Annapurna I."],
      ["Jhinu Danda", "Natural hot springs."],
      ["Return to Pokhara", "Free evening."],
      ["Drive to Kathmandu / depart", "Tourist coach or flight."],
    ],
  },
  {
    slug: "annapurna-circuit-trek",
    title: "Annapurna Circuit & Thorong La",
    summary: "Subtropical valleys to the arid Manang plateau and a 5,416 m pass.",
    description:
      "The great Himalayan traverse: from paddy fields to high desert, over Thorong La, then down to the pilgrimage temple of Muktinath and the Kali Gandaki gorge.",
    image: "/images/short-annapurna-circuit.webp",
    gallery: ["/images/short-annapurna-circuit.webp", "/images/annapurna-region.jpg"],
    routeMap: "/images/annapurna-circuit-trek-route-map.svg",
    duration: "15 days",
    difficulty: "Challenging",
    groupSize: "2 – 12 people",
    maxAltitude: "5,416 m / Thorong La",
    bestSeason: "Mar – May · Sep – Nov",
    price: 2150,
    categories: ["Trekking", "Annapurna Region", "Adventure Tours"],
    included: [
      "Airport transfers",
      "Licensed guide",
      "Porters",
      "All permits & national park fees",
      "Teahouse accommodation",
      "All meals on trek",
    ],
    excluded: [
      "International flights",
      "Nepal entry visa",
      "Travel insurance",
      "Personal expenses & tips",
    ],
    itinerary: [
      ["Kathmandu arrival", "Briefing."],
      ["Drive to Chame", "Long scenic jeep day."],
      ["Upper Pisang", "Pine forest and Annapurna II."],
      ["Manang via Ghyaru", "High route with the best views."],
      ["Acclimatisation in Manang", "Ice Lake or Gangapurna viewpoint."],
      ["Yak Kharka", "Short ascent day."],
      ["Thorong Phedi", "Pass base camp."],
      ["Thorong La to Muktinath", "The big crossing."],
      ["Kagbeni and Jomsom", "Windy Kali Gandaki valley."],
      ["Fly or drive to Pokhara", "Rest day."],
      ["Pokhara free day", "Boating on Phewa Lake."],
      ["Return to Kathmandu", "Tourist coach."],
      ["Heritage tour", "Patan and Bhaktapur."],
      ["Reserve day", "Weather buffer."],
      ["Departure", "Airport transfer."],
    ],
  },
  {
    slug: "manaslu-circuit-trek",
    title: "Manaslu Circuit & Larke Pass",
    summary: "Restricted-area wilderness around the eighth highest mountain.",
    description:
      "A remote teahouse circuit with Tibetan-influenced villages, few crowds and the demanding Larke La at 5,106 m. Special restricted-area permits handled in-house.",
    image: "/images/manaslu-circuit.jpg",
    gallery: ["/images/manaslu-circuit.jpg"],
    routeMap: "/images/manaslu-circuit-trek-route-map.svg",
    duration: "16 days",
    difficulty: "Strenuous",
    groupSize: "2 – 10 people",
    maxAltitude: "5,106 m",
    bestSeason: "Apr – May · Oct – Nov",
    price: 2500,
    categories: ["Trekking", "Adventure Tours"],
    included: [
      "Airport transfers",
      "Licensed guide",
      "Porters",
      "All permits & national park fees",
      "Teahouse accommodation",
      "All meals on trek",
      "Manaslu restricted area permit",
    ],
    excluded: [
      "International flights",
      "Nepal entry visa",
      "Travel insurance",
      "Personal expenses & tips",
    ],
    itinerary: [
      ["Kathmandu arrival", "Permit paperwork."],
      ["Drive to Machha Khola", "Along the Budhi Gandaki."],
      ["Jagat", "Entry to the restricted area."],
      ["Deng", "Tibetan influence begins."],
      ["Namrung", "Pine and fir forest."],
      ["Lho", "First full Manaslu view."],
      ["Samagaun", "Village below the mountain."],
      ["Acclimatisation", "Hike to Manaslu Base Camp."],
      ["Samdo", "Last permanent settlement."],
      ["Dharamsala", "Pass base."],
      ["Larke Pass to Bimthang", "Longest day of the trek."],
      ["Tilije", "Back into the forest."],
      ["Dharapani to Besisahar", "Jeep transfer."],
      ["Drive to Kathmandu", "Farewell dinner."],
      ["Reserve day", "Buffer."],
      ["Departure", "Airport transfer."],
    ],
  },
  {
    slug: "upper-mustang-tour",
    title: "Upper Mustang & Lo Manthang",
    summary: "The walled capital of the forbidden kingdom beyond the Himalaya.",
    description:
      "Ochre canyons, cave monasteries and the medieval walled city of Lo Manthang. Trek or jeep options, both with restricted-area permits and a Mustang-born guide.",
    image: "/images/upper-mustang.jpg",
    gallery: ["/images/upper-mustang.jpg", "/images/mustang-trek.jpg"],
    routeMap: "/images/upper-mustang-trek-route-map.svg",
    duration: "12 days",
    difficulty: "Moderate",
    groupSize: "2 – 10 people",
    maxAltitude: "3,840 m",
    bestSeason: "Mar – Nov (rain shadow)",
    price: 1750,
    categories: ["Mustang Region", "Cultural Tours", "Trekking"],
    included: [
      "Airport transfers",
      "Licensed guide",
      "Porters",
      "All permits & national park fees",
      "Teahouse accommodation",
      "All meals on trek",
      "Upper Mustang restricted permit (USD 500 / 10 days)",
    ],
    excluded: [
      "International flights",
      "Nepal entry visa",
      "Travel insurance",
      "Personal expenses & tips",
    ],
    itinerary: [
      ["Kathmandu arrival", "Briefing and permits."],
      ["Fly to Pokhara", "Lakeside night."],
      ["Fly to Jomsom, drive to Kagbeni", "Gateway to Mustang."],
      ["Chele", "Enter the restricted zone."],
      ["Syangboche", "Two high passes."],
      ["Ghami", "Longest mani wall in Nepal."],
      ["Tsarang", "Old royal palace."],
      ["Lo Manthang", "Arrive at the walled city."],
      ["Lo Manthang exploration", "Chhoser caves and monasteries."],
      ["Drive to Jomsom", "Scenic jeep transfer."],
      ["Fly to Pokhara", "Free afternoon."],
      ["Return to Kathmandu / depart", "Flight and transfer."],
    ],
  },
  {
    slug: "langtang-valley-trek",
    title: "Langtang Valley & Kyanjin Ri",
    summary: "Closest Himalayan valley to Kathmandu, rebuilt and welcoming.",
    description:
      "A short, beautiful trek through Tamang villages and yak pastures to Kyanjin Gompa, with an optional climb of Tserko Ri for a 360-degree glacier panorama.",
    image: "/images/langtang-valley.jpg",
    gallery: ["/images/langtang-valley.jpg"],
    routeMap: "/images/langtang-valley-route-map.svg",
    duration: "9 days",
    difficulty: "Moderate",
    groupSize: "2 – 14 people",
    maxAltitude: "4,984 m",
    bestSeason: "Mar – May · Oct – Dec",
    price: 790,
    categories: ["Trekking", "Langtang Region"],
    included: [
      "Airport transfers",
      "Licensed guide",
      "Porters",
      "All permits & national park fees",
      "Teahouse accommodation",
      "All meals on trek",
    ],
    excluded: [
      "International flights",
      "Nepal entry visa",
      "Travel insurance",
      "Personal expenses & tips",
    ],
    itinerary: [
      ["Kathmandu arrival", "Briefing."],
      ["Drive to Syabrubesi", "Mountain highway."],
      ["Lama Hotel", "Forest and langur monkeys."],
      ["Langtang village", "Memorial to the 2015 earthquake."],
      ["Kyanjin Gompa", "Cheese factory and monastery."],
      ["Tserko Ri", "Sunrise climb."],
      ["Lama Hotel", "Descend."],
      ["Syabrubesi", "Final trail day."],
      ["Drive to Kathmandu / depart", "Transfer."],
    ],
  },
  {
    slug: "kathmandu-heritage-tour",
    title: "Kathmandu Valley Heritage Tour",
    summary: "Seven UNESCO sites, three Durbar Squares, one living museum city.",
    description:
      "Kathmandu, Patan and Bhaktapur Durbar Squares, Swayambhunath, Boudhanath, Pashupatinath and Changu Narayan with a heritage historian guide and a private vehicle.",
    image: "/images/kathmandu-durbar-square-photo.jpg",
    gallery: [
      "/images/kathmandu-durbar-square-photo.jpg",
      "/images/patan-durbar-square.jpg",
      "/images/bhaktapur-durbar-square.jpg",
    ],
    routeMap: "/images/nepal-cultural-tour-route-map.svg",
    duration: "4 days",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "1,400 m",
    bestSeason: "All year",
    price: 390,
    categories: ["Cultural Tours"],
    included: [
      "Private air-conditioned vehicle with driver",
      "Heritage guide for all sightseeing days",
      "All monument entry fees",
      "3 nights boutique hotel with breakfast",
      "Airport transfers",
    ],
    excluded: ["International flights", "Lunch and dinner", "Personal expenses", "Tips"],
    itinerary: [
      ["Arrival and Thamel walk", "Evening orientation walk."],
      ["Swayambhunath and Kathmandu Durbar Square", "Monkey temple at sunrise."],
      ["Patan, Bhaktapur and Changu Narayan", "Newari craft and architecture."],
      ["Pashupatinath, Boudhanath, departure", "Morning rituals then transfer."],
    ],
  },
  {
    slug: "muktinath-janaki-pilgrimage",
    title: "Muktinath & Janaki Temple Pilgrimage",
    summary: "Pashupatinath, Muktinath and Janakpur on one guided pilgrimage.",
    description:
      "A dedicated darshan itinerary covering Pashupatinath, Manakamana, Muktinath at 3,710 m and the Janaki Temple in Janakpur, with puja arrangements and priest coordination.",
    image: "/images/pilgrims-guide-muktinath-kali-gandaki.jpg",
    gallery: [
      "/images/pilgrims-guide-muktinath-kali-gandaki.jpg",
      "/images/muktinath-temple.jpg",
      "/images/janaki-mandir-janakpur.jpg",
    ],
    routeMap: "/images/muktinath-janaki-pilgrimage-route-map.svg",
    duration: "8 days",
    difficulty: "Easy",
    groupSize: "2 – 20 people",
    maxAltitude: "3,710 m",
    bestSeason: "Feb – Nov",
    price: 720,
    categories: ["Religious Tours", "Cultural Tours"],
    included: [
      "All ground transport and domestic flight Pokhara – Jomsom",
      "Hotel accommodation with breakfast",
      "Pilgrimage guide and puja coordination",
      "Temple entry and cable car tickets",
    ],
    excluded: ["Offerings and donations", "Lunch and dinner", "Personal expenses", "Insurance"],
    itinerary: [
      ["Kathmandu arrival", "Evening aarati at Pashupatinath."],
      ["Kathmandu temples", "Budhanilkantha and Guhyeshwari."],
      ["Manakamana and Pokhara", "Cable car darshan."],
      ["Fly to Jomsom, drive to Muktinath", "108 water spouts."],
      ["Return to Pokhara", "Rest day."],
      ["Drive to Janakpur", "Overnight in Mithila."],
      ["Janaki Temple", "Morning darshan and Mithila art."],
      ["Return and departure", "Flight to Kathmandu."],
    ],
  },
  {
    slug: "chitwan-bardia-wildlife-safari",
    title: "Chitwan & Bardia Wildlife Safari",
    summary: "One-horned rhino, gharial and a real chance of Bengal tiger.",
    description:
      "Jeep safari, canoe trip and guided jungle walks in Chitwan National Park, then the wilder, quieter Bardia in the far west for tiger tracking with expert naturalists.",
    image: "/images/sauraha-jungle-safari.jpg",
    gallery: [
      "/images/sauraha-jungle-safari.jpg",
      "/images/chitwan-national-park.jpg",
      "/images/bardia-national-park.jpg",
    ],
    routeMap: "/images/chitwan-safari-tour-route-map.svg",
    duration: "7 days",
    difficulty: "Easy",
    groupSize: "2 – 12 people",
    maxAltitude: "415 m",
    bestSeason: "Oct – Apr",
    price: 650,
    categories: ["Wildlife Tours", "Adventure Tours"],
    included: [
      "Jungle lodge accommodation with all meals",
      "Park entry permits and naturalist guide",
      "Jeep safari, canoe ride and jungle walk",
      "Tharu cultural programme",
      "All ground transport",
    ],
    excluded: ["Flights", "Drinks", "Insurance", "Tips"],
    itinerary: [
      ["Drive to Chitwan", "Sunset on the Rapti River."],
      ["Chitwan full day", "Canoe, jeep safari and elephant breeding centre."],
      ["Fly to Nepalgunj, drive to Bardia", "Transfer day."],
      ["Bardia jeep safari", "Full day in the core area."],
      ["Tiger tracking on foot", "With two armed naturalists."],
      ["Karnali river day", "Gharial and dolphin spotting."],
      ["Return to Kathmandu", "Flight and transfer."],
    ],
  },
  {
    slug: "everest-helicopter-tour",
    title: "Everest Base Camp Helicopter Tour",
    summary: "Four hours from Kathmandu to breakfast at 3,880 m and back.",
    description:
      "A private or shared charter over the Khumbu with a landing at Kala Patthar viewpoint and breakfast at Everest View Hotel — the whole Everest region in a single morning.",
    image: "/images/mountain-flight.jpg",
    gallery: ["/images/mountain-flight.jpg", "/images/everest-base-camp-helicopter-tour.jpg"],
    routeMap: "/images/ebc-helicopter-tour-route-map.svg",
    duration: "1 day (4 – 5 hrs)",
    difficulty: "Easy",
    groupSize: "1 – 5 people",
    maxAltitude: "5,545 m (landing)",
    bestSeason: "All year, weather permitting",
    price: 1900,
    categories: ["Helicopter Tours", "Everest Region", "Adventure Tours"],
    included: [
      "Shared helicopter seat with all airport taxes",
      "Breakfast at Everest View Hotel",
      "Kala Patthar landing (weather and weight permitting)",
      "Hotel transfers in Kathmandu",
      "Oxygen supply on board",
    ],
    excluded: ["Private charter surcharge", "Insurance", "Personal expenses"],
    itinerary: [
      [
        "Kathmandu – Lukla – Kala Patthar – Kathmandu",
        "05:45 pick-up, refuel at Lukla, landing at Kala Patthar, breakfast at Syangboche, back in Kathmandu by 10:30.",
      ],
    ],
  },
  {
    slug: "kailash-mansarovar-yatra",
    title: "Kailash Mansarovar Yatra",
    summary: "The sacred kora around Mount Kailash and holy Lake Mansarovar.",
    description:
      "A fully supported overland yatra from Kathmandu via Kerung, with the three-day parikrama over Dolma La at 5,630 m, oxygen support and a dedicated Tibetan-speaking guide.",
    image: "/images/kailash-mansarovar-tour.jpg",
    gallery: ["/images/kailash-mansarovar-tour.jpg"],
    routeMap: "/images/kailash-mansarovar-yatra-route-map.svg",
    duration: "14 days",
    difficulty: "Strenuous",
    groupSize: "6 – 25 people",
    maxAltitude: "5,630 m / Dolma La",
    bestSeason: "May – Sep",
    price: 2450,
    categories: ["Kailash Mansarovar Tours", "Religious Tours"],
    included: [
      "Tibet travel permit and China group visa",
      "All overland transport in Tibet",
      "Hotel and guesthouse accommodation",
      "All vegetarian meals with Nepali cook",
      "Support truck, oxygen cylinders and gamow bag",
      "Nepali and Tibetan guides",
    ],
    excluded: [
      "Horse and porter during kora",
      "Insurance",
      "Emergency evacuation",
      "Personal expenses",
    ],
    itinerary: [
      ["Kathmandu arrival", "Yatra briefing."],
      ["Kathmandu preparation day", "Visa processing."],
      ["Drive to Syabrubesi", "Border approach."],
      ["Kerung border crossing", "Immigration formalities."],
      ["Acclimatisation in Kerung", "Short hikes."],
      ["Drive to Saga", "High plateau."],
      ["Drive to Mansarovar", "Evening puja by the lake."],
      ["Mansarovar to Darchen", "Kailash first sight."],
      ["Kora day 1: Yamdwar to Dirapuk", "North face of Kailash."],
      ["Kora day 2: Dolma La to Zuthulpuk", "The hardest day."],
      ["Kora day 3 and drive to Saga", "Complete the parikrama."],
      ["Drive to Kerung", "Descend."],
      ["Return to Kathmandu", "Farewell dinner."],
      ["Departure", "Airport transfer."],
    ],
  },
  {
    slug: "upper-mustang-jeep-tour",
    title: "Upper Mustang Jeep Tour",
    summary:
      "Drive the raw, high-desert trail to Lo Manthang by 4x4 — the walled city, cave monasteries and canyons of Mustang without the multi-day walk.",
    description:
      "Drive the raw, high-desert trail to Lo Manthang by 4x4 — the walled city, cave monasteries and canyons of Mustang without the multi-day walk. A guided experience through Mustang, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/upper-mustang-jeep-tour.webp",
    gallery: ["/images/upper-mustang-jeep-tour.webp"],
    routeMap: "/images/upper-mustang-jeep-tour-route-map.svg",
    duration: "7 days",
    difficulty: "Easy",
    groupSize: "1 – 10 people",
    maxAltitude: "3,840 m",
    bestSeason: "All year",
    price: 2800,
    categories: ["Adventure Tours", "Mustang Region"],
    included: [
      "Private air-conditioned vehicle with driver",
      "Government-licensed English speaking guide",
      "All entry fees and permits mentioned in the itinerary",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Lunch and dinner",
      "Personal expenses and tips",
      "Travel insurance",
      "International/domestic flights unless noted",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Upper Mustang Jeep Tour — day 1",
        "Continue the journey through Mustang, following the planned route with your guide.",
      ],
      [
        "Upper Mustang Jeep Tour — day 2",
        "Continue the journey through Mustang, following the planned route with your guide.",
      ],
      [
        "Upper Mustang Jeep Tour — day 3",
        "Drive the raw, high-desert trail to Lo Manthang by 4x4 — the walled city, cave monasteries and canyons of Mustang without the multi-day walk.",
      ],
      [
        "Upper Mustang Jeep Tour — day 4",
        "Continue the journey through Mustang, following the planned route with your guide.",
      ],
      [
        "Upper Mustang Jeep Tour — day 5",
        "Continue the journey through Mustang, following the planned route with your guide.",
      ],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "upper-mustang-motorbike-tour",
    title: "Upper Mustang Motorbike Tour",
    summary:
      "Ride the windswept trail to the forbidden kingdom of Lo Manthang on two wheels — river crossings, canyons and Tibetan-style villages en route.",
    description:
      "Ride the windswept trail to the forbidden kingdom of Lo Manthang on two wheels — river crossings, canyons and Tibetan-style villages en route. A guided experience through Mustang, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/upper-mustang-motorbike-tour.jpg",
    gallery: ["/images/upper-mustang-motorbike-tour.jpg"],
    routeMap: "/images/upper-mustang-motorbike-tour-route-map.svg",
    duration: "7 days",
    difficulty: "Moderate",
    groupSize: "1 – 10 people",
    maxAltitude: "3,840 m",
    bestSeason: "All year",
    price: 4000,
    categories: ["Adventure Tours", "Mustang Region"],
    included: [
      "Private air-conditioned vehicle with driver",
      "Government-licensed English speaking guide",
      "All entry fees and permits mentioned in the itinerary",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Lunch and dinner",
      "Personal expenses and tips",
      "Travel insurance",
      "International/domestic flights unless noted",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Upper Mustang Motorbike Tour — day 1",
        "Continue the journey through Mustang, following the planned route with your guide.",
      ],
      [
        "Upper Mustang Motorbike Tour — day 2",
        "Continue the journey through Mustang, following the planned route with your guide.",
      ],
      [
        "Upper Mustang Motorbike Tour — day 3",
        "Ride the windswept trail to the forbidden kingdom of Lo Manthang on two wheels — river crossings, canyons and Tibetan-style villages en route.",
      ],
      [
        "Upper Mustang Motorbike Tour — day 4",
        "Continue the journey through Mustang, following the planned route with your guide.",
      ],
      [
        "Upper Mustang Motorbike Tour — day 5",
        "Continue the journey through Mustang, following the planned route with your guide.",
      ],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "ama-dablam-expedition",
    title: "Ama Dablam Expedition",
    summary:
      "The Matterhorn of the Himalayas — a technical, breathtaking climb for seasoned alpinists seeking their first 6000m summit.",
    description:
      "Ama Dablam is routinely called 'the Matterhorn of the Himalayas' — a striking, technical peak that, unlike most 6,000m Nepali summits, actually requires real climbing skill: fixed ropes, jumaring, exposed rock and ice sections, and three high camps perched on genuinely dramatic terrain. It's a serious step up from trekking, and a common 'first 6,000er' for climbers with some prior mountaineering background looking to progress toward 7,000m and 8,000m objectives. The approach follows the same Khumbu trail as Everest Base Camp as far as Pangboche, before branching off to Ama Dablam Base Camp (4,600 m) — meaning you get the classic Namche-Tengboche trekking experience as a warm-up before the climbing itself begins. From Base Camp, the route climbs a broad ridge to Camp I (5,700 m), a narrow, exposed ridge to Camp II (6,000 m) below the famous hanging glacier (the 'Dablam'), and a final steep rock/ice section to Camp III (6,300 m) before the summit push. We build substantial contingency into the 30-day schedule — roughly a week of buffer for weather windows and multiple rotations for acclimatization — because summit success on this mountain depends far more on picking the right weather day than on raw climbing ability. Our IFMGA-certified Sherpa team fixes rope, manages camp logistics, and makes the final go/no-go call on summit day together with you.",
    image: "/images/ama-dablam-peak.png",
    gallery: ["/images/ama-dablam-peak.png"],
    routeMap: "/images/ama-dablam-expedition-route-map.svg",
    duration: "30 Days",
    difficulty: "Extreme",
    groupSize: "2–8 climbers, with dedicated 1:1 climbing Sherpa support",
    maxAltitude: "6,812 m (Summit)",
    bestSeason: "Late Sept–Nov (Autumn, primary season) & Apr–May (Spring)",
    price: 5400,
    categories: ["Trekking", "Everest Region", "Adventure Tours"],
    included: [
      "Airport pick-up and drop-off by private vehicle",
      "Kathmandu hotel accommodation on bed & breakfast basis (before/after the expedition)",
      "All meals during the trek and at Base Camp (dedicated expedition cook and kitchen crew at Base Camp)",
      "Teahouse/lodge accommodation on the approach trek; quality expedition tents at Base Camp and high camps",
      "Domestic flights: Kathmandu–Lukla–Kathmandu",
      "IFMGA/UIAGM-certified climbing guide plus dedicated 1:1 climbing Sherpa per client",
      "Fixed rope, ice screws, snow bars and other group technical climbing equipment for the route",
      "Porter and yak support for Base Camp equipment",
      "NMA (Nepal Mountaineering Association) expedition royalty/permit",
      "Sagarmatha National Park entry permit and Khumbu Rural Municipality entry permit",
      "Base Camp medical kit, oxygen cylinder and mask/regulator held in reserve for emergency use",
      "All government and local taxes, VAT, and office service charges",
      "Summit certificate and farewell dinner in Kathmandu",
    ],
    excluded: [
      "International airfare to/from Kathmandu",
      "Nepal entry visa fee (available on arrival — approx. USD 30 for 15 days)",
      "Travel, medical and high-altitude climbing insurance, including helicopter evacuation and rescue cover up to 7,000 m (mandatory — we can help you arrange this)",
      "Personal climbing gear (harness, crampons, ice axe, ascender/descender, climbing helmet, mountaineering boots — rental available in Kathmandu, but well-fitted personal boots are strongly recommended)",
      "Personal oxygen use beyond the emergency reserve cylinder (rarely needed on Ama Dablam but available on request at extra cost)",
      "Personal climbing Sherpa's summit bonus (customary, typically $500–1,000, discussed and agreed before the climb)",
      "Hot showers, Wi-Fi/internet and battery charging fees at teahouses on the approach trek",
      "Tips for guides, Sherpas, porters and Base Camp kitchen staff (a significant and expected part of expedition culture — budget $300–500 per climber)",
      "Personal expenses: souvenirs, extra snacks, laundry, etc.",
      "Any costs from itinerary extension due to weather, illness, or a delayed summit window beyond the built-in contingency days",
      "Kathmandu sightseeing tours and monument entrance fees (available as an easy add-on)",
    ],
    itinerary: [
      [
        "Arrival in Kathmandu",
        "Airport pickup and hotel transfer, meet your expedition leader and Sherpa team.",
      ],
      [
        "Kathmandu — permits, briefing & equipment check",
        "A full day sorting NMA expedition permits, insurance verification, and a thorough personal-gear check — anything missing gets rented or bought in Thamel's mountaineering shops before you fly.",
      ],
      [
        "Fly to Lukla, trek to Phakding",
        "The short mountain flight into Lukla, then an easy first walking day to Phakding.",
      ],
      [
        "Phakding to Namche Bazaar",
        "Into Sagarmatha National Park and up to the Khumbu's largest town, Namche Bazaar.",
      ],
      [
        "Acclimatization day — Namche Bazaar",
        "A hike up to the Everest View Hotel or Khumjung, then back down to sleep at Namche.",
      ],
      [
        "Namche to Tengboche",
        "Ama Dablam itself becomes a constant, dominating presence on the skyline from here on.",
      ],
      [
        "Tengboche to Pangboche",
        "A short day to Pangboche, home to the oldest monastery in the Khumbu and the last real village before Base Camp.",
      ],
      [
        "Pangboche to Ama Dablam Base Camp",
        "Leaving the main EBC trail, we climb directly toward the mountain to Base Camp itself, arriving beneath the imposing southwest face.",
      ],
      [
        "Base Camp — rest, gear sort & puja ceremony",
        "A traditional Buddhist puja ceremony asking the mountain's permission for safe passage — a genuine ritual our Sherpa team takes seriously, and one every climber is expected to attend before setting foot on the route.",
      ],
      [
        "Acclimatization rotation — Base Camp to Camp I and back",
        "First rotation onto the mountain proper — a broad, moderately technical ridge to Camp I, testing gear and fixed-rope technique before returning to Base Camp to sleep.",
      ],
      [
        "Rest day at Base Camp",
        "Recovery day — this is where the expedition's flexible buffer time starts to matter.",
      ],
      [
        "Rotation — Base Camp to Camp I, sleep at Camp I",
        "A carry and sleep rotation, caching gear and building tolerance to the altitude at Camp I.",
      ],
      [
        "Camp I to Camp II and back to Base Camp",
        "The narrow, exposed 'Yellow Tower' ridge section leading to Camp II — the most technically demanding terrain below the summit push itself.",
      ],
      [
        "Rest & recovery days at Base Camp",
        "Two to three days of rest, weather monitoring, and forecast review with the climbing Sherpa team.",
      ],
      [
        "Second rotation — Base Camp to Camp I",
        "A stronger, faster second rotation now that bodies are properly acclimatized.",
      ],
      [
        "Camp I to Camp II",
        "Sleeping at Camp II, beneath the mountain's famous hanging glacier, the 'Dablam' itself.",
      ],
      [
        "Camp II to Camp III",
        "A short but intense climbing day up steep, technical terrain to the final camp before the summit.",
      ],
      [
        "Summit push",
        "A pre-dawn departure from Camp III for the summit itself, along exposed snow ridges and the final rock step, then descent to Camp II or all the way to Base Camp depending on conditions and energy levels.",
      ],
      [
        "Contingency & weather buffer days",
        "Up to 5 built-in contingency days for poor weather, illness, or a second summit attempt — the single most important reason this expedition runs a full 30 days rather than a tight 20.",
      ],
      [
        "Base Camp to Pangboche",
        "Breaking Base Camp and descending back into the trekking trail network.",
      ],
      [
        "Pangboche to Namche Bazaar",
        "Retracing the trail back toward Namche, with a noticeable improvement in air and appetite.",
      ],
      [
        "Namche to Lukla",
        "The final trekking day, and a celebratory dinner with the full climbing and support team.",
      ],
      [
        "Fly Lukla to Kathmandu",
        "Morning flight back to the capital; certificates and a farewell dinner in the evening.",
      ],
      [
        "Final departure",
        "Transfer to Tribhuvan International Airport for your onward international flight.",
      ],
    ],
  },
  {
    slug: "gosaikunda-trek",
    title: "Gosaikunda Lake Trek",
    summary:
      "A sacred high-altitude lake complex above Dhunche, revered by Hindu pilgrims and trekkers alike — crossed via the Lauribina La pass.",
    description:
      "Gosaikunda is one of Nepal's most sacred alpine lakes — a glacier-fed jewel at 4,380 m in the Langtang region, believed by Hindus to have been created by Shiva's trident and by Buddhists to be a place of deep spiritual power. Thousands of pilgrims climb here every August for Janai Purnima, but for most of the year the trail is quiet, and that's when it's at its best for trekking. The route climbs steadily out of Dhunche through rhododendron and oak forest to Sing Gompa, a small village known for its yak-cheese factory, before breaking above the treeline to a chain of high alpine lakes culminating in Gosaikunda itself. The most physically demanding stretch is the Lauribina La pass at 4,610 m, crossed on the way out toward Helambu — it's a long, cold morning, but nothing that requires technical skill. This is a shorter, more affordable alternative to the big-name treks, and a genuinely good fit for trekkers with 8–9 days who still want a real high-altitude pass and a properly sacred destination, not just a viewpoint.",
    image: "/images/gosaikunda-lake.jpg",
    gallery: ["/images/gosaikunda-lake.jpg"],
    routeMap: "/images/gosaikunda-trek-route-map.svg",
    duration: "8 Days",
    difficulty: "Moderate",
    groupSize: "2–12 (private & tailor-made groups also arranged)",
    maxAltitude: "4,610 m (Lauribina La Pass) · 4,380 m (Gosaikunda Lake)",
    bestSeason:
      "Mar–May (Spring) & Sept–Nov (Autumn), plus the Aug full-moon Janai Purnima festival",
    price: 1850,
    categories: ["Trekking", "Langtang Region"],
    included: [
      "Airport pick-up and drop-off by private vehicle",
      "2 nights in a 3-star Kathmandu hotel on bed & breakfast basis",
      "All meals (breakfast, lunch, dinner) during the trek, tea/coffee included",
      "Teahouse/lodge accommodation for all nights on the trail",
      "Private vehicle transfers Kathmandu–Dhunche and Chisapani–Kathmandu",
      "Government-licensed, English-speaking trekking guide",
      "Porter service (1 porter per 2 trekkers, 12–15 kg limit per trekker's bag)",
      "Guide & porter salary, insurance, meals, accommodation and equipment",
      "Langtang National Park entry permit",
      "TIMS (Trekkers' Information Management System) card",
      "Comprehensive first-aid medical kit (carried by the guide)",
      "All government and local taxes, VAT, and office service charges",
      "Farewell dinner in Kathmandu",
    ],
    excluded: [
      "International airfare to/from Kathmandu",
      "Nepal entry visa fee (available on arrival — approx. USD 30 for 15 days)",
      "Travel & medical insurance, including emergency evacuation cover (mandatory)",
      "Personal trekking gear (sleeping bag, down jacket, trekking poles, boots — rental available in Kathmandu)",
      "Hot showers, Wi-Fi/internet, and battery charging fees at teahouses",
      "Bottled/boiled water and all drinks other than plain tea/coffee at meals",
      "Tips for your guide and porter (customary — budget roughly $100–150 total per trekker)",
      "Personal expenses: souvenirs, extra snacks, laundry, etc.",
      "Any costs from itinerary changes due to weather, illness, or road closure",
    ],
    itinerary: [
      [
        "Arrival in Kathmandu",
        "Airport pickup and transfer to your hotel. Evening briefing with your guide to go over permits, gear, and the days ahead.",
      ],
      [
        "Drive to Dhunche",
        "A scenic mountain drive out of the Kathmandu Valley, following the Trishuli river before climbing into the Langtang National Park gateway town of Dhunche.",
      ],
      [
        "Dhunche to Sing Gompa (Chandanbari)",
        "A steady forest climb through oak and rhododendron. Sing Gompa is home to Nepal's first cheese factory, still producing yak cheese today, and a small monastery worth a look before dinner.",
      ],
      [
        "Sing Gompa to Gosaikunda",
        "The trail breaks above the treeline and climbs past a string of smaller lakes — Saraswati Kunda, Bhairav Kunda — before reaching Gosaikunda itself, ringed by jagged peaks and, in season, still holding winter ice at its edges.",
      ],
      [
        "Gosaikunda over Lauribina La to Ghopte",
        "The trek's high point — a cold, early start to cross Lauribina La before cloud builds. The descent on the far side is loose and rocky in places, and this is the one day we ask trekkers to take slowly regardless of fitness.",
      ],
      [
        "Ghopte to Kutumsang",
        "A long, welcome descent through forest with the air thickening noticeably. Kutumsang is a friendly Tamang village and a good spot to properly rest your legs.",
      ],
      [
        "Kutumsang to Chisapani, drive to Kathmandu",
        "A final ridge walk to Chisapani, from where a vehicle collects you for the drive back into Kathmandu. Farewell dinner in the evening.",
      ],
      [
        "Final departure",
        "Free morning, transfer to Tribhuvan International Airport for your onward flight, or extend into a Kathmandu Valley sightseeing add-on.",
      ],
    ],
  },
  {
    slug: "mardi-himal-trek",
    title: "Mardi Himal Trek",
    summary:
      "An off-the-beaten-path ridge walk to a close-up viewpoint of Machhapuchhre (Fishtail) — quieter trails, big Annapurna views.",
    description:
      "Mardi Himal is the trek we recommend most often to people who want a genuine high-altitude Himalayan experience but only have a week to spare and don't want to share the trail with hundreds of other trekkers. It sat largely unknown until around 2012 and still carries a fraction of the traffic of Annapurna Base Camp, despite running almost parallel to it. The route climbs a narrow forested ridge — rhododendron and moss-draped oak lower down, then increasingly stark and open — straight toward Machhapuchhre (Fishtail, 6,993 m), which looms close enough at High Camp that it feels like you could reach out and touch it. The final push to the Mardi Himal viewpoint at 4,500 m opens onto a genuinely wide panorama: Annapurna South, Hiunchuli and the Annapurna Sanctuary peaks all in one sweep. Because it's a ridge trek with no side valleys to get lost in, and no technical terrain, this is a solid choice for a strong first Himalayan trek — the main challenge is the altitude gain in the final two days, which we manage with a careful pace rather than pushing straight through.",
    image: "/images/mardi-himal-trek.webp",
    gallery: ["/images/mardi-himal-trek.webp"],
    routeMap: "/images/mardi-himal-trek-route-map.svg",
    duration: "9 Days",
    difficulty: "Moderate",
    groupSize: "2–12 (private & tailor-made groups also arranged)",
    maxAltitude: "4,500 m (Mardi Himal Base Camp viewpoint)",
    bestSeason: "Mar–May (Spring) & Sept–Dec (Autumn/early Winter)",
    price: 1200,
    categories: ["Trekking", "Annapurna Region"],
    included: [
      "Airport pick-up and drop-off by private vehicle",
      "2 nights in a 3-star Kathmandu hotel and 1 night in Pokhara on bed & breakfast basis",
      "All meals (breakfast, lunch, dinner) during the trek, tea/coffee included",
      "Teahouse/lodge accommodation for all nights on the trail",
      "Kathmandu–Pokhara–Kathmandu transport (tourist bus or flight, as arranged)",
      "Government-licensed, English-speaking trekking guide",
      "Porter service (1 porter per 2 trekkers, 12–15 kg limit per trekker's bag)",
      "Guide & porter salary, insurance, meals, accommodation and equipment",
      "Annapurna Conservation Area Permit (ACAP)",
      "TIMS (Trekkers' Information Management System) card",
      "Comprehensive first-aid medical kit (carried by the guide)",
      "All government and local taxes, VAT, and office service charges",
      "Farewell dinner in Kathmandu",
    ],
    excluded: [
      "International airfare to/from Kathmandu",
      "Nepal entry visa fee (available on arrival — approx. USD 30 for 15 days)",
      "Travel & medical insurance, including emergency evacuation cover (mandatory)",
      "Personal trekking gear (sleeping bag, down jacket, trekking poles, boots — rental available in Kathmandu/Pokhara)",
      "Hot showers, Wi-Fi/internet, and battery charging fees at teahouses",
      "Bottled/boiled water and all drinks other than plain tea/coffee at meals",
      "Tips for your guide and porter (customary — budget roughly $100–150 total per trekker)",
      "Personal expenses: souvenirs, extra snacks, laundry, etc.",
      "Kathmandu/Pokhara sightseeing tours and monument entrance fees (available as an easy add-on)",
    ],
    itinerary: [
      [
        "Arrival in Kathmandu",
        "Airport pickup, hotel check-in, and an evening trip briefing with your guide.",
      ],
      [
        "Drive/fly to Pokhara",
        "A scenic day either by road along the Trishuli and Marshyangdi valleys, or a short mountain flight, arriving in the lakeside town of Pokhara by afternoon.",
      ],
      [
        "Drive to Kande, trek to Forest Camp",
        "A short drive to the trailhead at Kande, then a steep initial climb via Australian Camp before the trail narrows onto the forested ridge proper.",
      ],
      [
        "Forest Camp to Low Camp",
        "A shorter, steadier day through moss-draped rhododendron forest — good acclimatization pacing before the terrain opens up above.",
      ],
      [
        "Low Camp to High Camp",
        "The forest thins out and Machhapuchhre appears directly ahead, startlingly close. High Camp itself sits right on the open ridge with unobstructed mountain views from the dining room window.",
      ],
      [
        "High Camp to Mardi Himal viewpoint, back to Low Camp",
        "A pre-dawn start for the viewpoint at 4,500 m, timed for sunrise light on Machhapuchhre, Annapurna South and Hiunchuli. We descend the same day, sleeping lower for better recovery.",
      ],
      [
        "Low Camp to Siding village, drive to Pokhara",
        "A different descent route through Siding, a traditional Gurung village well off the main trekking trail, followed by a short drive back into Pokhara.",
      ],
      [
        "Drive/fly to Kathmandu",
        "Return to Kathmandu, with the afternoon free to explore Thamel. Farewell dinner in the evening.",
      ],
      ["Final departure", "Transfer to Tribhuvan International Airport for your onward flight."],
    ],
  },
  {
    slug: "kailash-mansarovar-overland",
    title: "Kailash Mansarovar Yatra — Nepal Overland",
    summary:
      "Drive overland from Kathmandu via Kerung across the Tibetan plateau to Lake Manasarovar and complete the sacred Kailash kora.",
    description:
      "Drive overland from Kathmandu via Kerung across the Tibetan plateau to Lake Manasarovar and complete the sacred Kailash kora. A guided experience through Tibet – Kailash Mansarovar, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/kailash-mansarovar-tour.jpg",
    gallery: ["/images/kailash-mansarovar-tour.jpg"],
    routeMap: "/images/kailash-mansarovar-overland-route-map.svg",
    duration: "14 days",
    difficulty: "Challenging",
    groupSize: "2 – 20 people",
    maxAltitude: "5,630 m",
    bestSeason: "May – Sep",
    price: 2500,
    categories: ["Religious Tours", "Kailash Mansarovar Tours"],
    included: [
      "All ground transport and permits as per itinerary",
      "Hotel/guesthouse accommodation on the route",
      "Experienced pilgrimage guide",
      "Puja and ritual coordination at key sites",
    ],
    excluded: [
      "International flights and visa fees",
      "Travel and high-altitude insurance",
      "Personal expenses and tips",
      "Alcoholic and bottled drinks",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Kailash Mansarovar Yatra — Nepal Overland — day 1",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — Nepal Overland — day 2",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — Nepal Overland — day 3",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — Nepal Overland — day 4",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — Nepal Overland — day 5",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — Nepal Overland — day 6",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — Nepal Overland — day 7",
        "Drive overland from Kathmandu via Kerung across the Tibetan plateau to Lake Manasarovar and complete the sacred Kailash kora.",
      ],
      [
        "Kailash Mansarovar Yatra — Nepal Overland — day 8",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — Nepal Overland — day 9",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — Nepal Overland — day 10",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — Nepal Overland — day 11",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — Nepal Overland — day 12",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "kailash-mansarovar-darshan",
    title: "Kailash Mansarovar Darshan — Fly-in",
    summary:
      "A faster fly-in darshan for pilgrims short on time — Manasarovar puja and a Kailash parikrama viewpoint without the long overland drive.",
    description:
      "A faster fly-in darshan for pilgrims short on time — Manasarovar puja and a Kailash parikrama viewpoint without the long overland drive. A guided experience through Tibet – Kailash Mansarovar, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/kailash-mansarovar-darshan-flyin.jpg",
    gallery: ["/images/kailash-mansarovar-darshan-flyin.jpg"],
    routeMap: "/images/kailash-mansarovar-darshan-flyin-route-map.svg",
    duration: "10 days",
    difficulty: "Moderate",
    groupSize: "2 – 20 people",
    maxAltitude: "5,630 m",
    bestSeason: "May – Sep",
    price: 1500,
    categories: ["Religious Tours", "Kailash Mansarovar Tours"],
    included: [
      "All ground transport and permits as per itinerary",
      "Hotel/guesthouse accommodation on the route",
      "Experienced pilgrimage guide",
      "Puja and ritual coordination at key sites",
    ],
    excluded: [
      "International flights and visa fees",
      "Travel and high-altitude insurance",
      "Personal expenses and tips",
      "Alcoholic and bottled drinks",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Kailash Mansarovar Darshan — Fly-in — day 1",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Darshan — Fly-in — day 2",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Darshan — Fly-in — day 3",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Darshan — Fly-in — day 4",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Darshan — Fly-in — day 5",
        "A faster fly-in darshan for pilgrims short on time — Manasarovar puja and a Kailash parikrama viewpoint without the long overland drive.",
      ],
      [
        "Kailash Mansarovar Darshan — Fly-in — day 6",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Darshan — Fly-in — day 7",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Darshan — Fly-in — day 8",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "tilicho-lake-trek",
    title: "Tilicho Lake Trek",
    summary:
      "Stand beside one of the highest lakes of its size on Earth — a dramatic side trip off the classic Annapurna Circuit route.",
    description:
      "Tilicho Lake sits at 4,919 m below the Grand Barrier wall of the Annapurna range, and is generally cited as one of the highest lakes of its size anywhere on Earth. It's a side branch off the classic Annapurna Circuit rather than a trek in its own right — most trekkers who make it here are already deep into circuit territory — but we run it as a dedicated itinerary for people who want the lake specifically, without committing to the full three-week circuit. We use jeep transport for the lower Marsyangdi valley sections, which are increasingly road-affected anyway, to put more of your time into the high country: Manang, Khangsar, and the exposed, landslide-prone trail along the base of the Grand Barrier to the lake itself. The last stretch to Tilicho is genuinely dramatic — a narrow traverse with the lake's glacial-blue water suddenly filling the whole view. This itinerary turns back toward Pokhara after the lake rather than continuing over Thorong La to Muktinath, which keeps the maximum altitude at Tilicho itself and avoids the additional demands of the pass — ask us about combining both if you have more time and want the complete circuit experience.",
    image: "/images/annapurna-region.jpg",
    gallery: ["/images/annapurna-region.jpg"],
    routeMap: "/images/tilicho-lake-trek-route-map.svg",
    duration: "14 Days",
    difficulty: "Challenging",
    groupSize: "2–10 (private & tailor-made groups also arranged)",
    maxAltitude: "4,919 m (Tilicho Lake)",
    bestSeason: "Mar–May (Spring) & Sept–Nov (Autumn)",
    price: 2200,
    categories: ["Trekking", "Annapurna Region"],
    included: [
      "Airport pick-up and drop-off by private vehicle",
      "2 nights in a 3-star Kathmandu hotel and 2 nights in Pokhara on bed & breakfast basis",
      "All meals (breakfast, lunch, dinner) during the trek, tea/coffee included",
      "Teahouse/lodge accommodation for all nights on the trail",
      "Private jeep transport Kathmandu–Chame and Manang–Pokhara",
      "Government-licensed, English-speaking trekking guide",
      "Porter service (1 porter per 2 trekkers, 12–15 kg limit per trekker's bag)",
      "Guide & porter salary, insurance, meals, accommodation and equipment",
      "Annapurna Conservation Area Permit (ACAP)",
      "TIMS (Trekkers' Information Management System) card",
      "Comprehensive first-aid medical kit (carried by the guide)",
      "All government and local taxes, VAT, and office service charges",
      "Farewell dinner in Kathmandu",
    ],
    excluded: [
      "International airfare to/from Kathmandu",
      "Nepal entry visa fee (available on arrival — approx. USD 30 for 15 days)",
      "Travel & medical insurance, including emergency helicopter evacuation cover (mandatory — the exposed Tilicho trail makes this non-negotiable)",
      "Personal trekking gear (sleeping bag, down jacket, trekking poles, boots)",
      "Hot showers, Wi-Fi/internet, and battery charging fees at teahouses",
      "Bottled/boiled water and all drinks other than plain tea/coffee at meals",
      "Tips for your guide and porter (customary — budget roughly $180–230 total per trekker)",
      "Personal expenses: souvenirs, extra snacks, laundry, etc.",
      "Any costs from itinerary changes due to weather, road closure, rockfall risk, or illness",
    ],
    itinerary: [
      [
        "Arrival in Kathmandu",
        "Airport pickup, hotel check-in, and an evening trip briefing with your guide.",
      ],
      [
        "Drive to Chame",
        "A long but spectacular jeep drive along the Marsyangdi valley road, climbing steadily into Manang district and the district headquarters of Chame.",
      ],
      [
        "Chame to Pisang",
        "The trail now leaves the road behind, passing beneath the towering Paungda Danda rock face — a single sweep of granite over 1,500 m tall — into Pisang.",
      ],
      [
        "Pisang to Manang",
        "Via the quieter upper trail through Ghyaru and Ngawal for the best views of Annapurna II and IV, descending into Manang, the region's largest village and a natural rest stop.",
      ],
      [
        "Acclimatization day — Manang",
        "A rest day with an optional hike to Gangapurna Lake or the Ice Lake viewpoint (4,600 m) — climb high, sleep low, ahead of the Tilicho approach.",
      ],
      [
        "Manang to Khangsar",
        "A short, easy day leaving the main circuit trail, climbing gently to the last permanent village before Tilicho, with wide views back down the Manang valley.",
      ],
      [
        "Khangsar to Tilicho Base Camp",
        "The most exposed day of the trek — a narrow trail cut into the unstable scree slopes below the Grand Barrier, occasionally affected by rockfall, which your guide will time carefully around morning conditions.",
      ],
      [
        "Tilicho Base Camp to Tilicho Lake and back",
        "The reason for the whole trip — a steep climb to the lake shore, where the sheer scale and colour of Tilicho genuinely stops most people in their tracks. We return to Base Camp to sleep.",
      ],
      [
        "Tilicho Base Camp to Manang",
        "Retracing the exposed trail back through Khangsar and down into Manang, with the air noticeably thicker by the day's end.",
      ],
      [
        "Manang to Chame",
        "A long descent back down the Marsyangdi valley, rejoining the road-accessible section of the circuit.",
      ],
      [
        "Drive to Besisahar",
        "A jeep transfer down the valley road, watching the terrain shift from high alpine back to subtropical terraces.",
      ],
      [
        "Drive to Pokhara",
        "Onward to lakeside Pokhara for a proper rest, hot shower and good food after ten days on the trail.",
      ],
      [
        "Free day in Pokhara / fly to Kathmandu",
        "A buffer day in Pokhara if the schedule needs it, otherwise flight or drive back to Kathmandu.",
      ],
      [
        "Final departure",
        "Transfer to Tribhuvan International Airport for your onward flight, or extend into another Nepal itinerary.",
      ],
    ],
  },
  {
    slug: "kailash-manasarovar-tour-via-lhasa",
    title: "Kailash Manasarovar Tour — via Lhasa",
    summary:
      "Fly into Lhasa first — Potala Palace, Jokhang Temple and Tibet's great monasteries — before continuing overland to Kailash and Manasarovar.",
    description:
      "Fly into Lhasa first — Potala Palace, Jokhang Temple and Tibet's great monasteries — before continuing overland to Kailash and Manasarovar. A guided experience through Tibet – Kailash Mansarovar, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/kailash-mansarovar-tour.jpg",
    gallery: ["/images/kailash-mansarovar-tour.jpg"],
    routeMap: "/images/kailash-manasarovar-tour-via-lhasa-route-map.svg",
    duration: "18 days",
    difficulty: "Challenging",
    groupSize: "2 – 20 people",
    maxAltitude: "5,630 m (Dolma La Pass)",
    bestSeason: "May – Sep",
    price: 3750,
    categories: ["Religious Tours", "Kailash Mansarovar Tours"],
    included: [
      "All ground transport and permits as per itinerary",
      "Hotel/guesthouse accommodation on the route",
      "Experienced pilgrimage guide",
      "Puja and ritual coordination at key sites",
    ],
    excluded: [
      "International flights and visa fees",
      "Travel and high-altitude insurance",
      "Personal expenses and tips",
      "Alcoholic and bottled drinks",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 1",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 2",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 3",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 4",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 5",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 6",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 7",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 8",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 9",
        "Fly into Lhasa first — Potala Palace, Jokhang Temple and Tibet's great monasteries — before continuing overland to Kailash and Manasarovar.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 10",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 11",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 12",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 13",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 14",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 15",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Manasarovar Tour — via Lhasa — day 16",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "kailash-mansarovar-yatra-helicopter",
    title: "Kailash Mansarovar Yatra — by Helicopter",
    summary:
      "The fastest route to Kailash — helicopter transfers cut days of overland travel, ideal for pilgrims with limited time or lower physical demand.",
    description:
      "The fastest route to Kailash — helicopter transfers cut days of overland travel, ideal for pilgrims with limited time or lower physical demand. A guided experience through Tibet – Kailash Mansarovar, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/kailash-mansarovar-darshan-flyin.jpg",
    gallery: ["/images/kailash-mansarovar-darshan-flyin.jpg"],
    routeMap: "/images/kailash-mansarovar-yatra-helicopter-route-map.svg",
    duration: "9 days",
    difficulty: "Moderate",
    groupSize: "2 – 20 people",
    maxAltitude: "5,630 m",
    bestSeason: "May – Sep",
    price: 3500,
    categories: ["Religious Tours", "Kailash Mansarovar Tours"],
    included: [
      "All ground transport and permits as per itinerary",
      "Hotel/guesthouse accommodation on the route",
      "Experienced pilgrimage guide",
      "Puja and ritual coordination at key sites",
    ],
    excluded: [
      "International flights and visa fees",
      "Travel and high-altitude insurance",
      "Personal expenses and tips",
      "Alcoholic and bottled drinks",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Kailash Mansarovar Yatra — by Helicopter — day 1",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — by Helicopter — day 2",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — by Helicopter — day 3",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — by Helicopter — day 4",
        "The fastest route to Kailash — helicopter transfers cut days of overland travel, ideal for pilgrims with limited time or lower physical demand.",
      ],
      [
        "Kailash Mansarovar Yatra — by Helicopter — day 5",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — by Helicopter — day 6",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Kailash Mansarovar Yatra — by Helicopter — day 7",
        "Continue the journey through Tibet – Kailash Mansarovar, following the planned route with your guide.",
      ],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "nar-phu-valley-trek",
    title: "Nar Phu Valley Trek",
    summary:
      "A hidden Tibetan-Buddhist valley sealed off to outsiders until 2003 — narrow gorges, ancient chörtens and the dramatic Kang La Pass linking Nar and Manang.",
    description:
      "Nar Phu was sealed off to outsiders until 2003 and still sees only a small fraction of Annapurna's trekking traffic today, since visiting requires a special Restricted Area Permit and a minimum group of two trekkers with a registered guide. What you get in return is one of the most intact Tibetan-Buddhist valleys in Nepal — chörtens, mani walls and monasteries that have barely changed in generations, and villages that still function largely on trade and yak herding rather than tourism. The trek pushes up a narrow, dramatic gorge to reach Phu, a fortress-like village clinging to the valley wall, before crossing back over to Nar, equally striking but architecturally distinct. The route then climbs to Kang La Pass (5,320 m), a genuinely serious high-altitude crossing that connects Nar Phu back to the main Annapurna Circuit near Ngawal. This is not a beginner's trek — the restricted-area regulations exist partly because the terrain and remoteness demand real trekking experience or a guide you trust completely. We run it as a specialist itinerary for trekkers who've done at least one prior high-altitude trek and want something genuinely off the standard circuit.",
    image: "/images/nar-phu-valley-trek.jpg",
    gallery: ["/images/nar-phu-valley-trek.jpg"],
    routeMap: "/images/nar-phu-valley-trek-route-map.svg",
    duration: "16 Days",
    difficulty: "Challenging",
    groupSize: "2–8 (minimum 2 trekkers required by permit regulation)",
    maxAltitude: "5,320 m (Kang La Pass)",
    bestSeason:
      "May–Oct (the Manang side of the Annapurna range sits in a rain-shadow, so this trek runs later into monsoon than most)",
    price: 2700,
    categories: ["Trekking", "Annapurna Region"],
    included: [
      "Airport pick-up and drop-off by private vehicle",
      "2 nights in a 3-star Kathmandu hotel on bed & breakfast basis",
      "All meals (breakfast, lunch, dinner) during the trek, tea/coffee included",
      "Teahouse/homestay accommodation for all nights on the trail",
      "Private jeep transport Kathmandu–Koto and Besisahar–Kathmandu",
      "Government-licensed, English-speaking trekking guide with restricted-area experience",
      "Porter service (1 porter per 2 trekkers, 12–15 kg limit per trekker's bag)",
      "Guide & porter salary, insurance, meals, accommodation and equipment",
      "Nar Phu Restricted Area Permit (RAP)",
      "Annapurna Conservation Area Permit (ACAP)",
      "TIMS (Trekkers' Information Management System) card",
      "Comprehensive first-aid medical kit (carried by the guide)",
      "All government and local taxes, VAT, and office service charges",
      "Farewell dinner in Kathmandu",
    ],
    excluded: [
      "International airfare to/from Kathmandu",
      "Nepal entry visa fee (available on arrival — approx. USD 30 for 15 days)",
      "Travel & medical insurance, including emergency helicopter evacuation cover (mandatory and non-negotiable for a restricted-area, high-pass trek)",
      "Personal trekking gear (sleeping bag rated for extreme cold, down jacket, crampons/microspikes if early/late season, trekking poles, boots)",
      "Hot showers, Wi-Fi/internet, and battery charging fees at teahouses (limited or unavailable in Phu and Nar)",
      "Bottled/boiled water and all drinks other than plain tea/coffee at meals",
      "Tips for your guide and porter (customary — budget roughly $200–280 total per trekker given the length and difficulty of this trek)",
      "Personal expenses: souvenirs, extra snacks, laundry, etc.",
      "Any costs from itinerary changes due to weather, road closure, or the pass being deemed unsafe to cross",
    ],
    itinerary: [
      [
        "Arrival in Kathmandu",
        "Airport pickup, hotel check-in, and an evening trip briefing covering the restricted-area permit process and what to expect.",
      ],
      [
        "Drive to Koto",
        "A long jeep drive up the Marsyangdi valley road to Koto, the last village before the Nar Phu restricted area checkpoint.",
      ],
      [
        "Koto to Meta",
        "Permit check at the checkpoint, then into the Nar Phu gorge proper — a narrow, dramatic canyon with the trail cut directly into cliff faces in places.",
      ],
      [
        "Meta to Phu Village",
        "Past ancient chörtens and ruined fortress walls, the valley finally opens to reveal Phu — houses stacked against the hillside beneath a 15th-century monastery, one of the most atmospheric villages in Nepal.",
      ],
      [
        "Acclimatization & exploration — Phu Village",
        "A full day to explore Phu's monastery, the ruined dzong above the village, and the trails toward Himlung Base Camp — genuinely unlike anywhere else on a standard Nepal itinerary.",
      ],
      [
        "Phu to Nar Phedi",
        "Retracing part of the gorge before climbing toward Nar Phedi, a small monastery settlement at the base of the climb to Nar village.",
      ],
      [
        "Nar Phedi to Nar Village",
        "A short, steep climb into Nar, visually distinct from Phu — flat-roofed stone houses and vividly colourful prayer flags against a backdrop of jagged peaks.",
      ],
      [
        "Acclimatization day — Nar Village",
        "Rest and explore Nar's monastery and surroundings, with an optional side hike toward Kang La base for pre-acclimatization ahead of the pass.",
      ],
      [
        "Nar to Kang La Phedi",
        "A short but steady climb to a basic high camp positioned for an early start on the pass the following morning.",
      ],
      [
        "Kang La Pass to Ngawal",
        "The trek's defining day — an early, cold climb to Kang La for sweeping views over the Annapurna range and back into the Nar Phu valley, followed by a long, knee-testing descent to Ngawal on the main Annapurna Circuit trail.",
      ],
      [
        "Ngawal to Manang",
        "A gentler day rejoining the busier circuit trail, with the contrast to Nar Phu's emptiness genuinely striking.",
      ],
      [
        "Rest day — Manang",
        "A well-earned rest day, with an optional short hike to Gangapurna Lake or the Ice Lake viewpoint.",
      ],
      [
        "Manang to Chame",
        "A long descent back down the Marsyangdi valley, air thickening noticeably by the day's end.",
      ],
      ["Drive to Besisahar", "A jeep transfer down the valley road back toward the lowlands."],
      [
        "Drive to Kathmandu",
        "Return to Kathmandu, with the evening free for a farewell dinner and a proper shower after two weeks on remote trails.",
      ],
      ["Final departure", "Transfer to Tribhuvan International Airport for your onward flight."],
    ],
  },
  {
    slug: "helambu-trek",
    title: "Helambu Trek",
    summary:
      "The closest Himalayan trek to Kathmandu — Sherpa and Hyolmo villages, rhododendron forests and gentle ridgelines with no serious altitude risk.",
    description:
      "Helambu is the trek we suggest most often to people with a genuinely short window — under a week — or anyone nervous about altitude who still wants a real Himalayan trekking experience. The trailhead at Sundarijal is barely an hour from Kathmandu, so there's no domestic flight to worry about, no flight-delay risk, and no altitude above 3,700 m. What it lacks in extreme elevation it makes up for in cultural texture: this is Hyolmo (Sherpa-related) and Tamang country, with monasteries, mani walls and a noticeably different rhythm of village life than the more heavily trekked Khumbu or Annapurna trails. Rhododendron forest, ridge-top views toward the Langtang and Jugal Himal ranges, and genuinely warm homestays are the trek's real draw. We recommend Helambu specifically for first-time trekkers to Nepal, families with older children, or anyone bolting a short trek onto a broader Nepal itinerary that also includes Kathmandu Valley sightseeing or a Chitwan safari.",
    image: "/images/helambu-trek-photo.jpg",
    gallery: ["/images/helambu-trek-photo.jpg"],
    routeMap: "/images/helambu-trek-route-map.svg",
    duration: "7 Days",
    difficulty: "Moderate",
    groupSize: "2–14 (private & tailor-made groups also arranged)",
    maxAltitude: "3,690 m (Thadepati)",
    bestSeason: "Year-round is workable given the modest altitude; best Mar–May & Sept–Dec",
    price: 1500,
    categories: ["Trekking", "Langtang Region"],
    included: [
      "Airport pick-up and drop-off by private vehicle",
      "2 nights in a 3-star Kathmandu hotel on bed & breakfast basis",
      "All meals (breakfast, lunch, dinner) during the trek, tea/coffee included",
      "Teahouse/lodge accommodation for all nights on the trail",
      "Private vehicle transfers Kathmandu–Sundarijal and Melamchi Pul–Kathmandu",
      "Government-licensed, English-speaking trekking guide",
      "Porter service (1 porter per 2 trekkers, 12–15 kg limit per trekker's bag)",
      "Guide & porter salary, insurance, meals, accommodation and equipment",
      "Shivapuri Nagarjun National Park entry permit",
      "TIMS (Trekkers' Information Management System) card",
      "Comprehensive first-aid medical kit (carried by the guide)",
      "All government and local taxes, VAT, and office service charges",
      "Farewell dinner in Kathmandu",
    ],
    excluded: [
      "International airfare to/from Kathmandu",
      "Nepal entry visa fee (available on arrival — approx. USD 30 for 15 days)",
      "Travel & medical insurance (recommended for all trekkers, even at modest altitude)",
      "Personal trekking gear (warm layers, rain jacket, trekking boots — rental available in Kathmandu)",
      "Hot showers, Wi-Fi/internet, and battery charging fees at teahouses",
      "Bottled/boiled water and all drinks other than plain tea/coffee at meals",
      "Tips for your guide and porter (customary — budget roughly $80–120 total per trekker)",
      "Personal expenses: souvenirs, extra snacks, laundry, etc.",
      "Kathmandu sightseeing tours and monument entrance fees (available as an easy add-on)",
    ],
    itinerary: [
      [
        "Arrival in Kathmandu",
        "Airport pickup, hotel check-in, and an evening trip briefing with your guide.",
      ],
      [
        "Drive to Sundarijal, trek to Chisapani",
        "A short drive to the trailhead at Sundarijal, then a climb through Shivapuri National Park forest — the trek's gateway and a good, easy day to settle in.",
      ],
      [
        "Chisapani to Kutumsang",
        "A rolling ridge walk with wide views toward the Langtang range on clear days, passing through several small Tamang villages along the way.",
      ],
      [
        "Kutumsang to Thadepati",
        "The trek's high point, climbing steadily through rhododendron forest that thins toward the top. Thadepati sits right on the ridge with genuinely expansive views in clear conditions.",
      ],
      [
        "Thadepati to Melamchigaon",
        "A long descent into the Helambu valley proper, arriving at Melamchigaon, home to an important Hyolmo monastery and a real sense of having left the trekking-trail bustle behind.",
      ],
      [
        "Melamchigaon to Tarkeghyang",
        "A gentle day through forest and farmland into Tarkeghyang, the largest and most attractive Hyolmo village on the route, known for its centuries-old monastery.",
      ],
      [
        "Tarkeghyang to Melamchi Pul, drive to Kathmandu",
        "A final descent through Sermathang to the roadhead at Melamchi Pul Bazaar, then a drive back to Kathmandu. Farewell dinner in the evening.",
      ],
    ],
  },
  {
    slug: "kathmandu-durbar-square",
    title: "Kathmandu Durbar Square Tour",
    summary:
      "Wander the old royal palace complex of the Malla kings — Kasthamandap, Hanuman Dhoka and the Kumari's living-goddess residence at the historic heart of Kathmandu.",
    description:
      "Wander the old royal palace complex of the Malla kings — Kasthamandap, Hanuman Dhoka and the Kumari's living-goddess residence at the historic heart of Kathmandu. A guided experience through Kathmandu Valley, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/kathmandu-durbar-square.png",
    gallery: ["/images/kathmandu-durbar-square.png"],
    routeMap: "/images/kathmandu-durbar-square-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "1,400 m",
    bestSeason: "All year",
    price: 45,
    categories: ["Cultural Tours"],
    included: [
      "Private vehicle with driver for all sightseeing",
      "Heritage guide for the full tour",
      "All monument entry fees",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Meals unless noted",
      "Personal expenses",
      "Tips for guide and driver",
      "Travel insurance",
    ],
    itinerary: [
      [
        "Full-day tour",
        "Wander the old royal palace complex of the Malla kings — Kasthamandap, Hanuman Dhoka and the Kumari's living-goddess residence at the historic heart of Kathmandu.",
      ],
    ],
  },
  {
    slug: "patan-durbar-square",
    title: "Patan Durbar Square Tour",
    summary:
      "The finest Newar craftsmanship in the valley — ornate stone and wood temples, the Patan Museum and centuries-old courtyards in the City of Fine Arts.",
    description:
      "The finest Newar craftsmanship in the valley — ornate stone and wood temples, the Patan Museum and centuries-old courtyards in the City of Fine Arts. A guided experience through Kathmandu Valley, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/patan-durbar-square.jpg",
    gallery: ["/images/patan-durbar-square.jpg"],
    routeMap: "/images/patan-durbar-square-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "1,280 m",
    bestSeason: "All year",
    price: 45,
    categories: ["Cultural Tours"],
    included: [
      "Private vehicle with driver for all sightseeing",
      "Heritage guide for the full tour",
      "All monument entry fees",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Meals unless noted",
      "Personal expenses",
      "Tips for guide and driver",
      "Travel insurance",
    ],
    itinerary: [
      [
        "Full-day tour",
        "The finest Newar craftsmanship in the valley — ornate stone and wood temples, the Patan Museum and centuries-old courtyards in the City of Fine Arts.",
      ],
    ],
  },
  {
    slug: "bhaktapur-durbar-square",
    title: "Bhaktapur Durbar Square Tour",
    summary:
      "Nepal's best-preserved medieval city — the five-tiered Nyatapola Temple, potter's square and brick-paved lanes untouched by modern traffic.",
    description:
      "Nepal's best-preserved medieval city — the five-tiered Nyatapola Temple, potter's square and brick-paved lanes untouched by modern traffic. A guided experience through Kathmandu Valley, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/bhaktapur-durbar-square.jpg",
    gallery: ["/images/bhaktapur-durbar-square.jpg"],
    routeMap: "/images/bhaktapur-durbar-square-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "1,401 m",
    bestSeason: "All year",
    price: 50,
    categories: ["Cultural Tours"],
    included: [
      "Private vehicle with driver for all sightseeing",
      "Heritage guide for the full tour",
      "All monument entry fees",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Meals unless noted",
      "Personal expenses",
      "Tips for guide and driver",
      "Travel insurance",
    ],
    itinerary: [
      [
        "Full-day tour",
        "Nepal's best-preserved medieval city — the five-tiered Nyatapola Temple, potter's square and brick-paved lanes untouched by modern traffic.",
      ],
    ],
  },
  {
    slug: "swayambhunath-stupa",
    title: "Swayambhunath Stupa Tour",
    summary:
      "Climb the hilltop 'Monkey Temple' — a 2,000-year-old stupa with the Buddha's all-seeing eyes gazing over the whole Kathmandu Valley.",
    description:
      "Climb the hilltop 'Monkey Temple' — a 2,000-year-old stupa with the Buddha's all-seeing eyes gazing over the whole Kathmandu Valley. A guided experience through Kathmandu Valley, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/swayambhunath-stupa.jpg",
    gallery: ["/images/swayambhunath-stupa.jpg"],
    routeMap: "/images/swayambhunath-stupa-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "1,370 m",
    bestSeason: "All year",
    price: 35,
    categories: ["Cultural Tours"],
    included: [
      "Private vehicle with driver for all sightseeing",
      "Heritage guide for the full tour",
      "All monument entry fees",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Meals unless noted",
      "Personal expenses",
      "Tips for guide and driver",
      "Travel insurance",
    ],
    itinerary: [
      [
        "Full-day tour",
        "Climb the hilltop 'Monkey Temple' — a 2,000-year-old stupa with the Buddha's all-seeing eyes gazing over the whole Kathmandu Valley.",
      ],
    ],
  },
  {
    slug: "boudhanath-stupa",
    title: "Boudhanath Stupa Tour",
    summary:
      "Circle the largest stupa in Nepal with maroon-robed monks, prayer wheels and the beating heart of Kathmandu's Tibetan Buddhist community.",
    description:
      "Circle the largest stupa in Nepal with maroon-robed monks, prayer wheels and the beating heart of Kathmandu's Tibetan Buddhist community. A guided experience through Kathmandu Valley, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/boudhanath-stupa.jpg",
    gallery: ["/images/boudhanath-stupa.jpg"],
    routeMap: "/images/boudhanath-stupa-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "1,350 m",
    bestSeason: "All year",
    price: 35,
    categories: ["Cultural Tours"],
    included: [
      "Private vehicle with driver for all sightseeing",
      "Heritage guide for the full tour",
      "All monument entry fees",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Meals unless noted",
      "Personal expenses",
      "Tips for guide and driver",
      "Travel insurance",
    ],
    itinerary: [
      [
        "Full-day tour",
        "Circle the largest stupa in Nepal with maroon-robed monks, prayer wheels and the beating heart of Kathmandu's Tibetan Buddhist community.",
      ],
    ],
  },
  {
    slug: "pashupatinath-temple",
    title: "Pashupatinath Temple Tour",
    summary:
      "Nepal's most sacred Hindu temple on the banks of the Bagmati River — pagoda architecture, sadhus and centuries-old cremation ghats.",
    description:
      "Nepal's most sacred Hindu temple on the banks of the Bagmati River — pagoda architecture, sadhus and centuries-old cremation ghats. A guided experience through Kathmandu Valley, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/pashupatinath-temple.jpg",
    gallery: ["/images/pashupatinath-temple.jpg"],
    routeMap: "/images/pashupatinath-temple-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "1,350 m",
    bestSeason: "All year",
    price: 60,
    categories: ["Cultural Tours"],
    included: [
      "Private vehicle with driver for all sightseeing",
      "Heritage guide for the full tour",
      "All monument entry fees",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Meals unless noted",
      "Personal expenses",
      "Tips for guide and driver",
      "Travel insurance",
    ],
    itinerary: [
      [
        "Full-day tour",
        "Nepal's most sacred Hindu temple on the banks of the Bagmati River — pagoda architecture, sadhus and centuries-old cremation ghats.",
      ],
    ],
  },
  {
    slug: "changu-narayan-temple",
    title: "Changu Narayan Temple Tour",
    summary:
      "Nepal's oldest surviving Hindu temple, perched on a quiet ridge above Bhaktapur — exquisite stone carvings dating back to the Licchavi era.",
    description:
      "Nepal's oldest surviving Hindu temple, perched on a quiet ridge above Bhaktapur — exquisite stone carvings dating back to the Licchavi era. A guided experience through Kathmandu Valley, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/changu-narayan-temple.jpg",
    gallery: ["/images/changu-narayan-temple.jpg"],
    routeMap: "/images/changu-narayan-temple-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "1,541 m",
    bestSeason: "All year",
    price: 40,
    categories: ["Cultural Tours"],
    included: [
      "Private vehicle with driver for all sightseeing",
      "Heritage guide for the full tour",
      "All monument entry fees",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Meals unless noted",
      "Personal expenses",
      "Tips for guide and driver",
      "Travel insurance",
    ],
    itinerary: [
      [
        "Full-day tour",
        "Nepal's oldest surviving Hindu temple, perched on a quiet ridge above Bhaktapur — exquisite stone carvings dating back to the Licchavi era.",
      ],
    ],
  },
  {
    slug: "kathmandu-durbar-square-day-tour",
    title: "Kathmandu Heritage Tour",
    summary:
      "All seven Kathmandu Valley UNESCO sites in one trip — Kathmandu, Patan and Bhaktapur Durbar Squares, Swayambhunath, Boudhanath, Pashupatinath and Changu Narayan.",
    description:
      "All seven Kathmandu Valley UNESCO sites in one trip — Kathmandu, Patan and Bhaktapur Durbar Squares, Swayambhunath, Boudhanath, Pashupatinath and Changu Narayan. A guided experience through Kathmandu Valley, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/kathmandu-valley.jpg",
    gallery: ["/images/kathmandu-valley.jpg"],
    routeMap: "/images/kathmandu-durbar-square-day-tour-route-map.svg",
    duration: "2 days",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "1,401 m",
    bestSeason: "All year",
    price: 180,
    categories: ["Cultural Tours"],
    included: [
      "Private vehicle with driver for all sightseeing",
      "Heritage guide for the full tour",
      "All monument entry fees",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Meals unless noted",
      "Personal expenses",
      "Tips for guide and driver",
      "Travel insurance",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "lumbini-heritage-tour",
    title: "Lumbini Heritage Site Tour",
    summary:
      "The birthplace of Lord Buddha — the sacred Maya Devi Temple, Ashoka Pillar and a Monastic Zone of temples built by Buddhist nations from around the world.",
    description:
      "The birthplace of Lord Buddha — the sacred Maya Devi Temple, Ashoka Pillar and a Monastic Zone of temples built by Buddhist nations from around the world. A guided experience through Lumbini, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/lumbini.jpg",
    gallery: ["/images/lumbini.jpg"],
    routeMap: "/images/lumbini-heritage-tour-route-map.svg",
    duration: "3 days",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "150 m",
    bestSeason: "All year",
    price: 280,
    categories: ["Cultural Tours"],
    included: [
      "Private vehicle with driver for all sightseeing",
      "Heritage guide for the full tour",
      "All monument entry fees",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Meals unless noted",
      "Personal expenses",
      "Tips for guide and driver",
      "Travel insurance",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Lumbini Heritage Site Tour — day 1",
        "The birthplace of Lord Buddha — the sacred Maya Devi Temple, Ashoka Pillar and a Monastic Zone of temples built by Buddhist nations from around the world.",
      ],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "gorkha-durbar-tour",
    title: "Gorkha Durbar Tour",
    summary:
      "The hilltop fortress-palace of Prithvi Narayan Shah, founder of unified Nepal — panoramic Himalayan views and the temple of Gorakhkali.",
    description:
      "The hilltop fortress-palace of Prithvi Narayan Shah, founder of unified Nepal — panoramic Himalayan views and the temple of Gorakhkali. A guided experience through Gorkha, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/gorkha-durbar.jpg",
    gallery: ["/images/gorkha-durbar.jpg"],
    routeMap: "/images/gorkha-durbar-tour-route-map.svg",
    duration: "2 days",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "1,097 m",
    bestSeason: "All year",
    price: 170,
    categories: ["Cultural Tours"],
    included: [
      "Private vehicle with driver for all sightseeing",
      "Heritage guide for the full tour",
      "All monument entry fees",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Meals unless noted",
      "Personal expenses",
      "Tips for guide and driver",
      "Travel insurance",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "nuwakot-durbar-tour",
    title: "Nuwakot Durbar Tour",
    summary:
      "A seven-storey historic palace on the old Kathmandu–Tibet trade route — quiet terraced hills and a living museum of Shah-era architecture.",
    description:
      "A seven-storey historic palace on the old Kathmandu–Tibet trade route — quiet terraced hills and a living museum of Shah-era architecture. A guided experience through Nuwakot, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/nuwakot-durbar.jpg",
    gallery: ["/images/nuwakot-durbar.jpg"],
    routeMap: "/images/nuwakot-durbar-tour-route-map.svg",
    duration: "2 days",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "1,000 m",
    bestSeason: "All year",
    price: 150,
    categories: ["Cultural Tours"],
    included: [
      "Private vehicle with driver for all sightseeing",
      "Heritage guide for the full tour",
      "All monument entry fees",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Meals unless noted",
      "Personal expenses",
      "Tips for guide and driver",
      "Travel insurance",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "tansen-durbar-tour",
    title: "Tansen Durbar Tour",
    summary:
      "A hillside Newari trading town in Palpa — the historic Tansen Durbar, Rani Mahal palace and sweeping views over the Kali Gandaki valley.",
    description:
      "A hillside Newari trading town in Palpa — the historic Tansen Durbar, Rani Mahal palace and sweeping views over the Kali Gandaki valley. A guided experience through Palpa, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/tansen-durbar.jpg",
    gallery: ["/images/tansen-durbar.jpg"],
    routeMap: "/images/tansen-durbar-tour-route-map.svg",
    duration: "3 days",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "1,343 m",
    bestSeason: "All year",
    price: 260,
    categories: ["Cultural Tours"],
    included: [
      "Private vehicle with driver for all sightseeing",
      "Heritage guide for the full tour",
      "All monument entry fees",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Meals unless noted",
      "Personal expenses",
      "Tips for guide and driver",
      "Travel insurance",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Tansen Durbar Tour — day 1",
        "A hillside Newari trading town in Palpa — the historic Tansen Durbar, Rani Mahal palace and sweeping views over the Kali Gandaki valley.",
      ],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "muktinath-tour",
    title: "Muktinath Temple Tour",
    summary:
      "A temple sacred to both Hindus and Buddhists — 108 water spouts and an eternal flame fed by natural gas, set beneath the arid cliffs of Mustang.",
    description:
      "A temple sacred to both Hindus and Buddhists — 108 water spouts and an eternal flame fed by natural gas, set beneath the arid cliffs of Mustang. A guided experience through Mustang, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/muktinath-temple.jpg",
    gallery: ["/images/muktinath-temple.jpg"],
    routeMap: "/images/muktinath-tour-route-map.svg",
    duration: "5 days",
    difficulty: "Moderate",
    groupSize: "1 – 16 people",
    maxAltitude: "3,710 m",
    bestSeason: "All year",
    price: 450,
    categories: ["Religious Tours"],
    included: [
      "Private vehicle with driver",
      "Pilgrimage guide and puja coordination",
      "Temple entry and cable car tickets where applicable",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Offerings and donations",
      "Meals unless noted",
      "Personal expenses",
      "Travel insurance",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Muktinath Temple Tour — day 1",
        "Continue the journey through Mustang, following the planned route with your guide.",
      ],
      [
        "Muktinath Temple Tour — day 2",
        "A temple sacred to both Hindus and Buddhists — 108 water spouts and an eternal flame fed by natural gas, set beneath the arid cliffs of Mustang.",
      ],
      [
        "Muktinath Temple Tour — day 3",
        "Continue the journey through Mustang, following the planned route with your guide.",
      ],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "janaki-mandir-tour",
    title: "Janaki Mandir Tour",
    summary:
      "The marble Koshi-style temple marking the birthplace of Goddess Sita in Janakpur — the spiritual capital of Nepal's Mithila culture.",
    description:
      "The marble Koshi-style temple marking the birthplace of Goddess Sita in Janakpur — the spiritual capital of Nepal's Mithila culture. A guided experience through Janakpur, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/janaki-mandir-janakpur.jpg",
    gallery: ["/images/janaki-mandir-janakpur.jpg"],
    routeMap: "/images/janaki-mandir-tour-route-map.svg",
    duration: "3 days",
    difficulty: "Easy",
    groupSize: "1 – 16 people",
    maxAltitude: "74 m",
    bestSeason: "All year",
    price: 240,
    categories: ["Religious Tours"],
    included: [
      "Private vehicle with driver",
      "Pilgrimage guide and puja coordination",
      "Temple entry and cable car tickets where applicable",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Offerings and donations",
      "Meals unless noted",
      "Personal expenses",
      "Travel insurance",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Janaki Mandir Tour — day 1",
        "The marble Koshi-style temple marking the birthplace of Goddess Sita in Janakpur — the spiritual capital of Nepal's Mithila culture.",
      ],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "pathivera-tour",
    title: "Pathivera (Pathibhara) Temple Tour",
    summary:
      "One of eastern Nepal's most revered Hindu shrines — a wish-fulfilling temple on a windswept ridge with views of Kanchenjunga.",
    description:
      "One of eastern Nepal's most revered Hindu shrines — a wish-fulfilling temple on a windswept ridge with views of Kanchenjunga. A guided experience through Taplejung, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/pathibhara-devi-temple.jpg",
    gallery: ["/images/pathibhara-devi-temple.jpg"],
    routeMap: "/images/pathivera-tour-route-map.svg",
    duration: "5 days",
    difficulty: "Moderate",
    groupSize: "1 – 16 people",
    maxAltitude: "3,794 m",
    bestSeason: "All year",
    price: 480,
    categories: ["Religious Tours"],
    included: [
      "Private vehicle with driver",
      "Pilgrimage guide and puja coordination",
      "Temple entry and cable car tickets where applicable",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Offerings and donations",
      "Meals unless noted",
      "Personal expenses",
      "Travel insurance",
    ],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Pathivera (Pathibhara) Temple Tour — day 1",
        "Continue the journey through Taplejung, following the planned route with your guide.",
      ],
      [
        "Pathivera (Pathibhara) Temple Tour — day 2",
        "One of eastern Nepal's most revered Hindu shrines — a wish-fulfilling temple on a windswept ridge with views of Kanchenjunga.",
      ],
      [
        "Pathivera (Pathibhara) Temple Tour — day 3",
        "Continue the journey through Taplejung, following the planned route with your guide.",
      ],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "chitwan-national-park",
    title: "Chitwan National Park Tour",
    summary:
      "Nepal's first national park and a UNESCO World Heritage Site — one-horned rhinos, Bengal tigers and gharial crocodiles in the subtropical Terai.",
    description:
      "Nepal's first national park and a UNESCO World Heritage Site — one-horned rhinos, Bengal tigers and gharial crocodiles in the subtropical Terai. A guided experience through Chitwan, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/chitwan-national-park.jpg",
    gallery: ["/images/chitwan-national-park.jpg"],
    routeMap: "/images/chitwan-national-park-route-map.svg",
    duration: "3 days",
    difficulty: "Easy",
    groupSize: "2 – 12 people",
    maxAltitude: "150 m",
    bestSeason: "Oct – Apr",
    price: 280,
    categories: ["Wildlife Tours"],
    included: [
      "Jungle lodge accommodation with all meals",
      "Park entry permits and naturalist guide",
      "Jeep safari, canoe ride and jungle walk as per itinerary",
      "All ground transport",
    ],
    excluded: ["Flights", "Drinks", "Travel insurance", "Tips for guide and staff"],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Chitwan National Park Tour — day 1",
        "Nepal's first national park and a UNESCO World Heritage Site — one-horned rhinos, Bengal tigers and gharial crocodiles in the subtropical Terai.",
      ],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "sauraha-jungle-safari",
    title: "Sauraha Jungle Safari",
    summary:
      "The gateway village to Chitwan — jeep and canoe safaris, Tharu cultural shows and close encounters with rhinos along the Rapti River.",
    description:
      "The gateway village to Chitwan — jeep and canoe safaris, Tharu cultural shows and close encounters with rhinos along the Rapti River. A guided experience through Chitwan, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/jungle-safari.jpg",
    gallery: ["/images/jungle-safari.jpg"],
    routeMap: "/images/sauraha-jungle-safari-route-map.svg",
    duration: "2 days",
    difficulty: "Easy",
    groupSize: "2 – 12 people",
    maxAltitude: "150 m",
    bestSeason: "Oct – Apr",
    price: 180,
    categories: ["Wildlife Tours"],
    included: [
      "Jungle lodge accommodation with all meals",
      "Park entry permits and naturalist guide",
      "Jeep safari, canoe ride and jungle walk as per itinerary",
      "All ground transport",
    ],
    excluded: ["Flights", "Drinks", "Travel insurance", "Tips for guide and staff"],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "bardia-national-park",
    title: "Bardia National Park Tour",
    summary:
      "Nepal's largest and wildest Terai national park — the best odds in the country of spotting a wild Bengal tiger, far from the crowds of Chitwan.",
    description:
      "Nepal's largest and wildest Terai national park — the best odds in the country of spotting a wild Bengal tiger, far from the crowds of Chitwan. A guided experience through Bardia, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/bardia-national-park.jpg",
    gallery: ["/images/bardia-national-park.jpg"],
    routeMap: "/images/bardia-national-park-route-map.svg",
    duration: "4 days",
    difficulty: "Easy",
    groupSize: "2 – 12 people",
    maxAltitude: "150 m",
    bestSeason: "Oct – Apr",
    price: 420,
    categories: ["Wildlife Tours"],
    included: [
      "Jungle lodge accommodation with all meals",
      "Park entry permits and naturalist guide",
      "Jeep safari, canoe ride and jungle walk as per itinerary",
      "All ground transport",
    ],
    excluded: ["Flights", "Drinks", "Travel insurance", "Tips for guide and staff"],
    itinerary: [
      ["Arrival in Kathmandu", "Airport pick-up, hotel check-in and an evening trip briefing."],
      [
        "Bardia National Park Tour — day 1",
        "Continue the journey through Bardia, following the planned route with your guide.",
      ],
      [
        "Bardia National Park Tour — day 2",
        "Nepal's largest and wildest Terai national park — the best odds in the country of spotting a wild Bengal tiger, far from the crowds of Chitwan.",
      ],
      [
        "Return and departure",
        "Transfer back to Kathmandu and onward departure, or extend into another itinerary.",
      ],
    ],
  },
  {
    slug: "ebc-helicopter-tour",
    title: "Everest Base Camp Helicopter Tour",
    summary:
      "See Everest Base Camp and Kalapatthar in a single unforgettable morning — land at Kalapatthar for tea with Everest towering directly overhead.",
    description:
      "See Everest Base Camp and Kalapatthar in a single unforgettable morning — land at Kalapatthar for tea with Everest towering directly overhead. A guided experience through Everest Region, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/everest-base-camp-helicopter-tour.jpg",
    gallery: ["/images/everest-base-camp-helicopter-tour.jpg"],
    routeMap: "/images/ebc-helicopter-tour-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 10 people",
    maxAltitude: "5,364 m",
    bestSeason: "All year",
    price: 1900,
    categories: ["Helicopter Tours", "Everest Region"],
    included: [
      "Shared or private helicopter seat with airport taxes",
      "Breakfast/refreshment stop as per itinerary",
      "Hotel transfers in Kathmandu",
      "Oxygen supply on board",
    ],
    excluded: ["Private charter surcharge", "Travel insurance", "Personal expenses"],
    itinerary: [
      [
        "Full-day tour",
        "See Everest Base Camp and Kalapatthar in a single unforgettable morning — land at Kalapatthar for tea with Everest towering directly overhead.",
      ],
    ],
  },
  {
    slug: "abc-helicopter-tour",
    title: "Annapurna Base Camp Helicopter Tour",
    summary:
      "Fly into the Annapurna Sanctuary and land at Base Camp itself — a 360° amphitheatre of 7,000–8,000 m peaks, no trekking required.",
    description:
      "Fly into the Annapurna Sanctuary and land at Base Camp itself — a 360° amphitheatre of 7,000–8,000 m peaks, no trekking required. A guided experience through Annapurna Region, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/annapurna-base-camp-helicopter-tour.jpg",
    gallery: ["/images/annapurna-base-camp-helicopter-tour.jpg"],
    routeMap: "/images/abc-helicopter-tour-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 10 people",
    maxAltitude: "4,130 m",
    bestSeason: "All year",
    price: 890,
    categories: ["Helicopter Tours", "Annapurna Region"],
    included: [
      "Shared or private helicopter seat with airport taxes",
      "Breakfast/refreshment stop as per itinerary",
      "Hotel transfers in Kathmandu",
      "Oxygen supply on board",
    ],
    excluded: ["Private charter surcharge", "Travel insurance", "Personal expenses"],
    itinerary: [
      [
        "Full-day tour",
        "Fly into the Annapurna Sanctuary and land at Base Camp itself — a 360° amphitheatre of 7,000–8,000 m peaks, no trekking required.",
      ],
    ],
  },
  {
    slug: "gosaikunda-helicopter-tour",
    title: "Gosaikunda Lake Helicopter Tour",
    summary:
      "Land beside the sacred alpine lake of Gosaikunda without the multi-day trek — a quick, high-altitude pilgrimage by air over the Langtang range.",
    description:
      "Land beside the sacred alpine lake of Gosaikunda without the multi-day trek — a quick, high-altitude pilgrimage by air over the Langtang range. A guided experience through Langtang Region, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/gosaikunda-lake.jpg",
    gallery: ["/images/gosaikunda-lake.jpg"],
    routeMap: "/images/gosaikunda-helicopter-tour-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 10 people",
    maxAltitude: "4,380 m",
    bestSeason: "All year",
    price: 990,
    categories: ["Helicopter Tours", "Langtang Region"],
    included: [
      "Shared or private helicopter seat with airport taxes",
      "Breakfast/refreshment stop as per itinerary",
      "Hotel transfers in Kathmandu",
      "Oxygen supply on board",
    ],
    excluded: ["Private charter surcharge", "Travel insurance", "Personal expenses"],
    itinerary: [
      [
        "Full-day tour",
        "Land beside the sacred alpine lake of Gosaikunda without the multi-day trek — a quick, high-altitude pilgrimage by air over the Langtang range.",
      ],
    ],
  },
  {
    slug: "upper-mustang-helicopter-tour",
    title: "Upper Mustang Helicopter Tour",
    summary:
      "Fly over the forbidden walled city of Lo Manthang and the eroded ochre cliffs of the Mustang desert — the fastest way into the last Tibetan kingdom.",
    description:
      "Fly over the forbidden walled city of Lo Manthang and the eroded ochre cliffs of the Mustang desert — the fastest way into the last Tibetan kingdom. A guided experience through Mustang, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/upper-mustang-helicopter-tour.jpg",
    gallery: ["/images/upper-mustang-helicopter-tour.jpg"],
    routeMap: "/images/upper-mustang-helicopter-tour-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 10 people",
    maxAltitude: "3,840 m",
    bestSeason: "All year",
    price: 1590,
    categories: ["Helicopter Tours", "Mustang Region"],
    included: [
      "Shared or private helicopter seat with airport taxes",
      "Breakfast/refreshment stop as per itinerary",
      "Hotel transfers in Kathmandu",
      "Oxygen supply on board",
    ],
    excluded: ["Private charter surcharge", "Travel insurance", "Personal expenses"],
    itinerary: [
      [
        "Full-day tour",
        "Fly over the forbidden walled city of Lo Manthang and the eroded ochre cliffs of the Mustang desert — the fastest way into the last Tibetan kingdom.",
      ],
    ],
  },
  {
    slug: "kathmandu-sightseeing-day-tour",
    title: "Kathmandu Sightseeing Day Tour",
    summary:
      "A single, well-paced day across Kathmandu's UNESCO highlights — Durbar Square, Swayambhunath, Boudhanath and Pashupatinath with a private guide.",
    description:
      "A single, well-paced day across Kathmandu's UNESCO highlights — Durbar Square, Swayambhunath, Boudhanath and Pashupatinath with a private guide. A guided experience through Kathmandu Valley, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/kathmandu-valley.jpg",
    gallery: ["/images/kathmandu-valley.jpg"],
    routeMap: "/images/kathmandu-sightseeing-day-tour-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 10 people",
    maxAltitude: "1,400 m",
    bestSeason: "All year",
    price: 65,
    categories: ["Cultural Tours"],
    included: [
      "Private air-conditioned vehicle with driver",
      "Government-licensed English speaking guide",
      "All entry fees and permits mentioned in the itinerary",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Lunch and dinner",
      "Personal expenses and tips",
      "Travel insurance",
      "International/domestic flights unless noted",
    ],
    itinerary: [
      [
        "Full-day tour",
        "A single, well-paced day across Kathmandu's UNESCO highlights — Durbar Square, Swayambhunath, Boudhanath and Pashupatinath with a private guide.",
      ],
    ],
  },
  {
    slug: "pokhara-sightseeing-day-tour",
    title: "Pokhara Sightseeing Day Tour",
    summary:
      "Phewa Lake boating, the World Peace Pagoda and sunrise over the Annapurna range from Sarangkot — Pokhara's essential highlights in one day.",
    description:
      "Phewa Lake boating, the World Peace Pagoda and sunrise over the Annapurna range from Sarangkot — Pokhara's essential highlights in one day. A guided experience through Pokhara, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/pokhara-phewa-lake.jpg",
    gallery: ["/images/pokhara-phewa-lake.jpg"],
    routeMap: "/images/pokhara-adventure-package-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 10 people",
    maxAltitude: "1,592 m (Sarangkot)",
    bestSeason: "All year",
    price: 55,
    categories: ["Cultural Tours"],
    included: [
      "Private air-conditioned vehicle with driver",
      "Government-licensed English speaking guide",
      "All entry fees and permits mentioned in the itinerary",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Lunch and dinner",
      "Personal expenses and tips",
      "Travel insurance",
      "International/domestic flights unless noted",
    ],
    itinerary: [
      [
        "Full-day tour",
        "Phewa Lake boating, the World Peace Pagoda and sunrise over the Annapurna range from Sarangkot — Pokhara's essential highlights in one day.",
      ],
    ],
  },
  {
    slug: "lumbini-sightseeing-day-tour",
    title: "Lumbini Sightseeing Day Tour",
    summary:
      "A focused day around the Buddha's birthplace — the Maya Devi Temple, sacred garden and the international monastic zone.",
    description:
      "A focused day around the Buddha's birthplace — the Maya Devi Temple, sacred garden and the international monastic zone. A guided experience through Lumbini, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/lumbini.jpg",
    gallery: ["/images/lumbini.jpg"],
    routeMap: "/images/lumbini-sightseeing-day-tour-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 10 people",
    maxAltitude: "150 m",
    bestSeason: "All year",
    price: 75,
    categories: ["Cultural Tours"],
    included: [
      "Private air-conditioned vehicle with driver",
      "Government-licensed English speaking guide",
      "All entry fees and permits mentioned in the itinerary",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Lunch and dinner",
      "Personal expenses and tips",
      "Travel insurance",
      "International/domestic flights unless noted",
    ],
    itinerary: [
      [
        "Full-day tour",
        "A focused day around the Buddha's birthplace — the Maya Devi Temple, sacred garden and the international monastic zone.",
      ],
    ],
  },
  {
    slug: "paragliding-sarankot",
    title: "Paragliding in Sarangkot",
    summary:
      "Tandem paraglide off Sarangkot ridge and soar above Phewa Lake with the Annapurna and Machhapuchhre skyline as your backdrop.",
    description:
      "Tandem paraglide off Sarangkot ridge and soar above Phewa Lake with the Annapurna and Machhapuchhre skyline as your backdrop. A guided experience through Pokhara, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/paragliding-in-sarangkot-photo.jpg",
    gallery: ["/images/paragliding-in-sarangkot-photo.jpg"],
    routeMap: "/images/paragliding-in-sarangkot-route-map.svg",
    duration: "1 day",
    difficulty: "Easy",
    groupSize: "1 – 10 people",
    maxAltitude: "1,592 m",
    bestSeason: "All year",
    price: 95,
    categories: ["Adventure Tours"],
    included: [
      "Private air-conditioned vehicle with driver",
      "Government-licensed English speaking guide",
      "All entry fees and permits mentioned in the itinerary",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Lunch and dinner",
      "Personal expenses and tips",
      "Travel insurance",
      "International/domestic flights unless noted",
    ],
    itinerary: [
      [
        "Full-day tour",
        "Tandem paraglide off Sarangkot ridge and soar above Phewa Lake with the Annapurna and Machhapuchhre skyline as your backdrop.",
      ],
    ],
  },
  {
    slug: "bungee-jumping-kusma",
    title: "Bungee Jumping in Kusma",
    summary:
      "Nepal's highest bungee jump and the world's second-highest — a 228 m free fall off the suspension bridge over the Kali Gandaki Gorge near Kusma.",
    description:
      "Nepal's highest bungee jump and the world's second-highest — a 228 m free fall off the suspension bridge over the Kali Gandaki Gorge near Kusma. A guided experience through Pokhara, arranged with a private vehicle and a knowledgeable local guide.",
    image: "/images/bungee-canyon-swing.jpg",
    gallery: ["/images/bungee-canyon-swing.jpg"],
    routeMap: "/images/bungee-jumping-kusma-route-map.svg",
    duration: "1 day",
    difficulty: "Extreme",
    groupSize: "1 – 10 people",
    maxAltitude: "228 m jump height",
    bestSeason: "All year",
    price: 120,
    categories: ["Adventure Tours"],
    included: [
      "Private air-conditioned vehicle with driver",
      "Government-licensed English speaking guide",
      "All entry fees and permits mentioned in the itinerary",
      "Hotel pick-up and drop-off",
    ],
    excluded: [
      "Lunch and dinner",
      "Personal expenses and tips",
      "Travel insurance",
      "International/domestic flights unless noted",
    ],
    itinerary: [
      [
        "Full-day tour",
        "Nepal's highest bungee jump and the world's second-highest — a 228 m free fall off the suspension bridge over the Kali Gandaki Gorge near Kusma.",
      ],
    ],
  },
];

export const heroImg = "/assets/hero-himalaya-DrS97LmK.jpg";
export const aboutImg = "/assets/region-annapurna-village-D26nnyfn.jpg";
export const skylineImg = "/assets/kathmandu-skyline-BWkh9nGe.jpg";

export const destinations: RegionItem[] = [
  {
    name: "Everest Region",
    title: "Everest Region",
    image: "/assets/region-everest-trekkers-smuIrnxG.jpg",
    packs: 10,
    description:
      "Home of Mount Everest, legendary Sherpa villages, Khumbu glacier moraines, and high Himalayan passes.",
  },
  {
    name: "Annapurna Region",
    title: "Annapurna Region",
    image: "/assets/region-annapurna-village-D26nnyfn.jpg",
    packs: 11,
    description:
      "Spectacular amphitheater of snow peaks, Annapurna Sanctuary, Thorong La pass, and rhododendron forests.",
  },
  {
    name: "Mustang Region",
    title: "Mustang Region",
    image: "/assets/region-mustang-lo-manthang-B0XvWSGn.jpg",
    packs: 4,
    description:
      "The ancient walled kingdom of Lo Manthang, Buddhist monasteries, cliffside caves, and trans-Himalayan scenery.",
  },
  {
    name: "Langtang Region",
    title: "Langtang Region",
    image: "/assets/region-langtang-kyanjin-wide-QT74wU_W.jpg",
    packs: 4,
    description:
      "The valley of glaciers, sacred high-altitude alpine lakes of Gosaikunda, and authentic Tamang hospitality.",
  },
  {
    name: "Chitwan Region",
    title: "Chitwan Region",
    image: "/assets/region-chitwan-rhino-knqlVUXn.jpg",
    packs: 3,
    description:
      "Subtropical jungle safaris, one-horned rhinoceros, Royal Bengal tigers, and vibrant Tharu culture.",
  },
  {
    name: "Kathmandu Region",
    title: "Kathmandu Region",
    image: "/assets/region-kathmandu-swayambhunath-DmGavd0w.jpg",
    packs: 6,
    description:
      "Ancient UNESCO World Heritage durbar squares, centuries-old shrines, stupas, and Newari stone architecture.",
  },
];

export const activities = [
  {
    title: "Himalayan Trekking",
    text: "From classic Everest Base Camp and Annapurna circuits to remote trails of Manaslu and Nar Phu with seasoned Sherpa guides.",
    img: "/images/everest-base-camp-sunrise.jpg",
  },
  {
    title: "Helicopter Tours",
    text: "Soar over Khumbu icefalls, land directly at Kala Patthar (5,545 m) or Annapurna Sanctuary for tea with 360° mountain views.",
    img: "/images/everest-base-camp-helicopter-tour.jpg",
  },
  {
    title: "Jungle Wildlife Safari",
    text: "Track endangered one-horned rhinoceros, Royal Bengal tigers, and exotic bird species across Chitwan and Bardia National Parks.",
    img: "/images/chitwan-national-park.jpg",
  },
  {
    title: "Cultural & Pilgrimage Tours",
    text: "Sacred journeys to Muktinath, Lumbini (birthplace of Buddha), Janaki Mandir, and Mount Kailash Mansarovar.",
    img: "/images/pilgrims-guide-muktinath-kali-gandaki.jpg",
  },
  {
    title: "Jeep & Motorbike Expeditions",
    text: "Rugged high-altitude 4x4 and Royal Enfield rides across the trans-Himalayan desert into the kingdom of Upper Mustang.",
    img: "/images/upper-mustang-motorbike-tour.jpg",
  },
  {
    title: "Adventure & Aerial Sports",
    text: "Tandem paragliding over Phewa Lake Pokhara and world-class canyon bungee jumping over the raging Kali Gandaki gorge.",
    img: "/images/paragliding-in-sarangkot-photo.jpg",
  },
];

export const packages: PackageItem[] = [
  {
    slug: "everest-base-camp-trek",
    title: "Everest Base Camp Trek",
    price: "$2,000",
    days: "14 Days",
    img: "/images/everest-base-camp-sunrise.jpg",
    places: ["Everest Region"],
    difficulty: "Challenging",
    maxAltitude: "5,545 m",
  },
  {
    slug: "annapurna-base-camp-trek",
    title: "Annapurna Base Camp Trek",
    price: "$1,550",
    days: "10 Days",
    img: "/images/annapurna-base-camp.webp",
    places: ["Annapurna Region"],
    difficulty: "Moderate",
    maxAltitude: "4,130 m",
  },
  {
    slug: "upper-mustang-tour",
    title: "Upper Mustang & Lo Manthang",
    price: "$1,750",
    days: "12 Days",
    img: "/images/upper-mustang.jpg",
    places: ["Mustang Region"],
    difficulty: "Moderate",
    maxAltitude: "3,840 m",
  },
  {
    slug: "langtang-valley-trek",
    title: "Langtang Valley & Kyanjin Ri",
    price: "$790",
    days: "9 Days",
    img: "/images/langtang-valley.jpg",
    places: ["Langtang Region"],
    difficulty: "Moderate",
    maxAltitude: "4,773 m",
  },
  {
    slug: "gokyo-lakes-trek",
    title: "Gokyo Lakes & Gokyo Ri Trek",
    price: "$2,350",
    days: "12 Days",
    img: "/images/gokyo-lakes-trek.jpg",
    places: ["Everest Region"],
    difficulty: "Challenging",
    maxAltitude: "5,357 m",
  },
  {
    slug: "annapurna-circuit-trek",
    title: "Annapurna Circuit & Thorong La",
    price: "$2,150",
    days: "15 Days",
    img: "/images/short-annapurna-circuit.webp",
    places: ["Annapurna Region"],
    difficulty: "Challenging",
    maxAltitude: "5,416 m",
  },
  {
    slug: "manaslu-circuit-trek",
    title: "Manaslu Circuit & Larke Pass",
    price: "$2,500",
    days: "16 Days",
    img: "/images/manaslu-circuit.jpg",
    places: ["Manaslu Region"],
    difficulty: "Strenuous",
    maxAltitude: "5,106 m",
  },
  {
    slug: "mardi-himal-trek",
    title: "Mardi Himal Trek",
    price: "$1,200",
    days: "9 Days",
    img: "/images/mardi-himal-trek.webp",
    places: ["Annapurna", "Pokhara"],
    difficulty: "Moderate",
    maxAltitude: "4,500 m",
  },
  {
    slug: "ama-dablam-expedition",
    title: "Ama Dablam Expedition",
    price: "$5,400",
    days: "30 Days",
    img: "/images/ama-dablam-peak.png",
    places: ["Everest Region"],
    difficulty: "Technical Climb",
    maxAltitude: "6,812 m",
  },
  {
    slug: "everest-helicopter-tour",
    title: "Everest Base Camp Helicopter Tour",
    price: "$1,900",
    days: "1 Day (4-5 hrs)",
    img: "/images/everest-base-camp-helicopter-tour.jpg",
    places: ["Everest Region"],
    difficulty: "Easy",
    maxAltitude: "5,545 m",
  },
  {
    slug: "chitwan-bardia-wildlife-safari",
    title: "Chitwan & Bardia Wildlife Safari",
    price: "$650",
    days: "7 Days",
    img: "/images/sauraha-jungle-safari.jpg",
    places: ["Chitwan", "Bardia"],
    difficulty: "Easy",
    maxAltitude: "415 m",
  },
  {
    slug: "gosaikunda-trek",
    title: "Gosaikunda Lake Trek",
    price: "$1,850",
    days: "8 Days",
    img: "/images/gosaikunda-lake.jpg",
    places: ["Langtang Region"],
    difficulty: "Moderate",
    maxAltitude: "4,380 m",
  },
  {
    slug: "upper-mustang-jeep-tour",
    title: "Upper Mustang Jeep Tour",
    price: "$2,800",
    days: "7 Days",
    img: "/images/upper-mustang-jeep-tour.webp",
    places: ["Mustang Region"],
    difficulty: "Easy",
    maxAltitude: "3,840 m",
  },
  {
    slug: "kailash-mansarovar-yatra",
    title: "Kailash Mansarovar Yatra",
    price: "$2,450",
    days: "14 Days",
    img: "/images/kailash-mansarovar-tour.jpg",
    places: ["Tibet & Kailash"],
    difficulty: "Challenging",
    maxAltitude: "5,630 m",
  },
  {
    slug: "kathmandu-heritage-tour",
    title: "Kathmandu Valley Heritage Tour",
    price: "$390",
    days: "4 Days",
    img: "/images/kathmandu-durbar-square-photo.jpg",
    places: ["Kathmandu Valley"],
    difficulty: "Easy",
    maxAltitude: "1,400 m",
  },
];

export const trips: TripItem[] = [
  {
    slug: "everest-three-passes-trek",
    title: "Everest Three Passes Trek",
    price: "$2,500",
    off: "15% Off",
    days: "19 Days",
    places: ["Everest Region", "Khumbu"],
    img: "/images/everest-three-passes-trek.jpg",
  },
  {
    slug: "annapurna-base-camp-trek",
    title: "Annapurna Base Camp Trek",
    price: "$1,550",
    off: "10% Off",
    days: "10 Days",
    places: ["Annapurna", "Machapuchare"],
    img: "/images/annapurna-base-camp.webp",
  },
  {
    slug: "upper-mustang-motorbike-tour",
    title: "Upper Mustang Motorbike Tour",
    price: "$4,000",
    off: "12% Off",
    days: "7 Days",
    places: ["Mustang", "Lo Manthang"],
    img: "/images/upper-mustang-motorbike-tour.jpg",
  },
  {
    slug: "mardi-himal-trek",
    title: "Mardi Himal Trek",
    price: "$1,200",
    off: "8% Off",
    days: "9 Days",
    places: ["Annapurna", "Pokhara"],
    img: "/images/mardi-himal-trek.webp",
  },
];

export const deals: DealItem[] = [
  {
    slug: "langtang-valley-trek",
    title: "Langtang Valley & Kyanjin Ri",
    was: "$950",
    price: "$790",
    off: "17% Off",
    days: "9 Days",
    places: ["Langtang Region"],
    img: "/images/langtang-valley.jpg",
  },
  {
    slug: "abc-helicopter-tour",
    title: "Annapurna Base Camp Helicopter Tour",
    was: "$1,100",
    price: "$890",
    off: "19% Off",
    days: "1 Day",
    places: ["Annapurna", "Pokhara"],
    img: "/images/annapurna-base-camp-helicopter-tour.jpg",
  },
  {
    slug: "chitwan-bardia-wildlife-safari",
    title: "Chitwan & Bardia Wildlife Safari",
    was: "$800",
    price: "$650",
    off: "18% Off",
    days: "7 Days",
    places: ["Chitwan National Park"],
    img: "/images/chitwan-national-park.jpg",
  },
];

export const posts = [
  {
    title: "Complete Guide to Everest Base Camp Trekking",
    category: "High Altitude",
    text: "Everything you need to know about preparing for EBC: gear essentials, acclimatisation schedules in Namche Bazaar, altitude sickness prevention, and teahouse life.",
    img: "/images/ebc-trek.jpg",
  },
  {
    title: "Best Time to Trek Annapurna & Thorong La Pass",
    category: "Trek Planning",
    text: "Comparing Spring rhododendron blooms with Autumn crystal clear Himalayan mountain views. When to go, what temperatures to expect, and trail conditions.",
    img: "/images/annapurna-region.jpg",
  },
  {
    title: "Exploring the Ancient Walled City of Lo Manthang",
    category: "Culture & Heritage",
    text: "A journey through the wind-carved valleys of Upper Mustang, centuries-old Buddhist gompas, sacred cliff meditation caves, and unique Tibetan heritage.",
    img: "/images/upper-mustang.jpg",
  },
];

export const features = [
  {
    title: "Licensed Local Sherpa Guides",
    text: "Our mountain guides are certified, government licensed locals with decades of high-altitude experience and deep passion for the Himalayas.",
  },
  {
    title: "100% Customizable Itineraries",
    text: "Tailor your trekking pace, acclimatisation schedule, group size, and accommodation style to match your dream adventure.",
  },
  {
    title: "Transparent & Direct Pricing",
    text: "We are a Kathmandu-based registered agency. Booking direct means no middleman fees, fair wages for our porters, and best local prices.",
  },
  {
    title: "Safety & Emergency Protocols",
    text: "Every expedition includes oxygen saturation monitoring, first aid readiness, comprehensive insurance support, and 24/7 helicopter rescue coordination.",
  },
];

export const counters = [
  { label: "Happy Trekkers", value: 2450 },
  { label: "Curated Packages", value: 52 },
  { label: "Himalayan Peaks", value: 14 },
  { label: "Years Experience", value: 16 },
];

export interface HeroSlide {
  image: string;
  title: string;
  subtitle: string;
  highlight: string;
}

export const heroSlides: HeroSlide[] = [
  {
    image: "/assets/hero-himalaya-DrS97LmK.jpg",
    title: "Find Your Himalayan Adventure",
    subtitle:
      "Direct Booking with Local Sherpa Guides in Kathmandu · Everest, Annapurna, Mustang & Kailash",
    highlight: "100% Safety Record · Certified Mountain Guides",
  },
  {
    image: "/assets/region-annapurna-village-D26nnyfn.jpg",
    title: "Trek the Annapurna Sanctuary",
    subtitle:
      "Walk through rhododendron forests beneath Machhapuchhre to the heart of the Annapurna Massif",
    highlight: "Moderate to Challenging · 7 to 15 Days",
  },
  {
    image: "/assets/region-mustang-lo-manthang-B0XvWSGn.jpg",
    title: "Discover Hidden Upper Mustang",
    subtitle:
      "Explore the ancient forbidden walled kingdom of Lo Manthang and centuries-old Tibetan monasteries",
    highlight: "Rain Shadow Trekking · Best in Summer & Autumn",
  },
  {
    image: "/assets/gallery-gokyo-lake-reflection-BtoS1Y9X.jpg",
    title: "Gokyo Lakes & Everest Panorama",
    subtitle:
      "Gaze over cobalt blue glacial tarns and four 8,000-meter peaks from Gokyo Ri (5,357 m)",
    highlight: "High Alpine Wilderness · Acclimatised Treks",
  },
  {
    image: "/assets/region-everest-trekkers-smuIrnxG.jpg",
    title: "Everest Base Camp & Kala Patthar",
    subtitle:
      "Stand in the shadow of Mount Everest (8,848.86 m) with our Kathmandu expedition leaders",
    highlight: "Iconic Teahouse Route · Lukla Mountain Flight",
  },
];

export interface GalleryPhoto {
  id: string;
  title: string;
  location: string;
  category: "Everest" | "Annapurna" | "Langtang" | "Mustang" | "Culture & Wildlife";
  image: string;
}

export const galleryPhotos: GalleryPhoto[] = [
  {
    id: "g-1",
    title: "Dingboche Trail towards Ama Dablam",
    location: "Everest Region (4,410 m)",
    category: "Everest",
    image: "/assets/gallery-everest-dingboche-trail-DMSnjb4m.jpg",
  },
  {
    id: "g-2",
    title: "Gokyo Glacial Lake Turquoise Reflection",
    location: "Gokyo Ri, Khumbu (4,750 m)",
    category: "Everest",
    image: "/assets/gallery-gokyo-lake-reflection-BtoS1Y9X.jpg",
  },
  {
    id: "g-3",
    title: "Annapurna Mountain Trail Rhododendron Path",
    location: "Annapurna Conservation Area",
    category: "Annapurna",
    image: "/assets/gallery-annapurna-trail-lMf23I0A.jpg",
  },
  {
    id: "g-4",
    title: "Terraced Himalayan Mountain Farming Village",
    location: "Ghandruk & Modi Khola Valley",
    category: "Annapurna",
    image: "/assets/gallery-annapurna-village-terrace-DgeLzEbs.jpg",
  },
  {
    id: "g-5",
    title: "Kyanjin Gompa & Surrounding Glaciers",
    location: "Langtang Valley (3,870 m)",
    category: "Langtang",
    image: "/assets/gallery-langtang-kyanjin-close-BnbDs_b5.jpg",
  },
  {
    id: "g-6",
    title: "Glacial Valley Panorama of Langtang Village",
    location: "Langtang National Park",
    category: "Langtang",
    image: "/assets/gallery-langtang-village-glacier-CM3ThTTQ.jpg",
  },
  {
    id: "g-7",
    title: "Traditional Himalayan High Stone Houses",
    location: "Upper Mustang & Nar Phu",
    category: "Mustang",
    image: "/assets/gallery-hill-village-stone-houses-RlDC_mTv.jpg",
  },
  {
    id: "g-8",
    title: "Ancient Royal Walled Capital of Lo Manthang",
    location: "Upper Mustang (3,840 m)",
    category: "Mustang",
    image: "/assets/region-mustang-lo-manthang-B0XvWSGn.jpg",
  },
  {
    id: "g-9",
    title: "Krishna Mandir Stone Carvings at Patan Durbar",
    location: "Lalitpur UNESCO Heritage Site",
    category: "Culture & Wildlife",
    image: "/assets/gallery-patan-durbar-temple-BcZ9TqRc.jpg",
  },
  {
    id: "g-10",
    title: "Kathmandu Valley Historic Temple Courtyard",
    location: "Kathmandu Durbar Square",
    category: "Culture & Wildlife",
    image: "/assets/gallery-kathmandu-durbar-temple-CZfIl7Kj.jpg",
  },
  {
    id: "g-11",
    title: "Himalayan Forest Jungle Cascading Waterfall",
    location: "Annapurna Foothills & Chitwan",
    category: "Culture & Wildlife",
    image: "/assets/gallery-jungle-waterfall-CxQaKE9u.jpg",
  },
  {
    id: "g-12",
    title: "Endangered Greater One-Horned Rhinoceros",
    location: "Chitwan National Park Wetland",
    category: "Culture & Wildlife",
    image: "/assets/region-chitwan-rhino-knqlVUXn.jpg",
  },
];

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  bio: string;
  experience: string;
  initials: string;
  department: string;
  photo?: string;
}

export const teamMembers: TeamMember[] = [
  {
    id: "kshitij-sapkota",
    name: "Kshitij Sapkota",
    role: "CEO",
    bio: "Sets the direction for Sunrise Himalaya and oversees every department, from trip design to partnerships. 8+ years of experience in the Nepal travel industry.",
    experience: "8+ Years",
    initials: "KS",
    department: "Leadership",
    photo: "/assets/team-kshitij-sapkota.jpg",
  },
  {
    id: "sarmila-adhikari",
    name: "Sarmila Adhikari",
    role: "Founder & Lead Mountaineer",
    bio: "Founded Sunrise Himalaya and leads our flagship high-altitude expeditions and mountaineering routes. 7.5 years of experience in the Nepal travel industry.",
    experience: "7.5 Years",
    initials: "SA",
    department: "Founding & Expedition",
    photo: "/assets/team-sarmila-adhikari.jpg",
  },
  {
    id: "sangam-thapa",
    name: "Sangam Thapa",
    role: "Operations Director",
    bio: "Runs permits, logistics and the 24/7 emergency desk, keeping every departure on schedule. 7.5 years of experience in the Nepal travel industry.",
    experience: "7.5 Years",
    initials: "ST",
    department: "Operations & Logistics",
    photo: "/assets/team-sangam-thapa.jpg",
  },
  {
    id: "abhishek-sapkota",
    name: "Abhishek Sapkota",
    role: "Senior Trek Leader",
    bio: "Leads trekking groups on the ground, managing route planning, pacing and altitude safety. 7.5 years of experience in the Nepal travel industry.",
    experience: "7.5 Years",
    initials: "AS",
    department: "Field Guiding & Safety",
    photo: "/assets/team-abhishek-sapkota.jpg",
  },
  {
    id: "nisha-rana-magar",
    name: "Nisha Rana Magar",
    role: "Jr. Trek Leader",
    bio: "Supports our trek leaders on the trail with group coordination and day-to-day route logistics. 5 years of experience in the Nepal travel industry.",
    experience: "5 Years",
    initials: "NR",
    department: "Field Coordination",
    photo: "/assets/team-nisha-rana-magar.jpg",
  },
  {
    id: "nischal-khadka",
    name: "Nischal Khadka",
    role: "Driver",
    bio: "Drives Sunrise Himalaya's guests safely across Nepal's mountain roads and valley routes. 6 years of experience in the Nepal travel industry.",
    experience: "6 Years",
    initials: "NK",
    department: "Transport & Mobility",
    photo: "/assets/team-nischal-khadka.jpg",
  },
  {
    id: "sitaram-tiwari",
    name: "Sitaram Tiwari",
    role: "Driver",
    bio: "Drives Sunrise Himalaya's guests safely across Nepal's mountain roads and valley routes. 6 years of experience in the Nepal travel industry.",
    experience: "6 Years",
    initials: "ST",
    department: "Transport & Mobility",
    photo: "/assets/team-sitaram-tiwari.jpg",
  },
];
