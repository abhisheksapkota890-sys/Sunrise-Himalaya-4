import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Clock, Compass, Filter, MapPin, Mountain, Search } from "lucide-react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { PageHero } from "@/components/site/PageHero";
import { TourModal } from "@/components/site/TourModal";
import { SafeImage } from "@/components/site/SafeImage";
import { allTours, Tour } from "@/data/travel";

export const Route = createFileRoute("/trip-types")({
  head: () => ({
    meta: [
      {
        title: "All 52 Nepal Packages & Trekking Itineraries — Sunrise Himalaya",
      },
      {
        name: "description",
        content:
          "Browse all 52 authentic trekking, climbing, cultural and helicopter packages across Everest, Annapurna, Mustang, and Langtang with local Sherpa guides.",
      },
      {
        property: "og:title",
        content: "All Nepal Packages & Trekking Itineraries — Sunrise Himalaya",
      },
      {
        property: "og:description",
        content:
          "Browse all 52 authentic trekking, climbing, cultural and helicopter packages across Nepal.",
      },
    ],
  }),
  component: TripTypes,
});

const categories = [
  "All",
  "Trekking",
  "Helicopter Tours",
  "Wildlife Tours",
  "Cultural Tours",
  "Day Tours",
  "Mustang Region",
  "Everest Region",
  "Annapurna Region",
];

function TripTypes() {
  const [selectedCategory, setSelectedCategory] = React.useState("All");
  const [search, setSearch] = React.useState("");
  const [selectedTour, setSelectedTour] = React.useState<Tour | null>(null);
  const [modalOpen, setModalOpen] = React.useState(false);

  const filtered = allTours.filter((t) => {
    const matchesSearch =
      t.title.toLowerCase().includes(search.toLowerCase()) ||
      t.summary.toLowerCase().includes(search.toLowerCase()) ||
      t.categories.some((c) => c.toLowerCase().includes(search.toLowerCase()));

    if (!matchesSearch) return false;

    if (selectedCategory === "All") return true;

    return t.categories.some((c) => c.toLowerCase().includes(selectedCategory.toLowerCase()));
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <PageHero
        title="All Himalayan Packages"
        subtitle="52 curated trekking expeditions, scenic flights, cultural pilgrimages and wilderness safaris."
      />

      <section className="container-site py-16">
        {/* Search & Filter Controls */}
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div className="relative w-full max-w-md">
            <Search className="absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search packages by name, region or activity..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-sm border border-border bg-background py-2.5 pr-4 pl-10 text-sm text-foreground outline-none focus:border-primary"
            />
          </div>

          <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground">
            <Filter className="size-3.5 text-primary" />
            Showing {filtered.length} of {allTours.length} packages
          </div>
        </div>

        {/* Category Pills */}
        <div className="mt-6 flex flex-wrap gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`rounded-full px-4 py-1.5 text-xs font-semibold transition-all ${
                selectedCategory === cat
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "border border-border bg-background text-muted-foreground hover:border-primary hover:text-foreground"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Packages Grid */}
        <div className="mt-12 grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {filtered.map((t) => (
            <article
              key={t.slug}
              onClick={() => {
                setSelectedTour(t);
                setModalOpen(true);
              }}
              className="rara-card group cursor-pointer overflow-hidden bg-background"
            >
              <div className="relative overflow-hidden">
                <SafeImage
                  src={t.image}
                  alt={t.title}
                  className="h-48 w-full object-cover transition-transform duration-500 group-hover:scale-108"
                />
                <span className="absolute top-3 left-3 rounded-full bg-primary px-3 py-1 font-heading text-xs font-semibold text-primary-foreground shadow-sm">
                  ${typeof t.price === "number" ? t.price.toLocaleString() : t.price}
                </span>
                {t.difficulty && (
                  <span className="absolute top-3 right-3 rounded-full bg-black/75 px-2.5 py-0.5 text-[10px] font-medium text-white backdrop-blur-xs">
                    {t.difficulty}
                  </span>
                )}
              </div>
              <div className="p-4">
                <div className="flex flex-wrap gap-1">
                  {t.categories.slice(0, 2).map((c) => (
                    <span key={c} className="text-[10px] font-semibold text-primary">
                      {c}
                    </span>
                  ))}
                </div>
                <h2 className="mt-1 line-clamp-1 font-heading text-base font-bold text-[#111111] transition-colors group-hover:text-primary">
                  {t.title}
                </h2>
                <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
                  {t.summary}
                </p>
                <div className="mt-3 flex items-center justify-between border-t border-border pt-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock className="size-3 text-primary" /> {t.duration}
                  </span>
                  {t.maxAltitude && (
                    <span className="flex items-center gap-1 font-medium text-foreground">
                      <Mountain className="size-3 text-primary" /> {t.maxAltitude}
                    </span>
                  )}
                </div>
                <button type="button" className="btn-rara-outline mt-3.5 w-full py-2 text-xs">
                  View Details &amp; Itinerary
                </button>
              </div>
            </article>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="mt-16 text-center py-12 border border-dashed border-border rounded-lg">
            <Compass className="size-10 mx-auto text-muted-foreground mb-3" />
            <p className="font-heading font-bold text-lg">No packages found</p>
            <p className="text-xs text-muted-foreground mt-1">
              Try adjusting your search terms or selecting a different category.
            </p>
            <button
              onClick={() => {
                setSearch("");
                setSelectedCategory("All");
              }}
              className="mt-4 bg-primary text-primary-foreground text-xs font-semibold px-4 py-2 rounded-xs"
            >
              Reset Filters
            </button>
          </div>
        )}
      </section>

      <Footer />
      <TourModal tour={selectedTour} open={modalOpen} onOpenChange={setModalOpen} />
    </div>
  );
}
