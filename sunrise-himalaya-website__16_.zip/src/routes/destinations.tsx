import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Clock, MapPin, Mountain } from "lucide-react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { PageHero } from "@/components/site/PageHero";
import { TourModal } from "@/components/site/TourModal";
import { SafeImage } from "@/components/site/SafeImage";
import { allTours, destinations, Tour } from "@/data/travel";

export const Route = createFileRoute("/destinations")({
  head: () => ({
    meta: [
      {
        title: "Nepal Destinations & Trekking Regions — Sunrise Himalaya",
      },
      {
        name: "description",
        content:
          "Discover Nepal's most revered trekking regions: Everest, Annapurna, Mustang, Langtang, Chitwan, and the historic Kathmandu Valley.",
      },
      {
        property: "og:title",
        content: "Nepal Destinations & Trekking Regions — Sunrise Himalaya",
      },
      {
        property: "og:description",
        content:
          "Everest, Annapurna, Mustang, Langtang, Chitwan, and Kathmandu Valley trekking destinations.",
      },
    ],
  }),
  component: Destinations,
});

const regionsList = [
  "All Destinations",
  "Everest Region",
  "Annapurna Region",
  "Mustang Region",
  "Langtang Region",
  "Chitwan Region",
  "Kathmandu Region",
];

function Destinations() {
  const [activeRegion, setActiveRegion] = React.useState("All Destinations");
  const [selectedTour, setSelectedTour] = React.useState<Tour | null>(null);
  const [modalOpen, setModalOpen] = React.useState(false);

  const filteredTours = allTours.filter((t) => {
    if (activeRegion === "All Destinations") return true;
    const clean = activeRegion.replace(" Region", "").toLowerCase();
    return (
      t.categories.some((c) => c.toLowerCase().includes(clean)) ||
      t.title.toLowerCase().includes(clean)
    );
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <PageHero
        title="Himalayan Destinations"
        subtitle="Where would you like to trek? Explore Nepal's iconic mountain ranges and valley kingdoms."
      />

      <section className="container-site py-16">
        {/* Region Highlights Cards */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {destinations.map((d) => (
            <div
              key={d.name}
              onClick={() => setActiveRegion(d.name)}
              className={`group relative cursor-pointer overflow-hidden rounded-md border-2 transition-all duration-300 ${
                activeRegion === d.name
                  ? "border-primary shadow-lg ring-2 ring-primary/30"
                  : "border-transparent shadow-sm hover:-translate-y-1 hover:shadow-md"
              }`}
            >
              <div className="relative h-64 overflow-hidden">
                <SafeImage
                  src={d.image}
                  alt={d.name}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
                <span className="absolute top-3 right-3 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                  {d.packs} Packages
                </span>
                <div className="absolute right-4 bottom-4 left-4 text-white">
                  <h2 className="font-heading text-xl font-bold">{d.name}</h2>
                  <p className="mt-1 line-clamp-2 text-xs text-white/85">{d.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Region Filter Buttons */}
        <div className="mt-14 flex flex-wrap justify-center gap-2">
          {regionsList.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setActiveRegion(r)}
              className={`rounded-full px-5 py-2 text-xs font-semibold transition-all ${
                activeRegion === r
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "border border-border bg-background text-muted-foreground hover:border-primary hover:text-foreground"
              }`}
            >
              {r}
            </button>
          ))}
        </div>

        {/* Filtered Regional Packages Grid */}
        <div className="mt-12">
          <div className="mb-6 flex items-center justify-between">
            <h3 className="font-heading text-xl font-bold">
              {activeRegion === "All Destinations"
                ? "All Himalayan Packages"
                : `${activeRegion} Packages`}
            </h3>
            <span className="text-xs text-muted-foreground font-semibold">
              {filteredTours.length} itineraries found
            </span>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {filteredTours.map((t) => (
              <article
                key={t.slug}
                onClick={() => {
                  setSelectedTour(t);
                  setModalOpen(true);
                }}
                className="rara-card group cursor-pointer overflow-hidden bg-background"
              >
                <div className="relative overflow-hidden">
                  <SafeImage
                    src={t.image}
                    alt={t.title}
                    className="h-48 w-full object-cover transition-transform duration-500 group-hover:scale-108"
                  />
                  <span className="absolute top-3 left-3 rounded-full bg-primary px-3 py-1 font-heading text-xs font-semibold text-primary-foreground shadow-sm">
                    ${t.price}
                  </span>
                  {t.difficulty && (
                    <span className="absolute top-3 right-3 rounded-full bg-black/75 px-2.5 py-0.5 text-[10px] font-medium text-white backdrop-blur-xs">
                      {t.difficulty}
                    </span>
                  )}
                </div>
                <div className="p-4">
                  <h4 className="line-clamp-1 font-heading text-base font-bold text-[#111111] transition-colors group-hover:text-primary">
                    {t.title}
                  </h4>
                  <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
                    {t.summary}
                  </p>
                  <div className="mt-3 flex items-center justify-between border-t border-border pt-2.5 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="size-3 text-primary" /> {t.duration}
                    </span>
                    {t.maxAltitude && (
                      <span className="flex items-center gap-1 font-medium text-foreground">
                        <Mountain className="size-3 text-primary" /> {t.maxAltitude}
                      </span>
                    )}
                  </div>
                  <button type="button" className="btn-rara-outline mt-3.5 w-full py-2 text-xs">
                    View Details
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <Footer />
      <TourModal tour={selectedTour} open={modalOpen} onOpenChange={setModalOpen} />
    </div>
  );
}
