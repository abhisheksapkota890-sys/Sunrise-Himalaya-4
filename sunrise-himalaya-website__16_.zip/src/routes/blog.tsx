import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { PageHero } from "@/components/site/PageHero";
import { posts } from "@/data/travel";

export const Route = createFileRoute("/blog")({
  head: () => ({
    meta: [
      { title: "Travel Blog — Stories, Guides & Tips | Travel Agency" },
      {
        name: "description",
        content:
          "Read travel guides, camping stories and mountaineering tips from our team of local guides and adventure travellers.",
      },
      { property: "og:title", content: "Travel Blog — Travel Agency" },
      {
        property: "og:description",
        content: "Guides, camping stories and mountaineering tips from our local guides.",
      },
    ],
  }),
  component: Blog,
});

function Blog() {
  const all = [...posts, ...posts];
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <PageHero title="Blog" subtitle="Stories, guides and tips from the road." />

      <section className="container-site grid gap-8 py-20 md:grid-cols-3">
        {all.map((p, i) => (
          <article key={i} className="overflow-hidden bg-background shadow-sm">
            <img src={p.img} alt={p.title} loading="lazy" className="h-52 w-full object-cover" />
            <div className="p-5">
              <span className="text-xs font-semibold tracking-wide text-primary uppercase">
                {p.category}
              </span>
              <h2 className="mt-2 font-heading text-lg font-bold">{p.title}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{p.text}</p>
              <p className="mt-4 text-xs text-muted-foreground">By Rara Theme</p>
            </div>
          </article>
        ))}
      </section>

      <Footer />
    </div>
  );
}
