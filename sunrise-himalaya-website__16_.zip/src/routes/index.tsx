import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  Camera,
  ChevronLeft,
  ChevronRight,
  Clock,
  Compass,
  Expand,
  MapPin,
  MessageCircle,
  Mountain,
  Pause,
  Play,
  Search,
  ShieldCheck,
  ZoomIn,
} from "lucide-react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { TourModal } from "@/components/site/TourModal";
import { SafeImage } from "@/components/site/SafeImage";
import { PhotoLightbox, LightboxImage } from "@/components/site/PhotoLightbox";
import { AnimatedCounter } from "@/components/site/AnimatedCounter";
import {
  aboutImg,
  activities,
  allTours,
  counters,
  deals,
  destinations,
  features,
  galleryPhotos,
  heroImg,
  heroSlides,
  packages,
  posts,
  Tour,
  trips,
} from "@/data/travel";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      {
        title: "Sunrise Himalaya Travel & Adventure — Nepal Treks, Tours & Expeditions",
      },
      {
        name: "description",
        content:
          "Everest Base Camp, Annapurna Circuit, Langtang and Upper Mustang treks, cultural tours, wildlife safaris, and helicopter charters with licensed Nepali Sherpa guides.",
      },
      {
        property: "og:title",
        content: "Sunrise Himalaya Travel & Adventure — Nepal Treks & Tours",
      },
      {
        property: "og:description",
        content:
          "Iconic Himalayan treks, scenic helicopter flights, cultural journeys, and wildlife safaris booked directly with Kathmandu experts.",
      },
      { property: "og:image", content: heroImg },
      { name: "twitter:image", content: heroImg },
    ],
  }),
  component: Home,
});

function Home() {
  const [selectedTour, setSelectedTour] = React.useState<Tour | null>(null);
  const [modalOpen, setModalOpen] = React.useState(false);
  const [searchQuery, setSearchQuery] = React.useState("");
  const [selectedRegion, setSelectedRegion] = React.useState("All Regions");

  // Hero Carousel State
  const [currentHeroSlide, setCurrentHeroSlide] = React.useState(0);
  const [isHeroPlaying, setIsHeroPlaying] = React.useState(true);

  // Gallery Filter & Lightbox State
  const [activeGalleryTab, setActiveGalleryTab] = React.useState("All");
  const [lightboxOpen, setLightboxOpen] = React.useState(false);
  const [lightboxIndex, setLightboxIndex] = React.useState(0);

  // Auto-advance hero slides
  React.useEffect(() => {
    if (!isHeroPlaying) return;
    const interval = setInterval(() => {
      setCurrentHeroSlide((prev) => (prev + 1) % heroSlides.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [isHeroPlaying]);

  const nextHeroSlide = () => {
    setCurrentHeroSlide((prev) => (prev + 1) % heroSlides.length);
  };

  const prevHeroSlide = () => {
    setCurrentHeroSlide((prev) => (prev - 1 + heroSlides.length) % heroSlides.length);
  };

  const openTourBySlug = (slug: string) => {
    const found = allTours.find((t) => t.slug === slug);
    if (found) {
      setSelectedTour(found);
      setModalOpen(true);
    }
  };

  const openTourByTitle = (title: string) => {
    const found =
      allTours.find((t) => t.title.toLowerCase() === title.toLowerCase()) ||
      allTours.find((t) => t.title.toLowerCase().includes(title.toLowerCase()));
    if (found) {
      setSelectedTour(found);
      setModalOpen(true);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim() && selectedRegion === "All Regions") return;
    const match = allTours.find((t) => {
      const matchesText = searchQuery
        ? t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          t.summary.toLowerCase().includes(searchQuery.toLowerCase())
        : true;
      const matchesRegion =
        selectedRegion === "All Regions" ||
        t.categories.some((c) => c.toLowerCase().includes(selectedRegion.toLowerCase()));
      return matchesText && matchesRegion;
    });
    if (match) {
      setSelectedTour(match);
      setModalOpen(true);
    }
  };

  // Filtered gallery items
  const filteredGallery = React.useMemo(() => {
    if (activeGalleryTab === "All") return galleryPhotos;
    return galleryPhotos.filter((p) => p.category.includes(activeGalleryTab));
  }, [activeGalleryTab]);

  const galleryLightboxImages: LightboxImage[] = React.useMemo(() => {
    return filteredGallery.map((p) => ({
      src: p.image,
      title: p.title,
      location: p.location,
      category: p.category,
    }));
  }, [filteredGallery]);

  const openGalleryLightbox = (idx: number) => {
    setLightboxIndex(idx);
    setLightboxOpen(true);
  };

  const activeHero = heroSlides[currentHeroSlide] || heroSlides[0];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Himalayan Hero Video */}
      <section className="relative h-[560px] overflow-hidden bg-slate-950 sm:h-[620px]">
        <video
          className="absolute inset-0 h-full w-full object-cover"
          src="/assets/hero-video.mp4"
          poster={heroImg}
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/55 to-black/35" />

        {/* Hero Overlay Content */}
        <div className="container-site absolute inset-0 z-20 flex flex-col items-center justify-center px-4 text-center">
          <h1 className="max-w-4xl font-heading text-4xl font-bold text-white drop-shadow-md transition-all duration-500 sm:text-5xl md:text-6xl">
            {activeHero.title}
          </h1>

          <p className="mt-3 max-w-2xl text-sm text-white/90 drop-shadow-sm transition-all duration-500 sm:text-base md:text-lg">
            {activeHero.subtitle}
          </p>

          <form
            onSubmit={handleSearch}
            className="mt-8 flex w-full max-w-2xl flex-col gap-2 rounded-full bg-black/60 p-2 backdrop-blur-md sm:flex-row sm:gap-2 shadow-2xl border border-white/20"
          >
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search Everest, Annapurna, Mustang, Safari..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-full bg-background/95 py-3 pl-11 pr-4 text-sm text-foreground outline-none ring-primary focus:ring-2"
              />
            </div>
            <button type="submit" className="btn-rara-primary text-xs py-3 px-8 whitespace-nowrap">
              Search Treks
            </button>
          </form>
        </div>
      </section>

      {/* Quick Search Selector Bar */}
      <div className="container-site relative z-30 -mt-8">
        <div className="grid gap-3 rounded-lg bg-background p-3.5 shadow-xl border border-border sm:grid-cols-2 md:grid-cols-4">
          <label className="flex items-center gap-2.5 rounded-md border border-border px-3.5 py-3 text-sm text-muted-foreground">
            <MapPin className="size-4 text-primary shrink-0" />
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              aria-label="Filter by Himalayan Region"
              className="w-full bg-transparent text-foreground font-heading text-xs font-semibold outline-none cursor-pointer"
            >
              <option value="All Regions">All Himalayan Regions</option>
              <option value="Everest">Everest Region</option>
              <option value="Annapurna">Annapurna Region</option>
              <option value="Mustang">Mustang Region</option>
              <option value="Langtang">Langtang Region</option>
              <option value="Chitwan">Chitwan & Safari</option>
              <option value="Kathmandu">Kathmandu Valley</option>
            </select>
          </label>

          <label className="flex items-center gap-2.5 rounded-md border border-border px-3.5 py-3 text-sm text-muted-foreground">
            <Mountain className="size-4 text-primary shrink-0" />
            <select
              aria-label="Filter by Trip Category"
              onChange={(e) => {
                const tour = allTours.find((t) => t.categories.includes(e.target.value));
                if (tour) {
                  setSelectedTour(tour);
                  setModalOpen(true);
                }
              }}
              className="w-full bg-transparent text-foreground font-heading text-xs font-semibold outline-none cursor-pointer"
            >
              <option value="">Trip Categories</option>
              <option value="Trekking">High Altitude Trekking</option>
              <option value="Helicopter Tours">Helicopter Tours</option>
              <option value="Wildlife Tours">Wildlife Safaris</option>
              <option value="Cultural Tours">Cultural & Heritage</option>
              <option value="Adventure Tours">Motorbike & 4x4 Jeep</option>
            </select>
          </label>

          <label className="flex items-center gap-2.5 rounded-md border border-border px-3.5 py-3 text-sm text-muted-foreground">
            <Clock className="size-4 text-primary shrink-0" />
            <select
              aria-label="Filter by Duration"
              onChange={(e) => {
                const days = parseInt(e.target.value);
                const tour = allTours.find((t) => {
                  const num = parseInt(t.duration);
                  if (days === 7) return num <= 7;
                  if (days === 12) return num > 7 && num <= 12;
                  if (days === 15) return num > 12;
                  return false;
                });
                if (tour) {
                  setSelectedTour(tour);
                  setModalOpen(true);
                }
              }}
              className="w-full bg-transparent text-foreground font-heading text-xs font-semibold outline-none cursor-pointer"
            >
              <option value="">Filter by Duration</option>
              <option value="7">1 to 7 Days (Short / Day Trips)</option>
              <option value="12">8 to 12 Days (Classic Treks)</option>
              <option value="15">13+ Days (Extended / Passes)</option>
            </select>
          </label>

          <Link to="/trip-types" className="btn-rara-primary text-xs py-3 px-6">
            <Compass className="size-4" /> Browse All 52 Packages
          </Link>
        </div>
      </div>

      {/* About Section */}
      <section className="container-site grid items-center gap-12 py-20 md:grid-cols-2">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-wider text-primary uppercase">
            <ShieldCheck className="size-4" /> Certified Nepal Adventure Operator
          </div>
          <h2 className="section-title-left mt-2">
            Welcome to Sunrise Himalaya Travel &amp; Adventure
          </h2>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
            Based in Lazimpat, Kathmandu, we specialize in tailor-made trekking expeditions,
            high-altitude climbing, helicopter sightseeings, and cultural tours across Nepal, Tibet,
            and Bhutan.
          </p>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            Our guides are native to the Khumbu, Annapurna, and Langtang valleys with government
            certifications, wilderness first-aid training, and a deep respect for mountain
            communities. When you book with us, you enjoy middleman-free pricing and authentic
            Himalayan hospitality.
          </p>
          <div className="mt-7 flex flex-wrap gap-4">
            <Link to="/about" className="btn-rara-primary text-xs py-3 px-7">
              Learn More About Us
            </Link>
            <a
              href="https://wa.me/9779851165293"
              target="_blank"
              rel="noreferrer"
              className="btn-rara-outline text-xs py-3 px-7"
            >
              <MessageCircle className="size-4" />
              <span>Chat on WhatsApp</span>
            </a>
          </div>
        </div>
        <div className="relative overflow-hidden rounded-md shadow-xl group">
          <SafeImage
            src={aboutImg}
            alt="Annapurna village with traditional houses and snowy peaks"
            className="h-96 w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute right-4 bottom-4 rounded-md bg-black/75 p-4 text-white backdrop-blur-xs border border-white/10">
            <p className="font-heading text-lg font-bold">16+ Years</p>
            <p className="text-xs text-white/80">Guiding Trekkers across the Himalayas</p>
          </div>
        </div>
      </section>

      {/* Destinations / Regions Showcase */}
      <section className="bg-muted py-20">
        <div className="container-site">
          <div className="text-center">
            <h2 className="section-title">Explore Himalayan Regions</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Choose your destination across Nepal's iconic mountain ranges and valleys
            </p>
          </div>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {destinations.map((d) => (
              <article
                key={d.name}
                className="rara-card group relative cursor-pointer overflow-hidden bg-background"
                onClick={() => {
                  const tour = allTours.find((t) =>
                    t.categories.some((c) => c.toLowerCase().includes(d.name.toLowerCase())),
                  );
                  if (tour) {
                    setSelectedTour(tour);
                    setModalOpen(true);
                  }
                }}
              >
                <div className="relative h-64 overflow-hidden">
                  <SafeImage
                    src={d.image}
                    alt={d.name}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-108"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent" />
                  <span className="absolute top-3.5 right-3.5 rounded-full bg-primary px-3 py-1 font-heading text-xs font-semibold text-primary-foreground shadow-sm">
                    {d.packs} Packages
                  </span>
                  <div className="absolute right-4 bottom-4 left-4 text-white">
                    <h3 className="font-heading text-xl font-bold transition-colors group-hover:text-primary">
                      {d.name}
                    </h3>
                    <p className="mt-1 line-clamp-2 text-xs text-white/85 leading-relaxed">
                      {d.description}
                    </p>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Packages Grid */}
      <section id="packages" className="container-site py-20">
        <div className="flex flex-col items-center justify-between gap-4 text-center md:flex-row md:text-left">
          <div>
            <h2 className="section-title-left">Popular Himalayan Packages</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Hand-picked itineraries with certified guides, teahouse stays, and permits included
            </p>
          </div>
          <Link to="/trip-types" className="btn-rara-primary text-xs py-2.5 px-6">
            View All 52 Packages <ArrowRight className="size-4" />
          </Link>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5">
          {packages.map((p) => (
            <article
              key={p.slug}
              onClick={() => openTourBySlug(p.slug)}
              className="rara-card group cursor-pointer overflow-hidden bg-background text-center"
            >
              <div className="relative overflow-hidden">
                <SafeImage
                  src={p.img}
                  alt={p.title}
                  className="aspect-square w-full object-cover transition-transform duration-500 group-hover:scale-108"
                />
                <span className="absolute top-2 left-2 rounded-full bg-primary px-2.5 py-1 font-heading text-xs font-semibold text-primary-foreground shadow-sm">
                  {p.price}
                </span>
                {p.difficulty && (
                  <span className="absolute right-2 bottom-2 rounded-full bg-black/75 px-2 py-0.5 text-[10px] font-medium text-white backdrop-blur-xs">
                    {p.difficulty}
                  </span>
                )}
              </div>
              <div className="p-3.5">
                <h3 className="line-clamp-1 font-heading text-sm font-bold text-[#111111] transition-colors group-hover:text-primary">
                  {p.title}
                </h3>
                <p className="mt-1.5 flex items-center justify-center gap-1 text-xs text-muted-foreground">
                  <Clock className="size-3 text-primary" /> {p.days}
                </p>
                <button type="button" className="btn-rara-outline mt-3 w-full py-1.5 text-xs">
                  View Details
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Why Travel With Us */}
      <section className="bg-muted py-20">
        <div className="container-site">
          <h2 className="section-title text-center">Why Trek With Sunrise Himalaya</h2>
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {features.map((f) => (
              <div key={f.title} className="rara-card bg-background p-7 transition-all">
                <div className="mb-4 inline-flex size-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <ShieldCheck className="size-5" />
                </div>
                <h3 className="font-heading text-base font-bold text-[#111111]">{f.title}</h3>
                <p className="mt-2.5 text-xs text-muted-foreground leading-relaxed">{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Signature Trips */}
      <section className="container-site py-20">
        <h2 className="section-title text-center">Featured Signature Trips</h2>
        <p className="mt-2 text-center text-sm text-muted-foreground">
          Top-rated expeditions and multi-day treks recommended by our lead guides
        </p>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {trips.map((t) => (
            <article
              key={t.slug}
              onClick={() => openTourBySlug(t.slug)}
              className="rara-card group cursor-pointer overflow-hidden bg-background"
            >
              <div className="relative overflow-hidden">
                <SafeImage
                  src={t.img}
                  alt={t.title}
                  className="h-48 w-full object-cover transition-transform duration-500 group-hover:scale-108"
                />
                <span className="absolute top-3 left-3 rounded-full bg-primary px-3 py-1 font-heading text-xs font-semibold text-primary-foreground shadow-sm">
                  {t.price}
                </span>
                <span className="rara-ribbon">{t.off}</span>
              </div>
              <div className="p-4.5">
                <h3 className="line-clamp-1 font-heading text-base font-bold text-[#111111] transition-colors group-hover:text-primary">
                  {t.title}
                </h3>
                <p className="mt-1 text-xs font-semibold text-primary">{t.places.join(", ")}</p>
                <p className="mt-2.5 flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Clock className="size-3.5 text-primary" /> {t.days}
                </p>
                <button type="button" className="btn-rara-outline mt-4 w-full py-2 text-xs">
                  View Details &amp; Itinerary
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Counters */}
      <section className="relative overflow-hidden py-16">
        <SafeImage src={heroImg} alt="" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-primary/90 backdrop-blur-xs" />
        <div className="container-site relative z-10 grid grid-cols-2 items-center gap-8 text-center md:grid-cols-4">
          {counters.map((c) => (
            <div key={c.label} className="p-4">
              <p className="font-heading text-4xl font-extrabold text-white tracking-tight drop-shadow-sm md:text-5xl">
                <AnimatedCounter value={c.value} />
              </p>
              <p className="mt-2 font-heading text-xs font-semibold uppercase tracking-wider text-white/90">
                {c.label}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Hot Deals */}
      <section className="container-site py-20">
        <div className="text-center">
          <h2 className="section-title">Seasonal Deals &amp; Offers</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Special discounts on select trekking departures and luxury helicopter tours
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {deals.map((d) => (
            <article
              key={d.slug}
              onClick={() => openTourBySlug(d.slug)}
              className="rara-card group cursor-pointer overflow-hidden bg-background"
            >
              <div className="relative overflow-hidden">
                <SafeImage
                  src={d.img}
                  alt={d.title}
                  className="h-56 w-full object-cover transition-transform duration-500 group-hover:scale-108"
                />
                <span className="rara-ribbon">{d.off}</span>
              </div>
              <div className="p-5">
                <p className="text-sm">
                  <span className="text-muted-foreground line-through">{d.was}</span>{" "}
                  <span className="font-heading text-xl font-extrabold text-primary">
                    {d.price}
                  </span>
                </p>
                <h3 className="mt-1.5 font-heading text-lg font-bold text-[#111111] transition-colors group-hover:text-primary">
                  {d.title}
                </h3>
                <p className="mt-1 text-xs font-semibold text-primary">{d.places.join(", ")}</p>
                <p className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Clock className="size-3.5 text-primary" /> {d.days}
                </p>
                <button type="button" className="btn-rara-primary mt-4.5 w-full py-2.5 text-xs">
                  Book Deal Now
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Visual Himalayan Photo Gallery Section */}
      <section id="gallery" className="bg-slate-900 py-20 text-white">
        <div className="container-site">
          <div className="flex flex-col items-center justify-between gap-4 text-center md:flex-row md:text-left">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-bold tracking-wider text-primary uppercase">
                <Camera className="size-4" /> Visual Journey Through Nepal
              </div>
              <h2 className="mt-1 font-heading text-3xl font-bold text-white sm:text-4xl">
                Himalayan Expedition Gallery
              </h2>
              <p className="mt-2 text-sm text-slate-300">
                Glimpses from the Khumbu moraines, Annapurna valleys, high stone villages, and
                sacred shrines
              </p>
            </div>

            {/* Gallery Category Filter Tabs */}
            <div className="flex flex-wrap items-center justify-center gap-2 rounded-lg bg-slate-800/80 p-1.5 backdrop-blur-sm">
              {["All", "Everest", "Annapurna", "Langtang", "Mustang", "Culture & Wildlife"].map(
                (tab) => (
                  <button
                    key={tab}
                    type="button"
                    onClick={() => setActiveGalleryTab(tab)}
                    className={`rounded-md px-3 py-1.5 text-xs font-semibold transition ${
                      activeGalleryTab === tab
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "text-slate-300 hover:text-white hover:bg-slate-700/50"
                    }`}
                  >
                    {tab}
                  </button>
                ),
              )}
            </div>
          </div>

          {/* Gallery Bento Grid */}
          <div className="mt-10 grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {filteredGallery.map((photo, idx) => (
              <div
                key={photo.id}
                onClick={() => openGalleryLightbox(idx)}
                className="group relative cursor-pointer overflow-hidden rounded-md bg-slate-800 shadow-md transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:ring-2 hover:ring-primary/60"
              >
                <div className="relative aspect-4/3 w-full overflow-hidden">
                  <SafeImage
                    src={photo.image}
                    alt={photo.title}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-80 transition-opacity group-hover:opacity-95" />

                  {/* Category Pill */}
                  <span className="absolute top-3 left-3 rounded-full bg-black/60 px-2.5 py-0.5 text-[11px] font-semibold text-primary backdrop-blur-xs">
                    {photo.category}
                  </span>

                  {/* Expand Icon */}
                  <span className="absolute top-3 right-3 flex size-7 items-center justify-center rounded-full bg-black/60 text-white opacity-0 backdrop-blur-xs transition group-hover:opacity-100">
                    <ZoomIn className="size-3.5" />
                  </span>

                  {/* Photo Title and Location */}
                  <div className="absolute right-3 bottom-3 left-3 text-white">
                    <h3 className="line-clamp-1 font-heading text-sm font-bold text-white transition-colors group-hover:text-primary">
                      {photo.title}
                    </h3>
                    <p className="mt-0.5 flex items-center gap-1 text-[11px] text-slate-300">
                      <MapPin className="size-3 text-primary" /> {photo.location}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Activities Section */}
      <section id="activities" className="bg-muted py-20">
        <div className="container-site">
          <h2 className="section-title text-center">Himalayan Activities</h2>
          <p className="mt-2 text-center text-sm text-muted-foreground">
            From high-altitude climbs to gentle jungle safaris and scenic helicopter rides
          </p>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {activities.map((a) => (
              <article
                key={a.title}
                onClick={() => openTourByTitle(a.title)}
                className="rara-card group cursor-pointer overflow-hidden bg-background"
              >
                <div className="overflow-hidden">
                  <SafeImage
                    src={a.img}
                    alt={a.title}
                    className="h-56 w-full object-cover transition-transform duration-500 group-hover:scale-108"
                  />
                </div>
                <div className="p-6">
                  <h3 className="font-heading text-lg font-bold text-[#111111] transition-colors group-hover:text-primary">
                    {a.title}
                  </h3>
                  <p className="mt-2 text-xs text-muted-foreground leading-relaxed">{a.text}</p>
                  <div className="mt-5 flex items-center justify-between">
                    <span className="text-xs font-semibold text-primary group-hover:underline">
                      Explore Activity Packages
                    </span>
                    <span className="inline-flex size-9 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-sm transition-transform group-hover:translate-x-1">
                      <ArrowRight className="size-4" />
                    </span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Section */}
      <section className="container-site py-20">
        <h2 className="section-title text-center">Trekker Stories &amp; Guides</h2>
        <p className="mt-2 text-center text-sm text-muted-foreground">
          Practical advice, packing lists, and local insights from our mountain leaders
        </p>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {posts.map((p) => (
            <article key={p.title} className="rara-card group overflow-hidden bg-background">
              <div className="relative overflow-hidden">
                <SafeImage
                  src={p.img}
                  alt={p.title}
                  className="h-52 w-full object-cover transition-transform duration-500 group-hover:scale-108"
                />
                <span className="absolute top-3 left-3 rounded-full bg-primary px-3 py-0.5 font-heading text-[11px] font-semibold text-primary-foreground shadow-sm">
                  {p.category}
                </span>
              </div>
              <div className="p-5">
                <h3 className="line-clamp-2 font-heading text-base font-bold text-[#111111] transition-colors group-hover:text-primary">
                  {p.title}
                </h3>
                <p className="mt-2 line-clamp-3 text-xs text-muted-foreground leading-relaxed">
                  {p.text}
                </p>
                <div className="mt-4 flex items-center justify-between border-t border-border pt-3 text-xs text-muted-foreground">
                  <span>By Lead Sherpa Guides</span>
                  <Link to="/blog" className="font-semibold text-primary hover:underline">
                    Read More →
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <Footer />

      {/* Floating WhatsApp Quick Contact Button */}
      <aside aria-label="Quick WhatsApp Contact" className="fixed bottom-6 right-6 z-40">
        <a
          href="https://wa.me/9779851165293"
          target="_blank"
          rel="noreferrer"
          className="group flex items-center gap-2.5 rounded-full bg-[#25D366] px-4 py-3 text-white shadow-xl transition-all duration-300 hover:scale-105 hover:shadow-2xl ring-4 ring-[#25D366]/25"
          aria-label="Chat on WhatsApp with Kathmandu office"
        >
          <MessageCircle className="size-5 shrink-0" />
          <span className="hidden font-heading text-xs font-bold tracking-wide sm:inline">
            WhatsApp Us
          </span>
        </a>
      </aside>

      {/* Interactive Tour Details Modal */}
      <TourModal tour={selectedTour} open={modalOpen} onOpenChange={setModalOpen} />

      {/* Gallery Lightbox */}
      <PhotoLightbox
        images={galleryLightboxImages}
        currentIndex={lightboxIndex}
        open={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        onNavigate={(newIdx) => setLightboxIndex(newIdx)}
      />
    </div>
  );
}
