import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { CheckCircle2, Mail, MapPin, MessageSquare, Phone, Send } from "lucide-react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { PageHero } from "@/components/site/PageHero";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Us — Sunrise Himalaya Travel & Adventure" },
      {
        name: "description",
        content:
          "Contact Sunrise Himalaya Travel & Adventure in Lazimpat, Kathmandu. Call/WhatsApp +977 9851165293 or email sunrisehimalaya369@gmail.com to plan your trek.",
      },
      { property: "og:title", content: "Contact Us — Sunrise Himalaya" },
      {
        property: "og:description",
        content: "Call, WhatsApp or message our Kathmandu trekking experts.",
      },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [sent, setSent] = React.useState(false);
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [subject, setSubject] = React.useState("");
  const [message, setMessage] = React.useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <PageHero
        title="Contact Sunrise Himalaya"
        subtitle="We are available 24/7 in Kathmandu — let's plan your Himalayan journey together."
      />

      <section className="container-site grid gap-10 py-20 md:grid-cols-3">
        <div className="space-y-4">
          <div className="flex gap-4 rounded-sm bg-muted p-6">
            <MapPin className="mt-1 size-5 shrink-0 text-primary" />
            <div>
              <h2 className="font-heading font-bold">Office Address</h2>
              <p className="mt-1 text-sm text-muted-foreground">Lazimpat, Kathmandu 44600, Nepal</p>
              <p className="text-xs text-muted-foreground">Near Embassy Area, Kathmandu</p>
            </div>
          </div>

          <div className="flex gap-4 rounded-sm bg-muted p-6">
            <Phone className="mt-1 size-5 shrink-0 text-primary" />
            <div>
              <h2 className="font-heading font-bold">Phone &amp; WhatsApp</h2>
              <a
                href="tel:+9779851165293"
                className="mt-1 block text-sm font-semibold text-primary hover:underline"
              >
                +977 9851165293
              </a>
              <a
                href="https://wa.me/9779851165293"
                target="_blank"
                rel="noreferrer"
                className="mt-2 inline-flex items-center gap-1.5 rounded-sm bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white"
              >
                <MessageSquare className="size-3.5" /> Chat on WhatsApp
              </a>
            </div>
          </div>

          <div className="flex gap-4 rounded-sm bg-muted p-6">
            <Mail className="mt-1 size-5 shrink-0 text-primary" />
            <div>
              <h2 className="font-heading font-bold">Official Email</h2>
              <a
                href="mailto:sunrisehimalaya369@gmail.com"
                className="mt-1 block text-sm text-muted-foreground hover:text-primary"
              >
                sunrisehimalaya369@gmail.com
              </a>
              <p className="text-xs text-muted-foreground">Responses within 2 - 4 hours</p>
            </div>
          </div>
        </div>

        <div className="rounded-sm border border-border bg-background p-8 shadow-xs md:col-span-2">
          {sent ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <CheckCircle2 className="size-14 text-emerald-500 mb-4" />
              <h3 className="font-heading text-2xl font-bold">Message Sent Successfully!</h3>
              <p className="mt-2 max-w-md text-sm text-muted-foreground">
                Thank you, <strong>{name}</strong>. Our team in Kathmandu has received your message
                and will reply to <strong>{email}</strong> shortly.
              </p>
              <button
                onClick={() => setSent(false)}
                className="mt-6 bg-primary px-6 py-2.5 text-xs font-semibold text-primary-foreground"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <h2 className="section-title-left">Send Our Expedition Team a Message</h2>
              <p className="text-xs text-muted-foreground">
                Tell us your desired travel dates, group size, or which peak or valley you wish to
                visit.
              </p>
              <div className="grid gap-4 sm:grid-cols-2">
                <input
                  required
                  placeholder="Your Full Name *"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="rounded-sm border border-border px-4 py-3 text-sm outline-none focus:border-primary"
                />
                <input
                  required
                  type="email"
                  placeholder="Your Email Address *"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="rounded-sm border border-border px-4 py-3 text-sm outline-none focus:border-primary"
                />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <input
                  placeholder="Phone / WhatsApp Number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="rounded-sm border border-border px-4 py-3 text-sm outline-none focus:border-primary"
                />
                <input
                  placeholder="Subject (e.g., Everest Base Camp in April)"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="rounded-sm border border-border px-4 py-3 text-sm outline-none focus:border-primary"
                />
              </div>
              <textarea
                rows={5}
                required
                placeholder="Tell us about your trip plans, fitness level, questions..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full rounded-sm border border-border px-4 py-3 text-sm outline-none focus:border-primary"
              />
              <button type="submit" className="btn-rara-primary text-xs py-3 px-8">
                <Send className="size-4" /> Send Message
              </button>
            </form>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
