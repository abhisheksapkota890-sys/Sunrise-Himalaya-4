import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { PageHero } from "@/components/site/PageHero";
import { aboutImg, counters, features, teamMembers } from "@/data/travel";
import { Award, Compass, MessageCircle, ShieldCheck, Users } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — Sunrise Himalaya Travel & Adventure" },
      {
        name: "description",
        content:
          "Meet the local mountain experts behind Sunrise Himalaya Travel & Adventure: licensed Sherpa guides, tailor-made itineraries, and middleman-free pricing.",
      },
      { property: "og:title", content: "About Us — Sunrise Himalaya" },
      {
        property: "og:description",
        content:
          "Local mountain experts crafting customizable, honestly priced Himalayan trekking holidays.",
      },
    ],
  }),
  component: About,
});

function About() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <PageHero
        title="About Sunrise Himalaya"
        subtitle="A Kathmandu-based local travel agency led by certified Himalayan guides."
      />

      {/* Main Story */}
      <section className="container-site grid items-center gap-12 py-20 md:grid-cols-2">
        <div className="relative overflow-hidden rounded-md shadow-lg group">
          <img
            src={aboutImg}
            alt="Annapurna traditional village and mountain ranges"
            className="w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute bottom-4 left-4 right-4 rounded-md bg-black/75 p-4 text-white backdrop-blur-xs border border-white/10">
            <div className="flex items-center gap-3">
              <span className="flex size-10 items-center justify-center rounded-full bg-primary text-white">
                <Award className="size-5" />
              </span>
              <div>
                <p className="font-heading text-sm font-bold">16+ Years Guiding the Himalayas</p>
                <p className="text-xs text-white/80">Government Licensed & NTB / TAAN Member</p>
              </div>
            </div>
          </div>
        </div>

        <div>
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-wider text-primary uppercase">
            <ShieldCheck className="size-4" /> Rooted in the Himalayas
          </div>
          <h2 className="section-title-left mt-2">Guided by Native Mountain Specialists</h2>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
            Sunrise Himalaya Travel &amp; Adventure Pvt. Ltd. was founded with a singular purpose:
            to share the awe-inspiring majesty and rich cultural heritage of Nepal with travelers
            from around the globe in a safe, sustainable, and unforgettable way.
          </p>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            From the high-altitude trails of Everest Base Camp and Annapurna Circuit to the tranquil
            rain-shadow lands of Upper Mustang, our team designs custom itineraries crafted to your
            pace, group preferences, and physical readiness.
          </p>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            Because our office is located directly in Lazimpat, Kathmandu, you book directly with
            the local team managing your logistics, permits, mountain porters, and emergency
            support.
          </p>

          <div className="mt-7 flex flex-wrap gap-4">
            <Link to="/contact" className="btn-rara-primary text-xs py-3 px-7">
              <Compass className="size-4" />
              <span>Inquire With Our Team</span>
            </Link>
            <a
              href="https://wa.me/9779851165293"
              target="_blank"
              rel="noreferrer"
              className="btn-rara-outline text-xs py-3 px-7"
            >
              <MessageCircle className="size-4" />
              <span>WhatsApp Direct</span>
            </a>
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="bg-muted/40 py-20 border-t border-border/60">
        <div className="container-site">
          <div className="text-center max-w-2xl mx-auto">
            <div className="inline-flex items-center gap-2 text-xs font-bold tracking-wider text-primary uppercase">
              <Users className="size-4" /> The People Behind Your Journeys
            </div>
            <h2 className="section-title mt-2">Meet Our Team</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              From leadership in Kathmandu to our certified high-altitude leaders and skilled
              drivers on the road, meet the dedicated professionals who make every Himalayan trip
              safe, seamless, and memorable.
            </p>
          </div>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {teamMembers.map((member) => (
              <div
                key={member.id}
                className="group relative flex flex-col justify-between rounded-xl border border-border/80 bg-background p-6 shadow-xs transition-all duration-300 hover:border-primary/40 hover:shadow-md"
              >
                <div>
                  <div className="flex items-start justify-between gap-4">
                    {member.photo ? (
                      <img
                        src={member.photo}
                        alt={member.name}
                        className="size-14 rounded-full object-cover ring-2 ring-primary/20 transition-transform duration-300 group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex size-14 items-center justify-center rounded-full bg-primary/10 font-heading text-sm font-bold text-primary ring-2 ring-primary/20 transition-transform duration-300 group-hover:scale-105">
                        {member.initials}
                      </div>
                    )}
                    <span className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-semibold text-muted-foreground">
                      {member.experience}
                    </span>
                  </div>

                  <div className="mt-4">
                    <h3 className="font-heading text-lg font-bold text-[#111111] transition-colors group-hover:text-primary">
                      {member.name}
                    </h3>
                    <p className="mt-0.5 text-xs font-bold uppercase tracking-wider text-primary">
                      {member.role}
                    </p>
                  </div>

                  <p className="mt-3 text-xs leading-relaxed text-muted-foreground">{member.bio}</p>
                </div>

                <div className="mt-5 border-t border-border/60 pt-3 flex items-center justify-between text-[11px] text-muted-foreground">
                  <span className="font-medium text-muted-foreground/80">{member.department}</span>
                  <span className="font-semibold text-primary">Sunrise Himalaya</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Guiding Commitments */}
      <section className="bg-muted py-20">
        <div className="container-site">
          <h2 className="section-title text-center">Our Guiding Commitments</h2>
          <p className="mt-2 text-center text-sm text-muted-foreground max-w-xl mx-auto">
            Safety first, fair porter welfare, and genuine cultural immersion at every step
          </p>

          <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {features.map((f) => (
              <div key={f.title} className="rara-card bg-background p-7">
                <h3 className="font-heading text-base font-bold text-[#111111]">{f.title}</h3>
                <p className="mt-3 text-xs leading-relaxed text-muted-foreground">{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Numerical Stats */}
      <section className="container-site grid grid-cols-2 gap-6 py-16 text-center md:grid-cols-4">
        {counters.map((c) => (
          <div key={c.label}>
            <p className="font-heading text-4xl font-bold text-primary">{c.value}</p>
            <p className="mt-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              {c.label}
            </p>
          </div>
        ))}
      </section>

      <Footer />
    </div>
  );
}
