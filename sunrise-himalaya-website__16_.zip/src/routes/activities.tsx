import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, Clock, Mountain } from "lucide-react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { PageHero } from "@/components/site/PageHero";
import { TourModal } from "@/components/site/TourModal";
import { SafeImage } from "@/components/site/SafeImage";
import { activities, allTours, Tour } from "@/data/travel";

export const Route = createFileRoute("/activities")({
  head: () => ({
    meta: [
      {
        title: "Nepal Adventure Activities — Trekking, Helicopter, Safari | Sunrise Himalaya",
      },
      {
        name: "description",
        content:
          "Pick your Himalayan adventure: high-altitude trekking, scenic helicopter tours, jungle wildlife safaris, motorbike expeditions, and paragliding.",
      },
      {
        property: "og:title",
        content: "Nepal Adventure Activities — Sunrise Himalaya",
      },
      {
        property: "og:description",
        content:
          "Trekking, scenic helicopter flights, wildlife safaris, and motorbike expeditions led by local Sherpa guides.",
      },
    ],
  }),
  component: Activities,
});

function Activities() {
  const [selectedActivity, setSelectedActivity] = React.useState<string | null>(null);
  const [selectedTour, setSelectedTour] = React.useState<Tour | null>(null);
  const [modalOpen, setModalOpen] = React.useState(false);

  const matchingTours = selectedActivity
    ? allTours.filter((t) => {
        const act = selectedActivity.toLowerCase();
        if (act.includes("trekking")) {
          return t.categories.includes("Trekking");
        }
        if (act.includes("helicopter")) {
          return t.categories.includes("Helicopter Tours");
        }
        if (act.includes("safari") || act.includes("wildlife")) {
          return t.categories.includes("Wildlife Tours");
        }
        if (act.includes("pilgrimage") || act.includes("cultural")) {
          return t.categories.includes("Cultural Tours");
        }
        if (act.includes("motorbike") || act.includes("jeep")) {
          return (
            t.categories.includes("Adventure Tours") ||
            t.title.toLowerCase().includes("jeep") ||
            t.title.toLowerCase().includes("motorbike")
          );
        }
        if (act.includes("aerial") || act.includes("adventure")) {
          return (
            t.title.toLowerCase().includes("paragliding") ||
            t.title.toLowerCase().includes("bungee")
          );
        }
        return false;
      })
    : [];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <PageHero
        title="Nepal Adventure Activities"
        subtitle="Choose how you want to experience the Himalayas — from mountain trails to skies and jungles."
      />

      <section className="container-site py-20">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {activities.map((a) => (
            <article
              key={a.title}
              onClick={() => setSelectedActivity(a.title === selectedActivity ? null : a.title)}
              className={`group cursor-pointer overflow-hidden rounded-sm border bg-background shadow-xs transition-all duration-300 hover:shadow-lg ${
                selectedActivity === a.title
                  ? "border-primary ring-2 ring-primary/30"
                  : "border-border hover:border-primary/50"
              }`}
            >
              <div className="overflow-hidden">
                <SafeImage
                  src={a.img}
                  alt={a.title}
                  className="h-56 w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-6">
                <h2 className="font-heading text-lg font-bold transition-colors group-hover:text-primary">
                  {a.title}
                </h2>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{a.text}</p>
                <div className="mt-4 flex items-center justify-between">
                  <span className="text-xs font-semibold text-primary">
                    {selectedActivity === a.title ? "Hide Packages ↑" : "View Packages ↓"}
                  </span>
                  <span className="inline-flex size-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                    <ArrowRight className="size-4" />
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* Dynamic Activity Tour Showcase */}
        {selectedActivity && (
          <div className="mt-16 rounded-lg border border-primary/20 bg-muted/30 p-8">
            <div className="mb-6 flex flex-col justify-between gap-2 sm:flex-row sm:items-center">
              <div>
                <h3 className="font-heading text-2xl font-bold text-foreground">
                  {selectedActivity} Packages
                </h3>
                <p className="text-xs text-muted-foreground">
                  Found {matchingTours.length} available packages
                </p>
              </div>
              <button
                onClick={() => setSelectedActivity(null)}
                className="text-xs font-semibold text-primary hover:underline"
              >
                Close List
              </button>
            </div>

            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {matchingTours.map((t) => (
                <div
                  key={t.slug}
                  onClick={() => {
                    setSelectedTour(t);
                    setModalOpen(true);
                  }}
                  className="rara-card group cursor-pointer overflow-hidden bg-background"
                >
                  <div className="relative overflow-hidden">
                    <SafeImage
                      src={t.image}
                      alt={t.title}
                      className="h-44 w-full object-cover transition-transform duration-500 group-hover:scale-108"
                    />
                    <span className="absolute top-2.5 left-2.5 rounded-full bg-primary px-3 py-1 font-heading text-xs font-semibold text-primary-foreground shadow-sm">
                      ${t.price}
                    </span>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="size-3 text-primary" /> {t.duration}
                      </span>
                      {t.maxAltitude && (
                        <span className="font-medium text-foreground">{t.maxAltitude}</span>
                      )}
                    </div>
                    <h4 className="mt-2 line-clamp-1 font-heading text-sm font-bold text-[#111111] group-hover:text-primary transition-colors">
                      {t.title}
                    </h4>
                    <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
                      {t.summary}
                    </p>
                    <button className="btn-rara-outline mt-3 w-full py-2 text-xs">
                      View Details &amp; Itinerary
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      <Footer />
      <TourModal tour={selectedTour} open={modalOpen} onOpenChange={setModalOpen} />
    </div>
  );
}
