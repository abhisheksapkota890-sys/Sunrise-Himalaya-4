import * as React from "react";

export const FALLBACK_IMAGE = "/assets/hero-himalaya-DrS97LmK.jpg";

interface SafeImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  fallbackSrc?: string;
}

export function SafeImage({
  src,
  fallbackSrc = FALLBACK_IMAGE,
  alt = "Nepal Himalayan Tour",
  className = "",
  ...props
}: SafeImageProps) {
  const [currentSrc, setCurrentSrc] = React.useState<string>(src || fallbackSrc);
  const [hasError, setHasError] = React.useState(false);

  React.useEffect(() => {
    setCurrentSrc(src || fallbackSrc);
    setHasError(false);
  }, [src, fallbackSrc]);

  return (
    <img
      {...props}
      src={hasError ? fallbackSrc : currentSrc}
      alt={alt}
      loading={props.loading ?? "lazy"}
      referrerPolicy="no-referrer"
      onError={() => {
        if (!hasError) {
          setHasError(true);
        }
      }}
      className={className}
    />
  );
}
