import { Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  ChevronDown,
  Facebook,
  Home,
  Instagram,
  Mail,
  MapPin,
  Menu,
  Mountain,
  Phone,
  Search,
  Twitter,
  X,
  Youtube,
} from "lucide-react";

function WhatsAppIcon({ className = "size-3.5" }: { className?: string }) {
  return (
    <svg className={className} fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z" />
    </svg>
  );
}

function ViberIcon({ className = "size-3.5" }: { className?: string }) {
  return (
    <svg className={className} fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12.004 0C5.372 0 0 4.887 0 10.916c0 3.328 1.65 6.297 4.227 8.214l-.658 3.585c-.098.535.394.97.912.806l4.24-1.341c1.045.367 2.158.568 3.283.568 6.632 0 12.004-4.887 12.004-10.916C24.008 4.887 18.636 0 12.004 0zm5.82 14.884c-.244.664-1.252 1.265-1.782 1.32-.49.052-1.127.075-3.606-.948-3.17-1.307-5.207-4.529-5.366-4.739-.158-.21-1.28-1.705-1.28-3.252 0-1.547.812-2.308 1.1-2.617.288-.309.628-.387.838-.387.21 0 .42.002.604.012.194.01.455-.074.71.54.266.643.908 2.215.986 2.375.079.16.132.348.026.558-.105.21-.158.34-.315.524-.158.185-.332.413-.474.554-.158.158-.323.33-.139.645.184.316.818 1.349 1.755 2.183 1.205 1.073 2.222 1.405 2.538 1.563.315.158.5-.026.683-.237.184-.21.787-.918.997-1.233.21-.315.42-.263.71-.158.289.105 1.838.866 2.153 1.024.315.158.525.236.604.368.079.132.079.765-.165 1.429z" />
    </svg>
  );
}

interface DropdownItem {
  label: string;
  to: string;
  children?: { label: string; to: string; desc?: string }[];
}

const nav: DropdownItem[] = [
  { label: "Home", to: "/" },
  {
    label: "Destinations",
    to: "/destinations",
    children: [
      { label: "Everest Region", to: "/destinations", desc: "EBC, Gokyo Lakes & Kala Patthar" },
      { label: "Annapurna Region", to: "/destinations", desc: "ABC, Circuit & Ghorepani" },
      { label: "Langtang Valley", to: "/destinations", desc: "Kyanjin Gompa & Gosaikunda" },
      { label: "Upper Mustang", to: "/destinations", desc: "Ancient Kingdom of Lo Manthang" },
      { label: "Manaslu Circuit", to: "/destinations", desc: "Untouched mountain sanctuary" },
      { label: "Chitwan & Wildlife", to: "/destinations", desc: "Jungle safaris & river canoe" },
    ],
  },
  {
    label: "Activities",
    to: "/activities",
    children: [
      { label: "High Altitude Trekking", to: "/activities", desc: "Guided tea-house expeditions" },
      { label: "Helicopter Tours", to: "/activities", desc: "Scenic luxury fly-ins to 5,500m" },
      { label: "Peak Climbing", to: "/activities", desc: "Island Peak, Mera & Lobuche" },
      { label: "Wildlife Safaris", to: "/activities", desc: "Rhinos, tigers & bird watching" },
      { label: "Cultural Heritage Tours", to: "/activities", desc: "UNESCO temples & stupas" },
    ],
  },
  {
    label: "Trip Types",
    to: "/trip-types",
    children: [
      { label: "Classic Himalayan Treks", to: "/trip-types" },
      { label: "Short & Day Hikes", to: "/trip-types" },
      { label: "Luxury Lodges & Heli", to: "/trip-types" },
      { label: "Motorbike & 4x4 Overland", to: "/trip-types" },
    ],
  },
  { label: "About Us", to: "/about" },
  { label: "Blog", to: "/blog" },
  { label: "Contact", to: "/contact" },
];

export function Header() {
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [quickQuery, setQuickQuery] = useState("");
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (quickQuery.trim()) {
      window.location.href = `/?search=${encodeURIComponent(quickQuery)}`;
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-background shadow-xs">
      {/* 1. Rara Themes Top Bar (header-t): Emerald Green */}
      <div className="bg-primary text-primary-foreground">
        <div className="container-site flex h-10 items-center justify-between text-xs">
          {/* Social icons */}
          <div className="flex items-center gap-3">
            <span className="hidden sm:inline font-heading font-medium tracking-wide text-[11px] opacity-90 uppercase">
              Follow Us:
            </span>
            <div className="flex items-center gap-2.5">
              <a
                href="https://www.facebook.com/profile.php?id=61593082291985"
                target="_blank"
                rel="noreferrer"
                aria-label="Facebook"
                className="transition-transform duration-200 hover:scale-115 hover:opacity-90"
              >
                <Facebook className="size-3.5" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram"
                className="transition-transform duration-200 hover:scale-115 hover:opacity-90"
              >
                <Instagram className="size-3.5" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Twitter / X"
                className="transition-transform duration-200 hover:scale-115 hover:opacity-90"
              >
                <Twitter className="size-3.5" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                aria-label="YouTube"
                className="transition-transform duration-200 hover:scale-115 hover:opacity-90"
              >
                <Youtube className="size-3.5" />
              </a>
            </div>
          </div>

          {/* Right quick tools: Call, WhatsApp, Viber, Gmail, & Search */}
          <div className="flex items-center gap-3 sm:gap-4">
            {/* 1. Call icon & number */}
            <a
              href="tel:+9779851165293"
              className="flex items-center gap-1.5 opacity-95 transition-opacity hover:opacity-100 hover:underline"
              title="Call us: +977 9851165293"
            >
              <Phone className="size-3.5 shrink-0" />
              <span className="font-heading text-[11px] font-semibold tracking-wide sm:text-xs">
                +977 9851165293
              </span>
            </a>

            {/* 2. WhatsApp logo */}
            <a
              href="https://wa.me/9779851165293"
              target="_blank"
              rel="noreferrer"
              aria-label="Chat on WhatsApp"
              title="Chat on WhatsApp (+977 9851165293)"
              className="opacity-90 transition-transform duration-200 hover:scale-120 hover:opacity-100"
            >
              <WhatsAppIcon className="size-3.5 shrink-0" />
            </a>

            {/* 3. Viber logo */}
            <a
              href="viber://chat?number=%2B9779851165293"
              target="_blank"
              rel="noreferrer"
              aria-label="Chat on Viber"
              title="Chat on Viber (+977 9851165293)"
              className="opacity-90 transition-transform duration-200 hover:scale-120 hover:opacity-100"
            >
              <ViberIcon className="size-3.5 shrink-0" />
            </a>

            {/* 4. Gmail logo & address */}
            <a
              href="mailto:sunrisehimalaya369@gmail.com"
              className="flex items-center gap-1.5 font-sans opacity-90 transition-opacity hover:opacity-100 hover:underline"
              title="Email: sunrisehimalaya369@gmail.com"
            >
              <Mail className="size-3.5 shrink-0" />
              <span className="hidden text-xs lg:inline">sunrisehimalaya369@gmail.com</span>
            </a>

            <div className="h-3.5 w-px bg-white/25" />

            <button
              type="button"
              onClick={() => setSearchOpen(!searchOpen)}
              className="flex items-center gap-1.5 font-heading text-[11px] font-semibold uppercase tracking-wider transition-opacity hover:opacity-80"
              aria-label="Toggle Quick Search"
            >
              <Search className="size-3.5" />
              <span className="hidden sm:inline">Search</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Search Modal Dropdown */}
      {searchOpen && (
        <div className="border-b border-border bg-muted/95 p-4 backdrop-blur-md animate-fade-in-up">
          <form onSubmit={handleSearchSubmit} className="container-site flex max-w-2xl gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <input
                type="text"
                value={quickQuery}
                onChange={(e) => setQuickQuery(e.target.value)}
                placeholder="Search by trek name, destination, or activity..."
                className="w-full rounded-full border border-border bg-background py-2.5 pl-10 pr-4 text-sm text-foreground outline-none ring-primary focus:border-primary focus:ring-1"
                autoFocus
              />
            </div>
            <button type="submit" className="btn-rara-primary text-xs py-2 px-6">
              Search
            </button>
            <button
              type="button"
              onClick={() => setSearchOpen(false)}
              className="flex size-10 items-center justify-center rounded-full text-muted-foreground hover:bg-background"
            >
              <X className="size-4" />
            </button>
          </form>
        </div>
      )}

      {/* 2. Middle Branding Bar (header-b): Logo */}
      <div className="container-site flex items-center justify-between gap-4 py-4 md:py-5">
        <Link to="/" className="group flex items-center gap-3.5">
          <img
            src="/assets/logo-mark.png"
            alt="Sunrise Himalaya Travel & Adventure logo"
            className="h-12 w-auto shrink-0 transition-transform duration-300 group-hover:scale-105"
          />
          <div>
            <span className="block font-heading text-lg font-extrabold uppercase tracking-tight text-[#111111] transition-colors group-hover:text-primary sm:text-2xl lg:text-3xl">
              Sunrise Himalaya Travel and Adventure
            </span>
            <span className="mt-0.5 flex items-center gap-1.5 font-heading text-xs font-bold text-[#111111] tracking-wide sm:text-sm">
              <MapPin className="size-3.5 shrink-0 text-primary" />
              <span>Lazimpat, Kathmandu</span>
            </span>
          </div>
        </Link>

        {/* Mobile menu toggle button */}
        <button
          className="flex size-10 items-center justify-center rounded-md border border-border text-foreground md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle mobile menu"
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      {/* 3. Navigation Bar (nav-holder): Rara Themes Style */}
      <nav className="border-t border-border bg-background">
        <div className="container-site hidden items-center justify-between md:flex">
          <ul className="flex items-center">
            {/* Home Icon Button */}
            <li>
              <Link
                to="/"
                aria-label="Home"
                className="flex items-center justify-center px-4 py-4 text-foreground transition-colors hover:text-primary"
              >
                <Home className="size-4" />
              </Link>
            </li>

            {nav.slice(1).map((item) => (
              <li
                key={item.label}
                className="relative"
                onMouseEnter={() => setActiveDropdown(item.label)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <Link
                  to={item.to}
                  activeProps={{ className: "text-primary border-b-2 border-primary" }}
                  className="flex items-center gap-1.5 px-4 py-4 font-heading text-xs font-semibold tracking-wider text-[#222222] uppercase transition-colors hover:text-primary"
                >
                  <span>{item.label}</span>
                  {item.children && <ChevronDown className="size-3 opacity-60" />}
                </Link>

                {/* Animated Dropdown Menu */}
                {item.children && activeDropdown === item.label && (
                  <div className="absolute left-0 top-full z-50 min-w-64 rounded-b-md border border-t-2 border-border border-t-primary bg-background p-2 shadow-xl animate-fade-in-up">
                    <ul className="space-y-1">
                      {item.children.map((sub) => (
                        <li key={sub.label}>
                          <Link
                            to={sub.to}
                            className="block rounded-xs px-3 py-2 text-xs transition-colors hover:bg-muted group"
                          >
                            <span className="font-heading font-semibold text-[#111111] group-hover:text-primary">
                              {sub.label}
                            </span>
                            {sub.desc && (
                              <span className="block text-[11px] text-muted-foreground">
                                {sub.desc}
                              </span>
                            )}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </li>
            ))}
          </ul>

          {/* Right CTA Button */}
          <div className="py-2.5">
            <Link to="/contact" className="btn-rara-primary text-xs py-2 px-5">
              Plan Your Trip
            </Link>
          </div>
        </div>
      </nav>

      {/* Mobile Navigation Drawer */}
      {open && (
        <div className="border-t border-border bg-background pb-6 pt-2 md:hidden animate-fade-in-up">
          <ul className="container-site divide-y divide-border">
            {nav.map((item) => (
              <li key={item.label} className="py-2.5">
                <Link
                  to={item.to}
                  onClick={() => setOpen(false)}
                  className="flex items-center justify-between font-heading text-xs font-semibold uppercase tracking-wider text-[#111111] hover:text-primary"
                >
                  <span>{item.label}</span>
                </Link>
              </li>
            ))}
            <li className="pt-4">
              <Link
                to="/contact"
                onClick={() => setOpen(false)}
                className="btn-rara-primary w-full py-2.5 text-xs text-center"
              >
                Plan Your Trip
              </Link>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
}
