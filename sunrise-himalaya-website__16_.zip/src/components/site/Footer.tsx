import { Link } from "@tanstack/react-router";
import { Facebook, Instagram, Mail, MapPin, Phone, Twitter } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-[#181d24] text-slate-300 font-sans">
      <div className="container-site grid gap-10 py-16 md:grid-cols-4">
        <div>
          <h3 className="font-heading text-base font-bold uppercase tracking-wider text-white relative pb-3 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-10 after:h-0.5 after:bg-primary">
            Sunrise Himalaya
          </h3>
          <p className="mt-4 text-xs leading-relaxed text-slate-400">
            Sunrise Himalaya Travel &amp; Adventure Pvt. Ltd. is a licensed Kathmandu agency
            specializing in Everest and Annapurna treks, scenic helicopter flights, cultural
            journeys, and wildlife safaris.
          </p>
          <div className="mt-5 flex gap-2.5">
            {[
              { Icon: Facebook, href: "https://www.facebook.com/profile.php?id=61593082291985", label: "Facebook" },
              { Icon: Twitter, href: "https://twitter.com", label: "Twitter / X" },
              { Icon: Instagram, href: "https://instagram.com", label: "Instagram" },
            ].map(({ Icon, href, label }, i) => (
              <a
                key={i}
                href={href}
                target="_blank"
                rel="noreferrer"
                className="flex size-8 items-center justify-center rounded-full bg-primary/20 text-primary transition-all duration-300 hover:bg-primary hover:text-white hover:-translate-y-0.5"
                aria-label={label}
              >
                <Icon className="size-3.5" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-heading text-base font-bold uppercase tracking-wider text-white relative pb-3 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-10 after:h-0.5 after:bg-primary">
            Quick Links
          </h3>
          <ul className="mt-4 space-y-2 text-xs text-slate-400">
            {[
              { label: "About Us", to: "/about" },
              { label: "Destinations", to: "/destinations" },
              { label: "Activities", to: "/activities" },
              { label: "Trip Types", to: "/trip-types" },
              { label: "Travel Blog", to: "/blog" },
              { label: "Contact Us", to: "/contact" },
            ].map((l) => (
              <li key={l.label}>
                <Link
                  to={l.to}
                  className="transition-colors hover:text-primary flex items-center gap-1.5"
                >
                  <span className="text-primary text-[10px]">›</span>
                  <span>{l.label}</span>
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-heading text-base font-bold uppercase tracking-wider text-white relative pb-3 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-10 after:h-0.5 after:bg-primary">
            Contact Info
          </h3>
          <ul className="mt-4 space-y-3 text-xs text-slate-400">
            <li className="flex gap-2.5">
              <MapPin className="mt-0.5 size-4 shrink-0 text-primary" />
              <span>Lazimpat, Kathmandu 44600, Nepal</span>
            </li>
            <li className="flex gap-2.5">
              <Phone className="mt-0.5 size-4 shrink-0 text-primary" />
              <a href="tel:+9779851165293" className="hover:text-primary transition-colors">
                +977 9851165293
              </a>
            </li>
            <li className="flex gap-2.5">
              <Mail className="mt-0.5 size-4 shrink-0 text-primary" />
              <a
                href="mailto:sunrisehimalaya369@gmail.com"
                className="hover:text-primary transition-colors"
              >
                sunrisehimalaya369@gmail.com
              </a>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="font-heading text-base font-bold uppercase tracking-wider text-white relative pb-3 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-10 after:h-0.5 after:bg-primary">
            Newsletter
          </h3>
          <p className="mt-4 text-xs leading-relaxed text-slate-400">
            Subscribe to get seasonal discount codes and Himalayan trekking advice.
          </p>
          <form className="mt-4 space-y-2.5" onSubmit={(e) => e.preventDefault()}>
            <input
              type="email"
              required
              placeholder="Your email address"
              className="w-full rounded-full border border-slate-700 bg-slate-800/80 px-4 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-primary"
            />
            <button type="submit" className="btn-rara-primary w-full py-2.5 text-xs">
              Subscribe Now
            </button>
          </form>
        </div>
      </div>

      <div className="w-full overflow-hidden opacity-80">
        <img
          src="/assets/kathmandu-skyline-BWkh9nGe.jpg"
          alt="Kathmandu Skyline"
          className="h-28 w-full object-cover object-bottom sm:h-36 lg:h-44 brightness-75"
        />
      </div>

      <div className="border-t border-slate-800/80 py-5 text-center text-xs text-slate-400">
        Copyright © {new Date().getFullYear()}{" "}
        <span className="text-white font-medium">
          Sunrise Himalaya Travel &amp; Adventure Pvt. Ltd.
        </span>{" "}
        All rights reserved. Powered by Travel Agency.
      </div>
    </footer>
  );
}
