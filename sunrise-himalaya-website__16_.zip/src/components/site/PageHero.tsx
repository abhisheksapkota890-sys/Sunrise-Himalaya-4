import { Link } from "@tanstack/react-router";
import { ChevronRight, Home } from "lucide-react";
import { heroImg } from "@/data/travel";

export function PageHero({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <section className="relative overflow-hidden">
      <img src={heroImg} alt="" className="h-64 w-full object-cover md:h-80 brightness-75" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/45 to-black/30" />
      <div className="container-site absolute inset-0 flex flex-col items-center justify-center text-center animate-fade-in-up">
        {/* Rara Themes Breadcrumbs */}
        <div className="mb-3 flex items-center gap-1.5 text-xs font-medium text-white/80">
          <Link to="/" className="flex items-center gap-1 hover:text-primary transition-colors">
            <Home className="size-3" />
            <span>Home</span>
          </Link>
          <ChevronRight className="size-3 text-white/50" />
          <span className="text-primary font-semibold">{title}</span>
        </div>

        <h1 className="font-heading text-3xl font-bold text-white md:text-4xl lg:text-5xl tracking-tight drop-shadow-sm">
          {title}
        </h1>
        {subtitle ? (
          <p className="mt-3 max-w-2xl text-sm md:text-base text-white/90 leading-relaxed drop-shadow-xs">
            {subtitle}
          </p>
        ) : null}
      </div>
    </section>
  );
}
