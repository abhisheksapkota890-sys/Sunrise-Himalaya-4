import * as React from "react";
import { X, ChevronLeft, ChevronRight, MapPin, ZoomIn, ZoomOut, RotateCcw } from "lucide-react";

export interface LightboxImage {
  src: string;
  title: string;
  location?: string;
  category?: string;
}

interface PhotoLightboxProps {
  images: LightboxImage[];
  currentIndex: number;
  open: boolean;
  onClose: () => void;
  onNavigate: (newIndex: number) => void;
}

export function PhotoLightbox({
  images,
  currentIndex,
  open,
  onClose,
  onNavigate,
}: PhotoLightboxProps) {
  const [zoom, setZoom] = React.useState(1);

  React.useEffect(() => {
    setZoom(1);
  }, [currentIndex, open]);

  const handlePrev = React.useCallback(() => {
    const nextIdx = (currentIndex - 1 + images.length) % images.length;
    onNavigate(nextIdx);
  }, [currentIndex, images.length, onNavigate]);

  const handleNext = React.useCallback(() => {
    const nextIdx = (currentIndex + 1) % images.length;
    onNavigate(nextIdx);
  }, [currentIndex, images.length, onNavigate]);

  React.useEffect(() => {
    if (!open) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") handlePrev();
      if (e.key === "ArrowRight") handleNext();
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [open, onClose, handlePrev, handleNext]);

  if (!open || images.length === 0) return null;

  const current = images[currentIndex] || images[0];

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex flex-col bg-black/95 text-white backdrop-blur-md transition-opacity duration-300 animate-in fade-in"
    >
      {/* Top Header Controls */}
      <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
        <div className="flex items-center gap-3">
          <span className="rounded-full bg-primary/20 px-3 py-1 text-xs font-semibold text-primary">
            {currentIndex + 1} / {images.length}
          </span>
          {current.category && (
            <span className="hidden text-xs text-white/60 sm:inline">• {current.category}</span>
          )}
        </div>

        {/* Zoom and close controls */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(z + 0.3, 2.5))}
            aria-label="Zoom in"
            className="flex size-9 items-center justify-center rounded-full bg-white/10 transition hover:bg-white/20"
          >
            <ZoomIn className="size-4" />
          </button>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(z - 0.3, 0.8))}
            aria-label="Zoom out"
            className="flex size-9 items-center justify-center rounded-full bg-white/10 transition hover:bg-white/20"
          >
            <ZoomOut className="size-4" />
          </button>
          {zoom !== 1 && (
            <button
              type="button"
              onClick={() => setZoom(1)}
              aria-label="Reset zoom"
              className="flex size-9 items-center justify-center rounded-full bg-white/10 transition hover:bg-white/20"
            >
              <RotateCcw className="size-4" />
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            aria-label="Close lightbox"
            className="ml-2 flex size-10 items-center justify-center rounded-full bg-white/15 transition hover:bg-red-600/80"
          >
            <X className="size-5" />
          </button>
        </div>
      </div>

      {/* Main Image Stage */}
      <div className="relative flex flex-1 items-center justify-center overflow-hidden p-4">
        {/* Previous Button */}
        <button
          type="button"
          onClick={handlePrev}
          aria-label="Previous image"
          className="absolute left-4 z-10 flex size-12 items-center justify-center rounded-full bg-black/60 text-white transition hover:bg-primary hover:text-primary-foreground focus:outline-none"
        >
          <ChevronLeft className="size-6" />
        </button>

        {/* Current Image */}
        <div
          className="flex max-h-full max-w-full items-center justify-center transition-transform duration-200"
          style={{ transform: `scale(${zoom})` }}
        >
          <img
            src={current.src}
            alt={current.title}
            className="max-h-[75vh] max-w-[90vw] rounded-md object-contain shadow-2xl"
          />
        </div>

        {/* Next Button */}
        <button
          type="button"
          onClick={handleNext}
          aria-label="Next image"
          className="absolute right-4 z-10 flex size-12 items-center justify-center rounded-full bg-black/60 text-white transition hover:bg-primary hover:text-primary-foreground focus:outline-none"
        >
          <ChevronRight className="size-6" />
        </button>
      </div>

      {/* Footer with Title and Location */}
      <div className="border-t border-white/10 bg-black/50 px-6 py-4 backdrop-blur-sm">
        <div className="container-site flex flex-col items-center justify-between gap-2 text-center sm:flex-row sm:text-left">
          <div>
            <h3 className="font-heading text-lg font-bold text-white">{current.title}</h3>
            {current.location && (
              <p className="flex items-center justify-center gap-1.5 text-xs text-white/75 sm:justify-start">
                <MapPin className="size-3.5 text-primary" /> {current.location}
              </p>
            )}
          </div>
          <p className="text-xs text-white/50">
            Use Left / Right arrow keys to navigate · Esc to close
          </p>
        </div>
      </div>
    </div>
  );
}
