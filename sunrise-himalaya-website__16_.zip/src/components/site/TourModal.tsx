import * as React from "react";
import {
  Calendar,
  CheckCircle2,
  Clock,
  Compass,
  Expand,
  Image as ImageIcon,
  Map as MapIcon,
  MapPin,
  Mountain,
  Phone,
  Send,
  Users,
  XCircle,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tour } from "@/data/travel";
import { SafeImage } from "@/components/site/SafeImage";
import { PhotoLightbox, LightboxImage } from "@/components/site/PhotoLightbox";

interface TourModalProps {
  tour: Tour | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function TourModal({ tour, open, onOpenChange }: TourModalProps) {
  const [activeImg, setActiveImg] = React.useState<string>("");
  const [viewMode, setViewMode] = React.useState<"photo" | "map">("photo");
  const [lightboxOpen, setLightboxOpen] = React.useState(false);
  const [lightboxIndex, setLightboxIndex] = React.useState(0);
  const [booked, setBooked] = React.useState(false);
  const [formData, setFormData] = React.useState({
    name: "",
    email: "",
    phone: "",
    date: "",
    guests: "2",
    message: "",
  });

  React.useEffect(() => {
    if (tour) {
      setActiveImg(tour.image);
      setViewMode("photo");
      setBooked(false);
    }
  }, [tour]);

  if (!tour) return null;

  // Build lightbox image list
  const lightboxImages: LightboxImage[] = [
    {
      src: tour.image,
      title: tour.title,
      location: tour.categories?.join(" · "),
      category: "Main Photo",
    },
    ...(tour.gallery || [])
      .filter((img) => img !== tour.image)
      .map((img, i) => ({
        src: img,
        title: `${tour.title} — Photo ${i + 2}`,
        location: tour.categories?.join(" · "),
        category: "Expedition Gallery",
      })),
    ...(tour.routeMap
      ? [
          {
            src: tour.routeMap,
            title: `${tour.title} — Official Route Map`,
            location: "Elevation Profile",
            category: "Route Map",
          },
        ]
      : []),
  ];

  const handleOpenLightbox = (index = 0) => {
    setLightboxIndex(index);
    setLightboxOpen(true);
  };

  const handleBook = (e: React.FormEvent) => {
    e.preventDefault();
    setBooked(true);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-h-[92vh] max-w-3xl overflow-y-auto p-0 sm:max-w-4xl">
          {/* Main Header Banner / Map */}
          <div className="relative h-72 w-full overflow-hidden bg-slate-950 sm:h-96">
            {viewMode === "photo" ? (
              <SafeImage
                src={activeImg || tour.image}
                alt={tour.title}
                className="h-full w-full object-cover transition-all duration-300"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-slate-900 p-2">
                {tour.routeMap ? (
                  <img
                    src={tour.routeMap}
                    alt={`${tour.title} Route Map`}
                    className="max-h-full max-w-full object-contain"
                  />
                ) : (
                  <p className="text-sm text-muted-foreground">Route map unavailable</p>
                )}
              </div>
            )}
            <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-black/85 via-black/30 to-transparent" />

            {/* View Mode Switcher (Photo vs Route Map) & Fullscreen button */}
            <div className="absolute top-4 right-14 z-10 flex items-center gap-2">
              {tour.routeMap && (
                <div className="flex rounded-full bg-black/60 p-1 backdrop-blur-md">
                  <button
                    type="button"
                    onClick={() => setViewMode("photo")}
                    className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold transition ${
                      viewMode === "photo"
                        ? "bg-primary text-primary-foreground"
                        : "text-white/80 hover:text-white"
                    }`}
                  >
                    <ImageIcon className="size-3.5" /> Photos
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewMode("map")}
                    className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold transition ${
                      viewMode === "map"
                        ? "bg-primary text-primary-foreground"
                        : "text-white/80 hover:text-white"
                    }`}
                  >
                    <MapIcon className="size-3.5" /> Route Map
                  </button>
                </div>
              )}

              <button
                type="button"
                onClick={() =>
                  handleOpenLightbox(
                    viewMode === "map" && tour.routeMap ? lightboxImages.length - 1 : 0,
                  )
                }
                title="Open fullscreen view"
                className="flex size-8 items-center justify-center rounded-full bg-black/60 text-white backdrop-blur-md transition hover:bg-primary"
              >
                <Expand className="size-4" />
              </button>
            </div>

            <div className="absolute top-4 left-4 flex flex-wrap gap-2">
              {tour.categories?.map((cat) => (
                <span
                  key={cat}
                  className="rounded-full bg-primary/90 px-3 py-1 text-xs font-semibold text-primary-foreground backdrop-blur-xs"
                >
                  {cat}
                </span>
              ))}
            </div>

            <div className="absolute right-4 bottom-4 left-4 text-white">
              <h2 className="font-heading text-2xl font-bold drop-shadow-md sm:text-3xl">
                {tour.title}
              </h2>
              <p className="mt-1 max-w-2xl text-xs text-white/90 drop-shadow-sm sm:text-sm">
                {tour.summary}
              </p>
            </div>
          </div>

          {/* Gallery Thumbnails if available */}
          {tour.gallery && tour.gallery.length > 0 && (
            <div className="flex items-center gap-2 overflow-x-auto border-b border-border/50 bg-muted/20 px-6 py-2.5">
              <span className="text-[11px] font-semibold text-muted-foreground uppercase shrink-0 mr-1">
                Photos:
              </span>
              {tour.gallery.map((img, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setActiveImg(img);
                    setViewMode("photo");
                  }}
                  className={`relative h-14 w-20 shrink-0 overflow-hidden rounded-md border-2 transition-all ${
                    activeImg === img && viewMode === "photo"
                      ? "border-primary scale-105 shadow-sm"
                      : "border-transparent opacity-75 hover:opacity-100"
                  }`}
                >
                  <SafeImage src={img} alt="" className="h-full w-full object-cover" />
                </button>
              ))}

              {tour.routeMap && (
                <button
                  type="button"
                  onClick={() => setViewMode("map")}
                  className={`relative flex h-14 w-24 shrink-0 flex-col items-center justify-center rounded-md border-2 bg-slate-900 text-white transition-all ${
                    viewMode === "map"
                      ? "border-primary scale-105 shadow-sm"
                      : "border-transparent opacity-75 hover:opacity-100"
                  }`}
                >
                  <MapIcon className="size-4 text-primary" />
                  <span className="mt-0.5 text-[10px] font-bold">Route Map</span>
                </button>
              )}
            </div>
          )}

          {/* Content Body */}
          <div className="space-y-6 p-6">
            {/* Key Metrics Bar */}
            <div className="grid grid-cols-2 gap-3 rounded-lg border border-border bg-muted/40 p-4 sm:grid-cols-4">
              <div className="flex items-center gap-2.5">
                <Clock className="size-5 text-primary" />
                <div>
                  <p className="text-[11px] font-semibold text-muted-foreground uppercase">
                    Duration
                  </p>
                  <p className="text-sm font-bold">{tour.duration}</p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <Compass className="size-5 text-primary" />
                <div>
                  <p className="text-[11px] font-semibold text-muted-foreground uppercase">Price</p>
                  <p className="text-sm font-bold text-primary">
                    ${typeof tour.price === "number" ? tour.price.toLocaleString() : tour.price} USD
                  </p>
                </div>
              </div>
              {tour.maxAltitude && (
                <div className="flex items-center gap-2.5">
                  <Mountain className="size-5 text-primary" />
                  <div>
                    <p className="text-[11px] font-semibold text-muted-foreground uppercase">
                      Max Altitude
                    </p>
                    <p className="text-sm font-bold">{tour.maxAltitude}</p>
                  </div>
                </div>
              )}
              {tour.difficulty && (
                <div className="flex items-center gap-2.5">
                  <Users className="size-5 text-primary" />
                  <div>
                    <p className="text-[11px] font-semibold text-muted-foreground uppercase">
                      Difficulty
                    </p>
                    <p className="text-sm font-bold">{tour.difficulty}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Description */}
            <div>
              <h3 className="font-heading text-lg font-bold">Trip Overview</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {tour.description}
              </p>
            </div>

            {/* Itinerary */}
            {tour.itinerary && tour.itinerary.length > 0 && (
              <div>
                <h3 className="font-heading text-lg font-bold">Daily Itinerary</h3>
                <div className="mt-3 space-y-3">
                  {tour.itinerary.map(([dayTitle, dayDesc], i) => (
                    <div
                      key={i}
                      className="flex gap-3.5 rounded-md border border-border/80 bg-background p-3.5 transition-colors hover:border-primary/50"
                    >
                      <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                        {i + 1}
                      </span>
                      <div>
                        <h4 className="font-heading text-sm font-bold text-foreground">
                          {dayTitle}
                        </h4>
                        <p className="mt-1 text-xs text-muted-foreground leading-normal">
                          {dayDesc}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Included / Excluded */}
            <div className="grid gap-6 sm:grid-cols-2">
              {tour.included && tour.included.length > 0 && (
                <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-4">
                  <h4 className="flex items-center gap-2 font-heading text-sm font-bold text-emerald-800 dark:text-emerald-300">
                    <CheckCircle2 className="size-4 text-emerald-600 dark:text-emerald-400" />
                    What Is Included
                  </h4>
                  <ul className="mt-3 space-y-1.5 text-xs text-muted-foreground">
                    {tour.included.map((inc, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-emerald-600 dark:text-emerald-400">•</span>
                        <span>{inc}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {tour.excluded && tour.excluded.length > 0 && (
                <div className="rounded-lg border border-red-500/20 bg-red-500/5 p-4">
                  <h4 className="flex items-center gap-2 font-heading text-sm font-bold text-red-800 dark:text-red-300">
                    <XCircle className="size-4 text-red-600 dark:text-red-400" />
                    What Is Excluded
                  </h4>
                  <ul className="mt-3 space-y-1.5 text-xs text-muted-foreground">
                    {tour.excluded.map((exc, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-red-600 dark:text-red-400">•</span>
                        <span>{exc}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Booking & Inquiry Form */}
            <div className="rounded-lg border border-primary/20 bg-primary/5 p-5">
              <h3 className="font-heading text-base font-bold text-foreground">
                Book Or Inquire About This Package
              </h3>
              <p className="text-xs text-muted-foreground">
                Direct booking with local Sherpa experts in Kathmandu. Custom dates and itineraries
                welcome.
              </p>

              {booked ? (
                <div className="mt-4 rounded-md bg-emerald-500/10 p-4 text-emerald-700 dark:text-emerald-300">
                  <p className="font-semibold text-sm">Thank you for your booking inquiry!</p>
                  <p className="mt-1 text-xs">
                    Our Kathmandu expedition team has received your request for{" "}
                    <strong>{tour.title}</strong> and will contact you within 2 hours with
                    availability and payment details.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleBook} className="mt-4 grid gap-3 sm:grid-cols-2">
                  <input
                    type="text"
                    required
                    placeholder="Full Name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full rounded-sm border border-border bg-background px-3 py-2 text-xs text-foreground outline-none focus:border-primary"
                  />
                  <input
                    type="email"
                    required
                    placeholder="Email Address"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full rounded-sm border border-border bg-background px-3 py-2 text-xs text-foreground outline-none focus:border-primary"
                  />
                  <input
                    type="tel"
                    placeholder="WhatsApp / Phone Number"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full rounded-sm border border-border bg-background px-3 py-2 text-xs text-foreground outline-none focus:border-primary"
                  />
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full rounded-sm border border-border bg-background px-3 py-2 text-xs text-foreground outline-none focus:border-primary"
                  />
                  <div className="sm:col-span-2">
                    <textarea
                      rows={2}
                      placeholder="Specific requirements, group size, or questions..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full rounded-sm border border-border bg-background px-3 py-2 text-xs text-foreground outline-none focus:border-primary"
                    />
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-3 sm:col-span-2">
                    <a
                      href="https://wa.me/9779851165293"
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400 hover:underline"
                    >
                      <Phone className="size-3.5" /> Chat directly on WhatsApp (+977 9851165293)
                    </a>
                    <button
                      type="submit"
                      className="flex items-center justify-center gap-2 rounded-sm bg-primary px-5 py-2.5 text-xs font-semibold text-primary-foreground transition-opacity hover:opacity-90"
                    >
                      <Send className="size-3.5" /> Submit Booking Request
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <PhotoLightbox
        images={lightboxImages}
        currentIndex={lightboxIndex}
        open={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        onNavigate={(newIdx) => setLightboxIndex(newIdx)}
      />
    </>
  );
}
